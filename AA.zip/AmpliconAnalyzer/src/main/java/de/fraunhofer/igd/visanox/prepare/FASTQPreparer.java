package de.fraunhofer.igd.visanox.prepare;

import org.apache.commons.lang.time.StopWatch;

import java.io.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
//import net.sf.samtools.util.BlockCompressedInputStream;

/**
 * Prepares a FASTQ-File to be read by ParseFASTQ
 */
class FASTQPreparer {
    private String fileName;
    private int numberOfBlocksPerChunk;
    private int BUFFERSIZE = 1024*16;

    FASTQPreparer (String fileName, int numberOfBlocksPerChunk) {
        this.fileName = fileName;
        this.numberOfBlocksPerChunk = numberOfBlocksPerChunk;
    }

    void partition (String inputFileName, String outputFileName) throws IOException {
        // 100MB random compressed -> 150MB random raw in 68 seconds
        StopWatch t = new StopWatch(); t.start();

        int counter = 0; int globalCounter = 0;

        FileOutputStream outputStream = new FileOutputStream(outputFileName);
        ZipOutputStream zipStream = new ZipOutputStream(new BufferedOutputStream(outputStream));

        FileInputStream inputStream = new FileInputStream(inputFileName);
        GZIPInputStream gzipStream = new GZIPInputStream(new BufferedInputStream(inputStream));

        byte[] buffer = new byte[BUFFERSIZE];
        int start;

        ZipEntry currentEntry = new ZipEntry(globalCounter+".fastq");
        zipStream.putNextEntry(currentEntry);

        for (int read; (read = gzipStream.read(buffer,0,buffer.length)) >= 0; ) {
            start = 0; int i;
            for (i = 0; i < read; i++) {
                counter = buffer[i] == '@' ? counter+1 : counter;
                if (counter > this.numberOfBlocksPerChunk) {
                    counter = 0;
                    globalCounter++;
                    zipStream.write(buffer,start,i-start);
                    zipStream.closeEntry();
                    start = i;
                    currentEntry = new ZipEntry(globalCounter+".fastq");
                    zipStream.putNextEntry(currentEntry);
                }
            }
            if (start != i) {
                zipStream.write(buffer,start,i-start);
            }
        }
        zipStream.closeEntry();
        zipStream.close();
        gzipStream.close();
        outputStream.close();

        t.stop();
        System.out.print(t.getTime()/1000);
    }
}
