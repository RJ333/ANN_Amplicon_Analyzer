package de.fraunhofer.igd.visanox.converter;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Schreibt Arraydaten in ein 2D-Graustufen-PNG.
 * 
 * @author Thomas Ruth, Fraunhofer IGD, 2015
 */
public class PNGWriter {
	private static final Log logger = LogFactory.getLog(PNGWriter.class); 
	
	public PNGWriter() {
		
	}
	
	/**
	 * Schreibt ein übergebenes Array als Graustufenbild in ein PNG.
	 */
	public void writeVolume(float[][] image, final String outputFileName) {
		StringBuilder sb = new StringBuilder();
		sb.append("Write out image as grayscale PNG image");
		
		int width = image[0].length; // 1. Dimension
		int height = image[0].length; // 2. Dimension
		try {
			BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
			WritableRaster r = bi.getRaster();

			// Hier das Array durchlaufen und in das PNG übertragen
		
			for (int i = 0; i < image.length; i++) {
				for (int j = 0; j < image[i].length; j++) {
					// Konversion in integer-Werte
					final int value = (int) image[i][j];
					r.setPixel(i, j, new int[] { value});
				}
			}
			sb.append('.');
			logger.info(sb.toString());

			ImageIO.write(bi, "PNG", new File(outputFileName));
			
			logger.info("Wrote image to file: " + outputFileName);

		} catch (IOException ie) {
			// TODO Ordentliches Fehlerhandling...
			ie.printStackTrace();
		}
	}
}