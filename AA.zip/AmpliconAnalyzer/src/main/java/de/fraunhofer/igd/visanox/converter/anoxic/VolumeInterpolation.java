package de.fraunhofer.igd.visanox.converter.anoxic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.LUDecomposition;
import org.apache.commons.math3.linear.QRDecomposition;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;
import org.geotools.geometry.jts.JTSFactoryFinder;
import org.geotools.geometry.jts.WKTReader2;

import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jtsexample.geom.ExtendedCoordinate;

/**
 * Class for one file/set of iow data. One-time computing is done at object initialization,
 * computing the Kriging-estimator for arbitrary new points will still cost significant
 * computation, so it should be used in measures. An approach for further processing would be
 * to compute a rough grid of Kriging-estimated points and for graphical display, connect
 * these points using an interpolation, e.g. splines.
 * 
 * @author jzabel
 *
 */
public class VolumeInterpolation { 
	private static final Log logger = LogFactory.getLog(VolumeInterpolation.class); 
  
  /**
   * The constructor makes all the one-time calculations that there are for a fix set of data,
   * such as computing the distance matrix or creating a variogram, so it might take
   * more time than usual for an object to initialize 
   * (depends on the amount of data approx. quadratically).
   * 
   * USAGE: create one VolumeInterpolation Object for one set of data,
   * query estimates using 'ordinaryKriging(...)' for as many points as you like
   * (may be computationally complex, ~ cubic in number of data points)
   * 
   * @param iowDataFilePath point the object to the IOW-Data it shall use
   * @throws ParseException 
   * @throws IOException 
   */
	public VolumeInterpolation(String basinsPath, String iowDataFilePath) throws IOException, ParseException {
		this(basinsPath, iowDataFilePath, true);
	}

	public VolumeInterpolation(String basinsPath, String iowDataFilePath, boolean verbose)	throws IOException, ParseException {
		this.basins = readBalticSeaBasinsFromFile(createWKTfileList(basinsPath));
		this.iowData = readFromIOW_TSV_File(iowDataFilePath, basins);
		init(verbose);
	}
  
	/**
	 * Shortcut constructor to reuse already precompiled data structures for
	 * basins and input data. (If you for example, already calculated BAXI).
	 */
	public VolumeInterpolation(Map<String, Polygon> basins, List<GridPointData> iowData, boolean verbose) throws IOException, ParseException {
		this.basins = basins;
		this.iowData = iowData;
		init(verbose);
	}
  
	private void init(boolean verbose) {
		calculateDistanceMatrix(this.iowData);
		computeEmpiricalVariograms(iowData);
		this.DEBUG = verbose;
	}
  
  private com.vividsolutions.jts.geom.GeometryFactory geometryFactory = JTSFactoryFinder.getGeometryFactory();
  private double[][] distanceMatrix;
  
  private double minDistance = Double.MAX_VALUE;
  private double maxDistance = Double.MIN_VALUE;
  
  private double bucketsize;
  
  private double iowDepthMean;
  private double iowO2Mean;
  private double iowH2SMean;
  
  private double iowDepthVariance;
  private double iowO2Variance;
  private double iowH2SVariance;
  
  double[] depthVariogram;
  double[] O2Variogram;
  double[] H2SVariogram;
  private final List<GridPointData> iowData;
  private final Map<String,Polygon> basins;
  
  private boolean DEBUG = true;
    
  private static final String [] FILE_HEADER_MAPPING = {"station","lon","lat","maxtiefe","tiefe3_O2","O2_tiefe3","tiefe1_O2","O2_tiefe1","tiefe2_O2","O2_tiefe2","tiefe1_H2S","H2S_tiefe1","tiefe2_H2S","H2S_tiefe2","tiefe_H2Smax","H2Smax"};
  
  /**
   * Interpolates missing sensor readings for H2S- and O2-concentration
   * with simple Kriging interpolation.
   * NOTE: at the moment, query ONLY with lat/lon coordinates possible!
   * 
   * returns a 2-element double array, FIRST: O2-estimation, SECOND: H2S-estimation
   * returns -999 in first/second index, when there was no data (in range) available.
   * This means, low O2 or H2s is assumed to not be present at the queried location.
   **/
  //note: query point-wise, estimation done for H2S and O2 simultaneously
  public double[] ordinaryKriging(double lon, double lat, double[] variogram, double radius){ //Lon = x (west to east), Lat = y (south to north)
    if(variogram == null) throw new IllegalArgumentException("Recieved empty variogram");
    if(distanceMatrix == null) throw new IllegalStateException("No distance matrix created yet, start 'calculateDistanceMatrix' once, before requesting any Kriging-interpolations");
    if(basins == null) throw new IllegalArgumentException("Basins not read in yet, please start 'readBalticSeaBasinsFromFile' first");
    int n = distanceMatrix.length;
    double[] estimation = {0,0};
    
    final boolean empiricalVariogram = false;
    
    //Point point = geometryFactory.createPoint(new ExtendedCoordinate(lon,lat, 0, 0));
    Pair<String,Polygon> currentBasin = assignPointToBalticSeaBasin(lon, lat, this.basins, false); //TODO not needed anymore?
    
    double normalizedSill = 0;
    double sill = 0;
    if(empiricalVariogram){
    double variogramMax = Arrays.stream(variogram).max().getAsDouble();
    sill = Arrays.stream(variogram).filter(s -> s < 0.75*variogramMax).max().getAsDouble(); //0.75 is just a practical choice, might not fit other data!
    int sillIndex = ArrayUtils.indexOf(variogram, sill);  //indexOf delivers the first occurence
    
    //normalize variogram
    variogram = Arrays.stream(variogram).map(s -> { return s/variogramMax; }).toArray();
    normalizedSill = variogram[sillIndex];
    }else{
      normalizedSill = simpleVariogram(2.5)/simpleVariogram(3);
      sill = simpleVariogram(2.5);
    }
    
    Map<Integer,Double> O2_Points = new HashMap<>(); // key = index in iowData, value = O2_value at that point
    Map<Integer,Double> H2S_Points = new HashMap<>(); // analog
    
    //pick only points within range (old method, backup/fallback code)
//    for(int i = 0; i < n; i++){        
//        if(FastMath.sqrt(FastMath.pow(iowData.get(i).getLat()-lat,2)+FastMath.pow(iowData.get(i).getLon()-lon,2))<=radius){
//          if(iowData.get(i).getReadingO2_upper().isPresent()) O2_Points.put(i, iowData.get(i).getReadingO2_upper().get());
//          if(iowData.get(i).getReadingH2S_upper().isPresent()) H2S_Points.put(i, iowData.get(i).getReadingH2S_upper().get());       
//          }
//    }
    
    //simple kriging: means stationary (so mean is constant instead of function mean = f(location) )
    double meanO2inBasin = 0;
    double meanH2SinBasin = 0;
    
    //pick only data from basin
    for(int i = 0; i < n; i++){         
      //check, if its the same basin
      if(StringUtils.equals(currentBasin.getFirst(),iowData.get(i).getBasinName().orElse(""))){
        if(iowData.get(i).getReadingO2_upper().isPresent()) {
          O2_Points.put(i, iowData.get(i).getReadingO2_upper().get());
          meanO2inBasin+=iowData.get(i).getReadingO2_upper().get();
        }
        if(iowData.get(i).getReadingH2S_upper().isPresent()) {
          H2S_Points.put(i, iowData.get(i).getReadingH2S_upper().get());
          meanH2SinBasin += iowData.get(i).getReadingH2S_upper().get();
        }
      }
    }
    if(O2_Points.size() > 0) meanO2inBasin/=O2_Points.size();
    if(H2S_Points.size() > 0) meanH2SinBasin/=H2S_Points.size();
    
    boolean O2_PointsAvailable = true;
    boolean H2S_PointsAvailable = true;
    
    //TODO: find better solution for "no points in range/basin"
    if(H2S_Points.isEmpty() && O2_Points.isEmpty()) { //TODO: WORKAROUND: this should be && instead of || => vergessen, was hier schiefgehen kann
      return new double[] {-999d,-999d};
    }
    if(O2_Points.isEmpty()) {
      estimation[0] = -999d;
      O2_PointsAvailable = false;
    }
    if(H2S_Points.isEmpty()){
      estimation[1] = -999d;
      H2S_PointsAvailable = false;
    }

    //------------O2-Section BEGIN------------------
    if(O2_PointsAvailable){
    RealMatrix covarianceMatrix_O2 = new Array2DRowRealMatrix(O2_Points.size(),O2_Points.size()); //A_i_j = sill - variogram(||i,j||_2)
    
    
    
    int[] O2_indizes = keySetToIntArray(O2_Points.keySet());
    for(int i = 0; i < O2_Points.size(); i++){        
      for(int j = i; j < O2_Points.size(); j++){
        if(i==j) {
          covarianceMatrix_O2.setEntry(i, j, normalizedSill);
          } else {
          //int whichBucket = (int) (distanceMatrix[i][j]/bucketsize);
          //Random random = new Random();
            //TODO: vermutlich FALSCH!! ->distanceMatrix nach key in O2_Points abrufen!! ->Achtung reihenfolge mit vektor punkte/request!
          
          double covariance = normalizedSill-simpleVariogram(distanceMatrix[O2_indizes[i]][O2_indizes[j]]);//variogram[whichBucket]+(random.nextDouble()-0.5d)/1000;
          covarianceMatrix_O2.setEntry(i, j, covariance); //< 0 ? random.nextDouble()/1000 : covariance);
          covarianceMatrix_O2.setEntry(j, i, covariance); // < 0 ? random.nextDouble()/1000 : covariance); //symmetric
          }
      }
    }
    
     
    QRDecomposition decomp_O2 = new QRDecomposition(covarianceMatrix_O2);
    
    //determine distances of queried point to the points that have been found in radius,
    //use their respective variogram value
    RealVector O2_covarianceRequestAndData = new ArrayRealVector(O2_Points.size()); // is 'k'
    int component = 0;
    RealVector O2_measuredDataInRange = new ArrayRealVector(O2_Points.size());
    for(Integer index : O2_indizes){
      double distance = FastMath.sqrt(FastMath.pow(iowData.get(index).getLat()-lat,2)+FastMath.pow(iowData.get(index).getLon()-lon,2));
      //if(DEBUG) System.out.printf("distance: %2.2f",distance);
      //int whichBucket = (int) (distance/bucketsize); //TODO: überprüfen
      O2_covarianceRequestAndData.setEntry(component, normalizedSill-simpleVariogram(distance));//variogram[whichBucket] < 0 ? 0 : normalizedSill-variogram[whichBucket]);
      O2_measuredDataInRange.addToEntry(component, iowData.get(index).getReadingO2_upper().get()-meanO2inBasin); //save as residuals!
      component++;
    }
    

    
    //org.jscience.mathematics.vector.Matrix<Real> matrix = DenseMatrix.valueOf(covarianceMatrix_O2);
    //RealVector pseudoWeights = covarianceMatrix_O2.
    
    RealVector kriging_O2_weigths = decomp_O2.getSolver().solve(O2_covarianceRequestAndData); //ensure, that vector components are in the same order when solving and using!
    
    //DEBUG line
    RealMatrix inverseCovariance =  new LUDecomposition(covarianceMatrix_O2).getSolver().getInverse();
    
    //apply computed weights to the points taken into consideration
    estimation[0] = meanO2inBasin + kriging_O2_weigths.dotProduct(O2_measuredDataInRange);
    }
    
    //------------H2S-Section BEGIN------------------
    if(H2S_PointsAvailable){
    RealMatrix covarianceMatrix_H2S = new Array2DRowRealMatrix(H2S_Points.size(),H2S_Points.size()); //symmetric
    
    int[] H2S_indizes = keySetToIntArray(H2S_Points.keySet());
    for(int i = 0; i < H2S_Points.size(); i++){        
      for(int j = i; j < H2S_Points.size(); j++){
        if(i==j) {
          covarianceMatrix_H2S.setEntry(i, j, normalizedSill);
          } else {
            //int whichBucket = (int) (distanceMatrix[i][j]/bucketsize);
            //Random random = new Random();
            double covariance = normalizedSill-simpleVariogram(distanceMatrix[H2S_indizes[i]][H2S_indizes[j]]);//variogram[whichBucket]+(random.nextDouble()-0.5d)/1000;
            covarianceMatrix_H2S.setEntry(i, j, covariance); //< 0 ? random.nextDouble()/1000 : covariance);
            covarianceMatrix_H2S.setEntry(j, i, covariance); // < 0 ? random.nextDouble()/1000 : covariance); //symmetric
          }
      }
    }

    QRDecomposition decomp_H2S = new QRDecomposition(covarianceMatrix_H2S);
    
    RealVector H2S_covarianceRequestAndData = new ArrayRealVector(H2S_Points.size());
    int component = 0;
    RealVector H2S_measuredDataInRange = new ArrayRealVector(H2S_Points.size());
    for(Integer index : H2S_indizes){
      double distance = FastMath.sqrt(FastMath.pow(iowData.get(index).getLat()-lat,2)+FastMath.pow(iowData.get(index).getLon()-lon,2));
      //int whichBucket = (int) (distance/bucketsize); //TODO: überprüfen
      H2S_covarianceRequestAndData.setEntry(component, normalizedSill-simpleVariogram(distance));//variogram[whichBucket] < 0 ? 0 : normalizedSill-variogram[whichBucket]); //TODO: auch nochmal drüber nachdenken!
      H2S_measuredDataInRange.addToEntry(component, iowData.get(index).getReadingH2S_upper().get()-meanH2SinBasin); //save as residuals!
      component++;
    }
    
    RealVector kriging_H2S_weigths = decomp_H2S.getSolver().solve(H2S_covarianceRequestAndData);
    
    
    estimation[1] = meanH2SinBasin + kriging_H2S_weigths.dotProduct(H2S_measuredDataInRange);  
    }
    
    if(DEBUG){ //TODO: to be replaced by a logger!
      logger.info("Requested point ("+lon+","+lat+") is in basin: "+currentBasin.getFirst());
      final StringBuilder log1 = new StringBuilder();
      log1.append("Data used for estimation of low-O2: ");
      O2_Points.entrySet().forEach(entry -> {
        Double distance = Math.sqrt(Math.pow((iowData.get(entry.getKey()).getLon()-lon),2)+Math.pow((iowData.get(entry.getKey()).getLat()-lat),2));
        log1.append(String.format(" %2.2f (%2.2f)",entry.getValue(),distance));
      });
      //O2_Points.values().forEach(d -> System.out.print(" "+d.toString()));
      logger.info(log1.toString());

      final StringBuilder log2 = new StringBuilder();
      log2.append("Data used for estimation of H2S: ");
      H2S_Points.entrySet().forEach(entry -> {
        double distance = Math.sqrt(Math.pow((iowData.get(entry.getKey()).getLon()-lon),2)+Math.pow((iowData.get(entry.getKey()).getLat()-lat),2));
        log2.append(String.format(" %2.2f (%2.2f)",entry.getValue(),distance));
      });
      //H2S_Points.values().forEach(d -> System.out.print(" "+d.toString()));
      logger.info(log2.toString());
    }
    return estimation;
  }
  
  /**
   * Simple conversion from intSet to array of int's,
   * needed by simple Kriging to assign indizes that were chosen by the basin assign
   * @param intSet
   * @return sorted int array (ascending)
   */
  private int[] keySetToIntArray(Set<Integer> intSet){
    int[] result = new int[intSet.size()];
    List<Integer> intermediateResult = new ArrayList<Integer>(intSet.size());
    for(Iterator<Integer> iterator = intSet.iterator(); iterator.hasNext();){
      intermediateResult.add(iterator.next());
    }
    Collections.sort(intermediateResult);
    for(int i = 0; i<intermediateResult.size(); i++){
      //auto-unboxing used, i know this whole thing can be done (much!) more elegantly but i lack the time/skills atm.
      //next time. promised. :-)
      result[i] = intermediateResult.get(i); 
    }
    return result;
  }
  
  
  //proximity = true allows also to choose the closest basin, false means, 
  //that the method will return null for points that are in no basin
  private static Pair<String,Polygon> assignPointToBalticSeaBasin(double lat, double lon, Map<String,Polygon> basins, boolean proximity){
//    ExtendedCoordinateSequenceFactory seqFact = ExtendedCoordinateSequenceFactory.instance();
    com.vividsolutions.jts.geom.GeometryFactory geometryFactory = JTSFactoryFinder.getGeometryFactory();
//    CoordinateSequence coord = seqFact.create(
//        new ExtendedCoordinate[] {
//            new ExtendedCoordinate(lat,lon, 0, 0),
//          });
    boolean overlap = false;
    boolean match = false;
    
    Pair<String,Polygon> containingBasin = new Pair<String, Polygon>("", null);
    
    Point point = geometryFactory.createPoint(new ExtendedCoordinate(lat,lon, 0, 0));
    Pair<Polygon,Double> closestBasin = new Pair<Polygon,Double>(null,Double.MAX_VALUE);
    for(String blubb : basins.keySet()){
      Polygon poly = basins.get(blubb);
      if(match && poly.contains(point)){ //point is in intersection
        overlap = true;
        Pair<String,Polygon> mergedBasin = new Pair<String,Polygon>("mergedBasin", (Polygon) containingBasin.getSecond().union(poly));
        containingBasin = mergedBasin;
      }
      if(!match && poly.contains(point)){
        match = true;
        containingBasin = new Pair<String,Polygon>(blubb,poly);
      }
        //calc distance
        if(proximity && poly.distance(point)< closestBasin.getSecond()){
          closestBasin = new Pair<>(poly,poly.distance(point));

      }
    }
    if(!match){
    return new Pair<String,Polygon>(null,closestBasin.getFirst());
    } else {
        return containingBasin; //is also mergedBasin if overlap
    }
  }
  
  public static Map<String,Polygon> readBalticSeaBasinsFromFile(List<String> files) throws IOException, ParseException {
    Map<String,Polygon> basins = new HashMap<String, Polygon>();
    Iterator<String> iterator = files.iterator();
    while(iterator.hasNext()){

    String fileName = iterator.next();
    
    FileReader fileReader = new FileReader(fileName);
    BufferedReader br = new BufferedReader(fileReader);
    
    String currentLine;
    String basinName = "";
    WKTReader2 reader = new WKTReader2();
    Polygon polygon; //needs to be from vividsolutions.com due to WKTReader2 using and returning this
    while((currentLine = br.readLine())!=null){
//      if(reader.read(currentLine) == null){
//        br.close();
//        throw new ParseException("Could not read WKT-file, maybe not a valid format");
//      }
      if(StringUtils.startsWith(currentLine, "#")){
        basinName = StringUtils.substring(currentLine, 1); //NOTE: potential source of error, assumes basin name to be commented out in a separate line above the polygon 
      }
      else {
        if(!StringUtils.equals(reader.read(currentLine).getClass().getSimpleName(),Polygon.class.getSimpleName())){
        br.close();
        throw new ParseException("Polygons expected for basins");
        }
        else {
        polygon = (Polygon) reader.read(currentLine);
        basins.put(basinName, polygon); //get basin name and the closed sequence of points aka polygon
      }
    }
    }
    br.close();
    }
    return basins;
  }
  
  private void calculateDistanceMatrix(List<GridPointData> heightValues){
    int n = heightValues.size();
    //do two things in two nested loops: create distance matrix AND find min and max distance
    distanceMatrix = new double[n][n];
    for(int i = 0; i < n; i++){
      for(int j = i; j < n; j++){
        if(i==j) distanceMatrix[i][i] = 0; else {
          
          double x1 = heightValues.get(i).getLat();
          double x2 = heightValues.get(j).getLat();
          double y1 = heightValues.get(i).getLon();
          double y2 = heightValues.get(j).getLon();
          distanceMatrix[i][j] = FastMath.sqrt(FastMath.pow((x1-x2),2)+FastMath.pow((y1-y2),2)); //Euclidean distance
          distanceMatrix[j][i] = distanceMatrix[i][j]; //symMETRIC
        
          if(minDistance > distanceMatrix[i][j]) minDistance = distanceMatrix[i][j];
          if(maxDistance < distanceMatrix[i][j]) maxDistance = distanceMatrix[i][j];
        }
      }
    }//distanceMatrix created, min and max found
  }
  
  List<String> createWKTfileList(String wktPath){
    List<String> wktFiles = new ArrayList<String>(6);
    for(int i = 0; i<6; i++){
      wktFiles.add(i, wktPath + "bsb"+(i+1)+".wkt");
    }
    return wktFiles;
  }
  
  /**
   * Computes a variogram from a 2-dimensional array. Output describes the estimated
   * degree of spatial correlation for the input array.
   * @param heightValues need to be positive
   * @return
   */
  
   void computeEmpiricalVariograms(List<GridPointData> heightValues) {
    int n = heightValues.size();
    
    depthVariogram = new double[n];
    O2Variogram = new double[n];
    H2SVariogram = new double[n];
    
    //double[] empiricalVariogram = new double[n];
    if(heightValues==null || n == 0) throw new IllegalArgumentException("Recieved empty data, check pointer / data file");
    
    //calculate the sample's means (depth, O2, H2S)
    int H2Svalues = n; //usually not measured everywhere
    int O2values = n; 
    for(int i = 0; i < n; i++){
        iowDepthMean += heightValues.get(i).getDepth();
        if(!heightValues.get(i).getReadingH2S_upper().isPresent()) H2Svalues--;
        if(!heightValues.get(i).getReadingO2_upper().isPresent()) O2values--;
        iowH2SMean += heightValues.get(i).getReadingH2S_upper().orElse(0d);
        iowO2Mean += heightValues.get(i).getReadingO2_upper().orElse(0d);
    }
    iowDepthMean /= n;
    iowH2SMean /= H2Svalues;
    iowO2Mean /= O2values;

    //double distanceRange = maxDistance-minDistance;
    
    // n points  =>  (n-1)(n-2)/2 distances;
    // n buckets => ~ n-3+2/n points per bucket on average
    bucketsize = maxDistance/n; 
    
    ArrayList<ArrayList<Double>> depthValuesInBuckets = new ArrayList<ArrayList<Double>>(n);
    ArrayList<ArrayList<Double>> O2ValuesInBuckets = new ArrayList<ArrayList<Double>>(n);
    ArrayList<ArrayList<Double>> H2SValuesInBuckets = new ArrayList<ArrayList<Double>>(n);
    
    //fill arrays old school
    for(int i = 0; i < n; i++){
      depthValuesInBuckets.add(i, new ArrayList<Double>());
      O2ValuesInBuckets.add(i, new ArrayList<Double>());
      H2SValuesInBuckets.add(i, new ArrayList<Double>());
    }
    
    int whichBucket;
    
    for(int i = 0; i < n; i++){        
      //compute overall variance
      iowDepthVariance += FastMath.pow(iowData.get(i).getDepth()-iowDepthMean,2);
      iowO2Variance += FastMath.pow(iowData.get(i).getReadingO2_upper().orElse(iowO2Mean)-iowO2Mean,2);
      iowH2SVariance += FastMath.pow(iowData.get(i).getReadingH2S_upper().orElse(iowH2SMean)-iowH2SMean,2);
      
      
      for(int j = i+1; j < n; j++){
        if(j>=n) break;
        //compute variance bucket-wise
        whichBucket = (int) (distanceMatrix[i][j]/bucketsize); //the +0.5 is due to cast to int being a floor operation   //TODO: nochmal durchrechnen/nachgucken!!!  
        if(whichBucket==n) whichBucket--;
        depthValuesInBuckets.get(whichBucket).add(FastMath.pow(iowData.get(i).getDepth()-iowData.get(j).getDepth(),2));
        if(iowData.get(i).getReadingO2_upper().isPresent()&&iowData.get(j).getReadingO2_upper().isPresent()){
          O2ValuesInBuckets.get(whichBucket).add(FastMath.pow(iowData.get(i).getReadingO2_upper().get()-iowData.get(j).getReadingO2_upper().get(),2));
          //System.out.printf("%2.2f %2.2f %n",distanceMatrix[i][j] ,Math.abs(iowData.get(i).getReadingO2_upper().get()-iowData.get(j).getReadingO2_upper().get()));
        }
        if(iowData.get(i).getReadingH2S_upper().isPresent()&&iowData.get(j).getReadingH2S_upper().isPresent()){
          H2SValuesInBuckets.get(whichBucket).add(FastMath.pow(iowData.get(i).getReadingH2S_upper().get()-iowData.get(j).getReadingH2S_upper().get(),2));
          //System.out.printf("%2.2f %2.2f %n",distanceMatrix[i][j],Math.abs(iowData.get(i).getReadingH2S_upper().get()-iowData.get(j).getReadingH2S_upper().get()));
        }
      }
    }
    iowDepthVariance /= n; 
    iowO2Variance /= n;
    iowH2SVariance /= n;

    
    double depthSum;
    double O2Sum;
    double H2SSum;
    
    double currentO2Max = 0;
    double currentH2SMax = 0;
    
    for(int i = 0; i < n; i++){ //n buckets
      depthSum = 0;
      O2Sum = 0;
      H2SSum = 0;
      for(int j = 0; j < depthValuesInBuckets.get(i).size(); j++){ //collect all values that belong to one bucket
        depthSum += depthValuesInBuckets.get(i).get(j);
        if(j<O2ValuesInBuckets.get(i).size())  O2Sum += O2ValuesInBuckets.get(i).get(j);
        if(j<H2SValuesInBuckets.get(i).size())  H2SSum += H2SValuesInBuckets.get(i).get(j);
      }
      depthSum /= depthValuesInBuckets.get(i).size();
      O2Sum /= depthValuesInBuckets.get(i).size();
      //System.out.printf("%2.2f %2.2f %n",i*bucketsize ,O2Sum);
      H2SSum /= depthValuesInBuckets.get(i).size();
      //System.out.printf("%2.2f %2.2f %n",i*bucketsize ,H2SSum);
      
      if(O2Sum > currentO2Max) { //force the variogram to be monotone, avoid NaN-values
        currentO2Max = O2Sum;
      }
      if(H2SSum > currentH2SMax){
        currentH2SMax = H2SSum;
      }
      depthVariogram[i] = depthSum;
      O2Variogram[i] = currentO2Max;
      H2SVariogram[i] = currentH2SMax;
      }    
    }
  /**
   * Fit an exponential function ( y = a * (1 - exp(b*x) )
   * 
   * @param heightValues hand over all data, that shall be used for variogram-computation. more is better!
   * @param mergeData merge H2S and O2-data for variance calculation and thus variogram creation
   */
  
//  private void computeExponentialVariogramModel(List<GridPointData> heightValues, boolean mergeData){
//    Regression regression = new Regression();
//    Map<Double,Double> O2Data = new TreeMap<>();
//    Map<Double,Double> H2SData = new TreeMap<>();
//    
//    double distance = 0;
//    for(int i = 0; i < heightValues.size(); i++){
//      for(int j = i+1; j < heightValues.size(); j++){
//        distance = Math.sqrt(Math.pow(heightValues.get(i).getLat()-heightValues.get(j).getLat(),2)+Math.pow(heightValues.get(i).getLon()-heightValues.get(j).getLon(),2));        
//        if(iowData.get(i).getReadingO2_upper().isPresent()&&iowData.get(j).getReadingO2_upper().isPresent()) { //only when both points have an O2-reading
//          O2Data.put(distance, iowData.get(i).getReadingO2_upper().get()-iowData.get(j).getReadingO2_upper().get());
//        }
//        if(iowData.get(i).getReadingH2S_upper().isPresent()&&iowData.get(j).getReadingH2S_upper().isPresent()) { //only when both points have an H2S-reading
//          
//        }
//      }
//    }
//    
//    ArrayList<Double> yValues = new ArrayList<Double>();
//    
//    for(int i = 0; i < heightValues.size(); i++){
//      if(heightValues.get(i).getReadingH2S_upper().isPresent()) heightValues.get(i)
//      if(heightValues.get(i).getReadingO2_upper().isPresent()) O2values--;
//      iowH2SMean += heightValues.get(i).getReadingH2S_upper().orElse(0d);
//      iowO2Mean += heightValues.get(i).getReadingO2_upper().orElse(0d);
//    }
//    
//    regression.enterData(arg0, arg1);
//    regression.oneMinusExponential();
//    re
//  }
  
  
   /**
    * NOTE: normalized!
    * @param distance
    * @return
    */
  private double simpleVariogram(double distance){
    final double range = 2.5;
    if(distance >= range) return 1;
    
    return 2*Math.sqrt(distance)/(2*Math.sqrt(range));
  }
  
  /**
   * Reads the stations' sensor readings from iow-file
   * @param fileName
   * @return list of station readings, coordinates not yet assigned to grid
   */
  
  public static List<GridPointData> readFromIOW_TSV_File(String fileName, Map<String,Polygon> basins){
    List<GridPointData> iowData = new ArrayList<GridPointData>();
    FileReader fileReader = null;
    CSVParser csvFileParser = null;
    CSVFormat csvFileFormat = CSVFormat.TDF.withHeader(FILE_HEADER_MAPPING); //this is only the columns' header, the iow-file has more header-info
    try {
      //first, the iow-file has to be made a TSV-File, it is full of spaces
      convertIOWFileToTSV(fileName);
      fileReader = new FileReader(fileName);
      csvFileParser = new CSVParser(fileReader, csvFileFormat);
      List<CSVRecord> csvRecords = csvFileParser.getRecords();
      GridPointData currentPoint;
      CSVRecord currentRecord;
      for(int i = 4; i < csvRecords.size(); i++){ //data begins at 5th line, 3 lines header, 1 line column description
        currentRecord = csvRecords.get(i);
        if (currentRecord.get("station").startsWith("no")) continue; // Skip stations which are not part of the official HELCOM monitoring program ("not named")
        
        Pair<String,Polygon> nameBasin = assignPointToBalticSeaBasin(Double.parseDouble(currentRecord.get("lon")), Double.parseDouble(currentRecord.get("lat")), basins, false);
        currentPoint = new GridPointData(
            Double.parseDouble(currentRecord.get("lon")),
            Double.parseDouble(currentRecord.get("lat")),
            Double.parseDouble(currentRecord.get("maxtiefe")),
            Double.parseDouble(currentRecord.get("tiefe1_H2S")), 
            Double.parseDouble(currentRecord.get("tiefe1_O2")),
            Double.parseDouble(currentRecord.get("H2S_tiefe1")),
            Double.parseDouble(currentRecord.get("O2_tiefe1")),
            Double.parseDouble(currentRecord.get("H2S_tiefe2")),
            Double.parseDouble(currentRecord.get("O2_tiefe2")),
            Double.parseDouble(currentRecord.get("H2Smax")),
            Double.parseDouble(currentRecord.get("O2_tiefe3")),
            nameBasin.getKey()  //not elegant but does the job
        );
        currentPoint.setStationname(currentRecord.get("station"));
        iowData.add(currentPoint);
      }
    } catch (Exception e) {
        logger.error("Error in CsvFileReader", e);
    } finally {
    try {
      fileReader.close();    
      csvFileParser.close();
      } catch (IOException e) {
        logger.error("Error while closing fileReader/fileWriter/csvFileParser", e);
        }
      }
    return iowData;
  }
  
  private static void convertIOWFileToTSV(String fileName) throws IOException{
    Path path = Paths.get(fileName);
    Charset charset = StandardCharsets.UTF_8;

    String content = new String(Files.readAllBytes(path), charset);
    content = content.replaceAll("H2S_tiefe2tiefe_H2Smax", "H2S_tiefe2"+"\t"+"tiefe_H2Smax"); //stupid IOW-file! l2p...
    content = content.replaceAll("(?m)^\\s+",""); // (?m) is MULTILINE flag
    content = content.replaceAll("^ +","");
    content = content.replaceAll(" +", "\t");
    Files.write(path, content.getBytes(charset));
  }

/**
 * Returns the input data (measured depths for anoxic and suboxic zones along the HELCOM monitoring surveys).
 */
public List<GridPointData> getInputData() {
	return iowData;
}

}
class RegexReplacement { 
  final Pattern regex;
  final String replacement;
  RegexReplacement(String regex, String replacement) {
    this.regex = Pattern.compile(regex);
    this.replacement = replacement;
  }
  String replace(String in) { 
    return regex.matcher(in).replaceAll(replacement);
    }
}

