package de.fraunhofer.igd.visanox.converter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ucar.ma2.Array;
import ucar.ma2.Range;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;
import ucar.nc2.dataset.NetcdfDataset;

/**
 * Analysieren und Konvertieren von netcdf-Daten im Projekt VisAnox.
 * 
 * Die Konfiguration des Builders kann entweder programmatisch mit BuilderProperties-Objekt, per converter.properties-Datei 
 * oder per Kommandozeilenaufruf erfolgen.
 *
 * @author Thomas Ruth, Fraunhofer IGD Rostock
 */
public class NetCdfReader {
	private static final Log logger = LogFactory.getLog(NetCdfReader.class); 

	private final BuilderProperties properties;

	public static void main(String args[]) {
		logger.info("VisAnox netCdfReader: Reads simulation data from NetCDF files.\n(C) 2014, Fraunhofer IGD Rostock\n");
    	
		if (args.length == 1 && !args[0].endsWith(".properties")) { // Only print informations, no conversion
			printNCFileInfos(args[0]);
			
		} else {

			final BuilderProperties properties;
			final BuilderProperties propsFromFile;
			// Wenn abweichender Pfad zu Config-Datei angegeben, diese nutzen!
			if ((args.length == 1) && args[0].endsWith(".properties")){
				propsFromFile = configureFromPropertyFile(args[0]);
			} else {
				propsFromFile = configureFromPropertyFile(null);
			}
			if (propsFromFile != null) {
				properties = propsFromFile;
			} else { // No converter.properties file found/used
				properties = new BuilderProperties(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
			}

			if (BuilderProperties.MODE_INFO.equals(properties.getMode())) {
				// Only print informations, no conversion
				printNCFileInfos(properties.getInputfile());
				return;
			} else {
				// do the full blown conversion job...
				final NetCdfReader x3dBuilder = new NetCdfReader(properties);
				x3dBuilder.readInputGrid();
			}

		}
	}
	
	/**
	 * Konstruktor, der ein Konfigurationsobjekt erwartet. Damit ist die eingebettete Nutzung des Builders moeglich.
	 *
	 * @param properties Konfiguration für die Konvertierung 
	 */
	public NetCdfReader(final BuilderProperties builderProperties) {
		this.properties = builderProperties;
		
		if (properties == null) {
			throw new RuntimeException("Builder properties are missing.");
		}

		if (properties.isVerbose()) {
			printParameters(properties);
		}
	}

	/**
	 * Konstruktor, der im Classpath die Datei 'converter.properties' mit der Konfiguration des Builders erwartet.
	 */
	public NetCdfReader() {
		this(configureFromPropertyFile(null));
	}
	
	private static BuilderProperties configureFromPropertyFile(final String propertyFilePath) {
		final Properties props = new Properties();
		Reader configReader = null;
		BuilderProperties properties = null;
		try {
			if (propertyFilePath != null) {
				configReader = new FileReader(propertyFilePath);
			} else {
				configReader = new FileReader("converter.properties");
			}
			props.load(configReader);
			logger.info("Found configuration file 'converter.properties', ignoring command line configuration.");
			if (!props.isEmpty()){
				properties = new BuilderProperties();
				BeanUtils.populate(properties, props);
			} else {
				logger.info("Converter property file is empty. Continuing with command line parameter configuration.");
			}
		} catch (FileNotFoundException e) {
			logger.info("Could not find converter property file. Continuing with command line parameter configuration.");
		} catch (IOException e) {
			logger.error("Error: Could not read converter property file.");
		} catch (IllegalAccessException e) {
			logger.error("Error: Could not configure converter from property file (maybe wrong/unknown property names?): " + e.getMessage() );
		}
	      catch (InvocationTargetException e) {
		    logger.error("Error: Could not configure converter from property file (maybe wrong/unknown property names?): " + e.getMessage() );
	    }
		if (configReader != null) {
			try {
				configReader.close();
			} catch (IOException e) {
				logger.error("Error: Could not close converter property file.");
			}
		}
		return properties;
	}

	/**
	 * Methode zum Auslesen eines Höhenfelds aus einer .nc Datei und Schreiben einer 3D-Szene im X3D-Format.
	 */
	public void readInputGrid() {
		final long startTime = System.nanoTime();
		
		NetcdfFile dataFile = null;
		
		final String inputFilename = properties.getInputfile();
		final String variableToParse = properties.getHeightVariable();
		final String variableForColor = properties.getColorVariable();
		final String variableForHighlight = properties.getHighlightVariable();
		final boolean printInfo =  properties.isVerbose();
		
		try {
			try {
				// Open the file.
				dataFile = NetcdfDataset.openDataset(inputFilename);
				
				if (printInfo) { // Show metainfo
					printNCInfos(dataFile);
				}
				
				logger.info("");
				logger.info("----------------- Computation Status informations -------------------------");

	    	   	// Determine and validate Variable for height shading
				final Variable heightVar = dataFile.findVariable(variableToParse);
				if (heightVar == null) {
					logger.error("Error: unknown variable name specified: " + variableToParse);
					return;
				} else {
					logger.info("Using variable '" + variableToParse + "' for ElevationGrid rendering: " + heightVar.getDescription());
				}

				if (heightVar.getRank() < 2){
					logger.error("Selected variable contains probably not a grid (not 2- or moredimensional)");
					return;
				} else {
					logger.info("Selected variable has " + heightVar.getRank() + " dimensions: " + heightVar.getDimensionsString());
				}
				
				// Hier die refenzierten Dimensions des Grid auslesen, prüfen, ob es Koordinaten sind
				// (NetCDF-Konvention ist: Koordinaten sind Variablen mit einer gleichnamigen Dimension)
				final List<Dimension> gridDimensions = heightVar.getDimensions();
				
				final Variable[] coordVar = new Variable[4]; // Array mit den beiden Positionsvariablen
				for (int i = 0; i < gridDimensions.size(); i++) {
					final Variable cv = dataFile.findVariable(gridDimensions.get(i).getName()); 
					if ((cv != null) && cv.isCoordinateVariable()){
						// Alles ok, Koordinaten-Variable speichern
						logger.info("grid coordinate #" + i + " is " + cv.getDODSName());
						coordVar[i] = cv;
						
					} else {
						logger.error("Error: Variable dimension is not a coordinate dimension: " + cv.getName());
						logger.error("Selected variable is probably not a grid");
						return;
					}
				}
				
				// Variante 2, um an das Koordinatensystem (und die einzelnen Werte des zugrundeliegenden Grids) zu kommen
				final NetcdfDataset dataSet = new ucar.nc2.dataset.NetcdfDataset(dataFile);
				//dataSet.getCoordinateSystems().get(0).isCoordinateSystemFor(heightVar);
				//dataSet.getCoordinateSystems().get(0).isGeoReferencing();
				double originLat = dataSet.getCoordinateAxes().get(0).read().getDouble(0);
				
				// Die ersten 2 X- und y-Koordinaten, um Abstand und Ursprung zu bestimmen
				final List<Range> start = new ArrayList<Range>(1);
				start.add(new Range(2));
				
				final Array xCoords = coordVar[1].read(start);
				final Array yCoords = coordVar[0].read(start);
				
				// Auslesen der ersten zwei Werte pro Dimension
				final Array Coords0 = coordVar[0].read(start); // time
				final Array Coords1 = coordVar[1].read(start); // zax
				final Array Coords2 = coordVar[2].read(start); // latc
				final Array Coords3 = coordVar[3].read(start); // lonc
				
				// Bereitstellen der NetCDF-Arrays (die ersten zwei Werte)
				final List<Range> startValues = new ArrayList<Range>(4);
				startValues.add(new Range(2));
				startValues.add(new Range(2));
				startValues.add(new Range(2));
				startValues.add(new Range(2));
				final Array grid = heightVar.read(startValues);
				
				// Determine Variable for grid coloring
	    	   	final Variable colorVar;
	    	   	if(variableForColor != null){
	    	   		colorVar = dataFile.findVariable(variableForColor);
	    	   		if (colorVar == null) {
	    	   			logger.error("WARNING: unknown variable name for grid coloring specified: " + variableForColor);
	    	   		} else {
	    	   			logger.info("Using variable '" + variableForColor + "' for grid coloring: " + colorVar.getDescription());
	    	   		}
	    	   	} else {
	    	   		logger.info("Using variable '" + variableToParse + "' for grid coloring: " + heightVar.getDescription());
	    	   		colorVar = null;
	    	   	}
	    	   	
	    	   	// Determine Variable for grid highlighting
	    	   	final Variable interpolVar;
	    	   	if(variableForHighlight != null && !variableForHighlight.equals(variableToParse) && !variableForHighlight.equals(variableForColor)){
	    			interpolVar = dataFile.findVariable(variableForHighlight);
	    			if (interpolVar == null) {
	    	   			logger.error("WARNING: unknown variable for grid highlighting specified: " + variableForHighlight);
	    	   		} else {
	    	   			logger.info("Using variable '" + variableForHighlight + "' for highlighting: " + interpolVar.getDescription());
	    	   		}
	    	   	} else {
	    	   		interpolVar = null;
	    	   	}
				
	   			
				final String generatorMode = properties.getGridGeneration();
				logger.info("Start generation of elevation grid, trying to transfer input grid with mode: " + generatorMode);
				
				final Map<String,double[][]> convertedGrids;
				if (generatorMode.equals(BuilderProperties.GENERATION_FULL)) {
					convertedGrids = createFullGrid(heightVar, colorVar, interpolVar);
				} else {
					logger.error("Error: unknown grid generation mode: " + generatorMode);
					convertedGrids = null;
				}
				
				double[][] coords = convertedGrids.get("coords");
				// TODO Bathy-Grid als PNG mit 512x512 wegschreiben (geeigneter Vielfacher für BFHRefiner)
				
				// TODO: Dann mit BVHRefiner ein progressives Modell baueen
				
				double[][] stride = convertedGrids.get("stride");
				float xSpacing = (xCoords.getFloat(1) - xCoords.getFloat(0)) * (float) stride[0][0];
				float ySpacing = (yCoords.getFloat(1) - yCoords.getFloat(0)) * (float) stride[0][0];

				float xOrigin = xCoords.getFloat(0) - 0.5f * xSpacing;
				float yOrigin = yCoords.getFloat(0) - 0.5f * ySpacing;

				final String origin = String.valueOf(xOrigin) + " " + String.valueOf(yOrigin) + " 0";
		
				logger.info("Finished!");
				
			} catch (Exception e) {
		    	   e.printStackTrace();
			} finally {
				if (dataFile != null){
					dataFile.close(); 
				}
			}
		} catch (Exception e) {// Catch exception if any
			e.printStackTrace();
		}
		
		logger.info("computation time: " + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS) + "ms");
	}

	private Map<String, double[][]> createFullGrid(Variable heightVar, Variable colorVar, Variable interpolVar) throws IOException {
		int arrayDim1 = heightVar.getShape()[0]; //360 fuer iow_topo1
		int arrayDim2 = heightVar.getShape()[1]; //370 fuer iow_topo1
		
		int valueCount = arrayDim1 * arrayDim2;
		logger.info("Input grid has " + valueCount + " values.");
		
		// Bereitstellen der NetCDF-Arrays
		final Array grid = heightVar.read();

		Array gridColor = null;
		if (colorVar != null) {
			if (colorVar != heightVar) {
				gridColor = colorVar.read();
			} else {
				gridColor = grid;
			}
		}
		
		Array gridInterpol = null;
		if (interpolVar != null) {
			gridInterpol = interpolVar.read();
		}
		
		// Auslesen der NetCDF-Arrays
		return null; //readGrids(colorVar, arrayDim1, arrayDim2, valueCount, 1.0, grid, gridColor, gridInterpol);
	}
	
	private static void printParameters(BuilderProperties properties) {
		logger.info("------------------ Specified parameters ------------------------");
		logger.info("Operation mode: " + properties.getMode());
		logger.info("Input grid file: " + properties.getInputfile());
		logger.info("Output X3D file: " + properties.getOutputfile());
		logger.info("Height variable for rendered elevation grid: " + properties.getHeightVariable());
		logger.info("Verbose (Print grid and colorscale details): " + properties.isVerbose());
		logger.info("Positive scale factor: " + properties.getPositiveScale());
		logger.info("Negative scale factor: " + properties.getNegativeScale());
		logger.info("Used colorscale: " + properties.getColorPaletteFile());
		logger.info("Used variable for coloring: " + (properties.getColorVariable() != null ? properties.getColorVariable() : properties.getHeightVariable()));
		logger.info("Used variable for highlighting: " + properties.getHighlightVariable());
		logger.info("X3D template folder: " + properties.getTemplateFolder());
	}
	
	
	public static void printNCFileInfos(final String fileName) {
		NetcdfFile dataFile = null;
		try {
			dataFile = NetcdfDataset.openDataset(fileName);
			printNCInfos(dataFile);
			
		} catch (IOException e) {
			logger.error("Error: Could not open netcdf file '" + fileName + "': " + e.getMessage());
		} finally {
			if (dataFile != null){
				try {
					dataFile.close();
				} catch (IOException e) {
					logger.error("Error: Could not close netcdf file '" + fileName + "': " + e.getMessage());
				}
			}
		}
	}
	
	private static void printNCInfos(final NetcdfFile dataFile) {
		if (dataFile != null) {
			logger.info("--------------------- NetCDF Data Detail Info -----------------------------");
	       	logger.info(dataFile.getDetailInfo());
	    	logger.info("----------------- FileTypeDescription --------------------------");
			logger.info(dataFile.getFileTypeDescription());
			logger.info("---------------------- Variables -------------------------------");
			logger.info(dataFile.getVariables()); //Variable = Mehrdimensionales Array mit Name, Typ und Dimensionen
			logger.info("--------------------- Dimensions -------------------------------");
			logger.info(dataFile.getDimensions()); //Länge der zugehörigen Variablen
			logger.info("------------------ Global Attributes ---------------------------");
			logger.info(dataFile.getGlobalAttributes()); //Metadaten als Key-Value-Paare zu Variablen oder der ganzen File
		}
		else{
			logger.error("Error: Inputfile is null.");
		}
	}
}
