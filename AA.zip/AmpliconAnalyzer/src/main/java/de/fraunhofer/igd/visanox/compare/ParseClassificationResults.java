package de.fraunhofer.igd.visanox.compare;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.math3.util.Pair;

import com.vividsolutions.jts.io.ParseException;

public class ParseClassificationResults {
  protected static final Log logger = LogFactory.getLog(ParseFASTQ.class); 
  
  public static ClassificationResults parseClassification(String path) throws IOException, ParseException{
    assert(!path.endsWith("txt"));
    FileReader freader = new FileReader(new File(path));

    CSVParser parser = new CSVParser(freader, CSVFormat.TDF.withFirstRecordAsHeader());
    List<CSVRecord> recs = parser.getRecords();
    ClassificationResults results = new ClassificationResults(path, Integer.parseInt(recs.get(0).get("SampleNumber")),recs.get(0).get("SampleName"));
    for(CSVRecord current : recs){
      switch (current.get("Level")){
        case "Kingdom": results.addKingdom(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        results.setTotalNumberOfReads(results.getTotalNumberOfReads()+Integer.parseInt(current.get("Reads")));
                        break;
        case "Phylum":  results.addPhylum(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        break;
        case "Class":   results.addClass(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        break;
        case "Order":   results.addOrder(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        break;
        case "Family":  results.addFamily(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        break;
        case "Genus":   results.addGenus(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        break;
        case "Species": results.addSpecies(current.get("Group"),Float.parseFloat(current.get("Percentage")));
                        break;
        default : logger.warn("Didn't find a taxonomic level in file: "+path);
                        break;
      }
    }
    
    return results;
  }
}

/*
 * Stores the classification results of one sample
 * +metadata (such as filename)
 * 
 * No concurrency needed here, so no Atomic variables.
 * 
 */
class ClassificationResults{
  
  String filename;
  int sampleNumber;
  String sampleName;
  int totalNumberOfReads = 0;
  
  public int getTotalNumberOfReads() {
    return totalNumberOfReads;
  }
  public void setTotalNumberOfReads(int totalNumberOfReads) {
    this.totalNumberOfReads = totalNumberOfReads;
  }
  public String getFilename() {
    return filename;
  }
  public int getSampleNumber() {
    return sampleNumber;
  }
  public String getSampleName() {
    return sampleName;
  }
  public List<Pair<String, Float>> getKingdom() {
    return kingdom;
  }
  public List<Pair<String, Float>> getPhylum() {
    return phylum;
  }
  public List<Pair<String, Float>> getClasss() {
    return classs;
  }
  public List<Pair<String, Float>> getOrder() {
    return order;
  }
  public List<Pair<String, Float>> getFamily() {
    return family;
  }
  public List<Pair<String, Float>> getGenus() {
    return genus;
  }
  public List<Pair<String, Float>> getSpecies() {
    return species;
  }
  List<Pair<String,Float>> kingdom = new ArrayList<>();
  List<Pair<String,Float>> phylum = new ArrayList<>();
  List<Pair<String,Float>> classs = new ArrayList<>();
  List<Pair<String,Float>> order = new ArrayList<>();
  List<Pair<String,Float>> family = new ArrayList<>();
  List<Pair<String,Float>> genus = new ArrayList<>();
  List<Pair<String,Float>> species = new ArrayList<>();
  
  public ClassificationResults(String filename, int sampleNumber,
      String sampleName) {
    super();
    this.filename = filename;
    this.sampleNumber = sampleNumber;
    this.sampleName = sampleName;
  }
  public void addKingdom(String name, float percentage){
    kingdom.add(new Pair<String,Float>(name,percentage));
  }
  public void addPhylum(String name, float percentage){
    phylum.add(new Pair<String,Float>(name,percentage));
  }
  public void addClass(String name, float percentage){
    classs.add(new Pair<String,Float>(name,percentage));
  }
  public void addOrder(String name, float percentage){
    order.add(new Pair<String,Float>(name,percentage));
  }
  public void addFamily(String name, float percentage){
    family.add(new Pair<String,Float>(name,percentage));
  }
  public void addGenus(String name, float percentage){
    genus.add(new Pair<String,Float>(name,percentage));
  }
  public void addSpecies(String name, float percentage){
    species.add(new Pair<String,Float>(name,percentage));
  }
  
}
