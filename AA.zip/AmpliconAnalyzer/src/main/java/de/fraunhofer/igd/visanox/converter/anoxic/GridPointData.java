package de.fraunhofer.igd.visanox.converter.anoxic;

import java.util.Optional;

import org.apache.commons.lang.builder.StandardToStringStyle;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.geotools.geometry.jts.JTSFactoryFinder;

import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jtsexample.geom.ExtendedCoordinate;

/**
 * Stores any (relevant) information that there is for one point of the grid
 * 
 * @author Jakob Zabel
 */

public class GridPointData {
  public boolean isStation; //also indicates, if the measurement is real or estimated
  private String stationname;
  private double lon;
  private double lat;
  private Point point;
  private double depth;
  private Optional<String> basinName = Optional.ofNullable(null);
  private Optional<Double> readingH2S_upper = Optional.ofNullable(null); //"tiefe1_H2S" in the iow-file
  //private double readingH2S_lower; //called "tiefe2_H2S" in the iow-file
  private Optional<Double> readingO2_upper = Optional.ofNullable(null); //"tiefe1_O2" in the iow-file
  
  private Optional<Double> concentration_at_H2S_upper = Optional.ofNullable(null); //in the iow-file
  private Optional<Double> concentration_at_O2_upper = Optional.ofNullable(null); //in the iow-file
  
  private Optional<Double> concentration_at_H2S_lower = Optional.ofNullable(null); // in the iow-file
  private Optional<Double> concentration_at_O2_lower = Optional.ofNullable(null); // in the iow-file
  
  private Optional<Double> concentrationMaxH2S = Optional.ofNullable(null); // in the iow-file
  private Optional<Double> concentrationBestO2 = Optional.ofNullable(null); // in the iow-file
  
  /**
   * 
   * @param lat
   * @param lon
   * @param depth
   * @param readingH2S_upper
   * @param readingO2_upper
   * @param basin may be null
   */
  
  public GridPointData(double lon, double lat,
      double depth, double readingH2S_upper, double readingO2_upper, 
      double concentration_at_H2S_upper, double concentration_at_O2_upper, 
      double concentration_at_H2S_lower, double concentration_at_O2_lower,
      double concentrationMaxH2S, double concentrationBestO2, 
      String basin) {
    isStation = false;
    this.lon = lon;
    this.lat = lat;
    com.vividsolutions.jts.geom.GeometryFactory geometryFactory = JTSFactoryFinder.getGeometryFactory();
    this.point = geometryFactory.createPoint(new ExtendedCoordinate(lon,lat, 0, 0));
    this.depth = depth;
    if(readingH2S_upper > -10)this.readingH2S_upper = Optional.of(readingH2S_upper); //usually, iow uses "-999" to say "not measured", but negative values dont make sense in general for water depth
    if(readingO2_upper > -10) this.readingO2_upper = Optional.of(readingO2_upper);
    
    if(readingH2S_upper > -10)this.concentration_at_H2S_upper = Optional.of(concentration_at_H2S_upper); 
    if(readingO2_upper > -10) this.concentration_at_O2_upper = Optional.of(concentration_at_O2_upper);
    
    if(readingH2S_upper > -10)this.concentration_at_H2S_lower = Optional.of(concentration_at_H2S_lower); 
    if(readingO2_upper > -10) this.concentration_at_O2_lower = Optional.of(concentration_at_O2_lower);
    
    if(readingH2S_upper > -10)this.concentrationMaxH2S = Optional.of(concentrationMaxH2S); 
    if(readingO2_upper > -10) this.concentrationBestO2 = Optional.of(concentrationBestO2);
    
    if(basin != null) this.basinName = Optional.of(basin);
    }

  public Optional<String> getBasinName() {
    return basinName;
  }


  public Point getPoint() {
    return point;
  }


  public boolean isStation() {
    return isStation;
  }


  public void setStation(boolean isStation) {
    this.isStation = isStation;
  }


  public String getStationname() {
    return stationname;
  }


  public void setStationname(String stationname) {
    this.stationname = stationname;
  }


  public double getLon() {
    return lon;
  }


  public double getLat() {
    return lat;
  }


  public double getDepth() {
    return depth;
  }


  public Optional<Double> getReadingH2S_upper() { //TODO: es gibt auch 'OptionalDouble'
    return readingH2S_upper;
  }


  public Optional<Double> getReadingO2_upper() {
    return readingO2_upper;
  }
  public Optional<Double> getConcentration_at_H2S_upper() {
    return concentration_at_H2S_upper;
  }

  public Optional<Double> getConcentration_at_O2_upper() {
    return concentration_at_O2_upper;
  }

  public Optional<Double> getConcentration_at_H2S_lower() {
    return concentration_at_H2S_lower;
  }

  public Optional<Double> getConcentration_at_O2_lower() {
    return concentration_at_O2_lower;
  }

  public Optional<Double> getConcentrationMaxH2S() {
    return concentrationMaxH2S;
  }

  public Optional<Double> getConcentrationBestO2() {
    return concentrationBestO2;
  }
  
  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, StandardToStringStyle.SIMPLE_STYLE);
  }
}