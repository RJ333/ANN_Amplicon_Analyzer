package de.fraunhofer.igd.visanox.connection;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

/***
 * A Simple 3D-Point
 */
class Point {
    double x;
    double y;
    double z;

    Point (double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    double distanceTo(double x, double y, double z) {
        return (float)Math.sqrt(Math.pow(x-this.x,2)+Math.pow(y-this.y,2)+Math.pow(z-this.z,2));
    }

    double distanceTo(Point p) {
        return (float)Math.sqrt(Math.pow(p.x-this.x,2)+Math.pow(p.y-this.y,2)+Math.pow(p.z-this.z,2));
    }

    double length() {
        return (float)Math.sqrt(Math.pow(this.x,2)+Math.pow(this.y,2)+Math.pow(this.z,2));
    }

    double heightDistance(Point p) {
        return (float)Math.abs(p.z-this.z);
    }

    Point multiplyBy(double s) {
        Point p = new Point(this.x, this.y, this.z);
        p.x *= s;
        p.y *= s;
        p.z *= s;
        return p;
    }

    Point add(Point s) {
        Point p = new Point(this.x, this.y, this.z);
        p.x += s.x;
        p.y += s.y;
        p.z += s.z;
        return p;
    }

    Point normalize() {
        Point p = new Point(this.x, this.y, this.z);
        return p.multiplyBy((double)1/p.length());
    }

    @Override
    public String toString() {
        return "("+this.x+","+this.y+","+this.z+")";
    }
}

/**
 * Wingman when it comes to detecting collisions in line of sight
 */
public class Connection {
    float[][] map = new float[750][660]; // [lat][lon]
    float density = 0.01f; // length of one step
    Projector p = new Projector(9.016666412353516, 53.50833511352539, 30.983333587646484, 65.99166870117188, 660, 750);

    double heightAtPoint(double lon, double lat) {
        int[] v = p.worldToScreen(lon, lat);
        //System.out.println("coord:  x:"+v[0]+", y:"+v[1]);
        return this.map[v[1]][v[0]];
    }

    boolean areConnected(float minDist, float minRelativeHeight, float fromLon, float fromLat, float fromHeight, float toLon, float toLat, float toHeight) {
        Point from = new Point(fromLon, fromLat, fromHeight);
        Point to = new Point(toLon, toLat, toHeight);

        if (from.distanceTo(to) < minDist) {
            return true;
        }

        Point direction = to.add(from.multiplyBy(-1)).normalize();

        Point walker;

        double maxHeightDistance = from.distanceTo(to)*minRelativeHeight;

        int steps = (int) Math.ceil(from.distanceTo(to)/this.density);

        for (int i = 1; i < steps; i++) {
            walker = from.add(direction.multiplyBy(i*this.density));
            double height = this.heightAtPoint(walker.x, walker.y);
            //System.out.println("coord:  "+walker);
            //System.out.println("height: "+height);
            if (height > walker.z && height - walker.z > maxHeightDistance) {
                return false;
            }
        }
        return true;
    }

    void loadMap() throws IOException {
        loadMap("map.converted.csv");
    }

    void loadMap (String path) throws IOException {
        CSVParser p = new CSVParser(new BufferedReader(new FileReader(path)), CSVFormat.DEFAULT);
        List<CSVRecord> recs = p.getRecords(); int y = 0; int x = 0;
        for (CSVRecord rec : recs) {
            for (String s : rec) {
                this.map[y][x++] = Float.valueOf(s).floatValue();
            }
            x = 0;
            y++;
        }
    }

    /***
     * Prints map to stdout using raw data
     */
    void printMap () {
        for (double lat = 53.50833511352539; lat < 65.99166870117188; lat+=0.2) {
            for (double lon = 9.016666412353516; lon < 30.983333587646484; lon+=0.2) {
                double height = this.heightAtPoint(lon,lat);
                if (height > 500) {
                    System.out.print('█');
                } else if (height > 250) {
                    System.out.print('▓');
                } else if (height > 100) {
                    System.out.print('▒');
                } else if (height > 0) {
                    System.out.print('░');
                }
            }
            System.out.print('\n');
        }
    }

    /***
     * Prints map to stdout using mapped data
     */
    void printMap2 () {
        for (int y = 0; y < 750; y+=10) {
            for (int x = 0; x < 660; x+=5) {
                if (this.map[y][x] > 500) {
                    System.out.print('█');
                } else if (this.map[y][x] > 250) {
                    System.out.print('▓');
                } else if (this.map[y][x] > 100) {
                    System.out.print('▒');
                } else if (this.map[y][x] > 0) {
                    System.out.print('░');
                }
            }
            System.out.print('\n');
        }
    }
}
