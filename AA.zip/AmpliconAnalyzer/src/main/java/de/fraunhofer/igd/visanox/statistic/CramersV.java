package de.fraunhofer.igd.visanox.statistic;

import org.apache.commons.math3.stat.inference.ChiSquareTest;
import org.apache.commons.math3.distribution.ChiSquaredDistribution;

/**
 * Calculates Cramér's V
 */
public class CramersV {
    /**
     * IMPORTANT NOTE: This test has been remodeled, it does NOT test for (in)dependence [neither] of 
     * two variables anymore!
     * The test remodels the contingency table so that the samples are the rows and the data forms
     * the columns. As such, if the test states independence of variables, they are probably correlated!
     * The test statistic used is the bias-corrected 
     * <a href="https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_V">Cramér's V</a> (see last paragraph)
     * The first field in the returned double-array is the p-Value of the null-hypothesis, 
     * that both samples (expected and observed) have been drawn from 
     * the same underlying distribution, tested with Pearson's Chi-Square.
     * 
     * @param sample1 First Sample, i.e. 1st row of contingency table. Sample1.length must be equal to sample2.length !
     * @param sample2 Second Sample, i.e. 2nd row of contingency table
     * @return [0] = chi-Squaretest for goodness-of-fit <br>
     *         [1] = p-Value, using Cramér's V as test statistic and evaluating with Pearson's Chi-Square
     */
    static public double[] remodeledCramers_V_biasCorrected (long sample1[], long sample2[]) {
        assert(sample1.length == sample2.length);
        ChiSquareTest chi_test = new ChiSquareTest();
        double[] results = new double[2];
        results[0] = chi_test.chiSquareTestDataSetsComparison(sample1,sample2);
 
        long num_observations = 0; 
        for(int i = 0; i<sample1.length; i++){
          num_observations+= sample1[i]+sample2[i]; //sum up both samples
        }
        
        //remodel contingency table
        long[][] contingencyTableNew = {sample1,sample2};
        
        double phi_squared = chi_test.chiSquare(contingencyTableNew)/num_observations;
        
        double bias = (((double) sample2.length-1)*(sample1.length-1))/(num_observations-1);
        double phi_tilde_squared = Math.max(0,phi_squared-bias);
        double rowBiasReduced = 2 - 1/num_observations; //shorter form, due to remodeled table leading to two rows (row1: sample1, row2: sample2) anyways
        double columnBiasReduced = sample1.length-1/num_observations*Math.pow(sample1.length-1, 2);
        double correctedCramersV = Math.sqrt(phi_tilde_squared/(Math.min(rowBiasReduced, columnBiasReduced)));
        ChiSquaredDistribution distrFct = new ChiSquaredDistribution(1); //test independence of the two rows (sample1, sample2)
        results[1] = distrFct.cumulativeProbability(correctedCramersV);
        //DEBUG:
        System.out.printf("Sum of observations (both samples): %d"+System.lineSeparator(), num_observations);
        System.out.printf("Chi-square statistics for goodness-of-fit: %f"+System.lineSeparator(), results[0]);
        System.out.printf("phi-square for remodeled contingency table: %f"+System.lineSeparator(), chi_test.chiSquare(contingencyTableNew));
        System.out.printf("The CramerV p-Value (eval with Pearson's chi-square  : %f"+System.lineSeparator(), results[1]);
        return results;
    }
}
