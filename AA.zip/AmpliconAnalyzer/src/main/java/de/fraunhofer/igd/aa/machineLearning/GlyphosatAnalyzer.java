package de.fraunhofer.igd.aa.machineLearning;

import static org.nd4j.linalg.factory.Nd4j.vstack;
import static org.nd4j.linalg.indexing.NDArrayIndex.all;
import static org.nd4j.linalg.indexing.NDArrayIndex.interval;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.WorkspaceMode;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.deeplearning4j.plot.BarnesHutTsne;
import org.jfree.data.xy.XYSeriesCollection;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.fraunhofer.igd.visanox.prepare.CSVReadSpecies;
import scala.Array;



/**
 * This example is intended to be a simple CSV classifier that seperates the training data
 * from the test data for the classification of animals. It would be suitable as a beginner's
 * example because not only does it load CSV data into the network, it also shows how to extract the
 * data and display the results of the classification, as well as a simple method to map the lables
 * from the testing data into the results.
 *
 * @author Clay Graham
 */
public class GlyphosatAnalyzer {

    private static Logger log = LoggerFactory.getLogger(GlyphosatAnalyzer.class);
    private static DataSet testData = new DataSet();
    private static DataSet trainingData = new DataSet();
    private int NUMBER_OF_EXPERIMENT_REPETITIONS;
    
    //number of time points that are used for validation (not seen by the ANN)
    //VALIDATION_QUANTITY * (number of files) = amount of validation data
    private static final int VALIDATION_QUANTITY = 1;
    
    private static int NUMBER_OF_FILES; //4 for rene's data, 1 (atm) for christins data
    
    
    
    public static int[] countRightGuesses = new int[1]; //should initialize the array with zeros
    
    public GlyphosatAnalyzer(int numberOfExp){
      NUMBER_OF_EXPERIMENT_REPETITIONS = numberOfExp;
    }
    
    public static void setNumberOfFiles(int quantity){
      NUMBER_OF_FILES = quantity;
    }
    
    public static void resetGuessCount(){
      countRightGuesses = new int[1];
    }
    
    /**
     * 
     * @param DataSet DL4J puts input and output into one DataSet. Use @CSVReadSpecies 
     * @throws InterruptedException 
     * @throws IOException 
     * @throws FileNotFoundException 
     */
    
    public MultiLayerConfiguration trainANNforAmpliconData(DataSet inputAndOutput, File resultStorage, boolean replicates) throws FileNotFoundException, IOException, InterruptedException{
      //int maxInputs = inputAndOutput.stream().max(Comparator.compare)
      
    log.info("Build model....");
    MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
        //.seed(5) //makes outcome deterministic (reproducible!)
        .iterations(2000)
        .activation(Activation.TANH)
        .weightInit(WeightInit.XAVIER)
        .learningRate(0.1)
        .regularization(true).l2(1e-4)
        .list()
        .layer(0, new DenseLayer.Builder().nIn(inputAndOutput.numInputs()).nOut(25) //numInputs() should be ~688 for now.
            .build())
        .layer(1, new DenseLayer.Builder().nIn(25).nOut(25)
            .build())
        .layer(2, new DenseLayer.Builder().nIn(25).nOut(5).build())
        .layer(3, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
            .activation(Activation.SOFTMAX)
            .nIn(5).nOut(inputAndOutput.numOutcomes()).build()) //numOutcomes() should be 2 for now (1 neuron per class)
        .backprop(true).pretrain(false)
        .trainingWorkspaceMode(WorkspaceMode.SINGLE)
        .build();
    
    //run the model
    MultiLayerNetwork net = new MultiLayerNetwork(conf);
    net.init();
    net.setListeners(new ScoreIterationListener(20));
    
    partitionGroundTruthData(inputAndOutput, replicates); //take out VALIDATION_QUANTITY timepoints for validation (which is testData)
    
    System.out.println("Testdata Labels: "+ System.lineSeparator()+testData.getLabels()+ System.lineSeparator()+
        "Testdata name: " );
    if(testData.getExampleMetaData() != null){
      testData.getExampleMetaData().stream().forEach(x-> System.out.print(x.toString()+","));
    }
    //System.out.println("Trainingdata Labels: "+ System.lineSeparator()+trainingData.getLabels()+ System.lineSeparator());
    try{
      net.fit(trainingData);
    }catch(Exception e){
      System.out.println(e.getStackTrace());
    }
    
    for(int i = 0; i < VALIDATION_QUANTITY; i++){
      //for(int j = 0; j < NUMBER_OF_FILES; j++){
        if(Math.abs(net.output(testData.getFeatureMatrix()).getDouble(2,0) - testData.getLabels().getDouble(2,0)) < 0.5) { //NUMBER_OF_FILES*i+j
          countRightGuesses[0]++;
          System.out.println("RIGHT");
        }else{
          System.out.println("WRONG");
        }
      //}
    }
    //resultEvaluation(inputAndOutput, net); //activate for more console output and an x-y-plot
    
     return conf;
   }
    /**
     * Needs a file in a very specific format!
     * @param resultStorage 3 columns, first: OTU-ID, 2nd: amount OTU has been picked, 3rd: amount of right classifications involving this OTU
     */
    public static void storeAmpliconExperimentResults(File resultStorage, DataSet trainingData) {
      // 1) identify, which otus were picked by the RNG (String "X237" -> int 237)
      List<Integer> OTUsPicked = trainingData.getExampleMetaData().stream().
          map(srlzble ->( Integer.valueOf(((String) srlzble).substring(1)))).collect(Collectors.toList());
//      String newLine = IntStream.range(1,688).boxed().map(number -> new Integer(number).toString()).reduce("", (a,b) -> a+b);
//      newLine+=System.lineSeparator();
      String newLine = "";
      for(int i = 1; i<688;i++){
        if(OTUsPicked.contains(new Integer(i))) {
          newLine+= (countRightGuesses[0]+1)+";"; 
        }else{
          newLine+= 0+";";
        }
      }
      newLine=newLine.substring(0, newLine.length()-1)+System.lineSeparator(); //remove last semicolon
      
      try {
        FileWriter fw = new FileWriter(resultStorage, true);
        fw.write(newLine);
        fw.close();
      } catch (IOException e) {
        e.printStackTrace();
      }      
    }

    
    /**
     * Needs a file with all species in the header, separated by ";".
     * @param resultStorage 3 columns, first: OTU-ID, 2nd: amount OTU has been picked, 3rd: amount of right classifications involving this OTU
     * @throws IOException 
     */
    public static void storeResultsPlainTextSpecies(File resultStorage, DataSet trainingData) throws IOException {
      //read in header to be able to assign results to the species used later on
	BufferedReader fr = new BufferedReader(new FileReader(resultStorage));
	String[] allSpeciesInOrder = fr.readLine().split(";");
	fr.close();
      List<String> OTUsPicked = trainingData.getExampleMetaData().stream().
          map(srlzble ->(String) srlzble).collect(Collectors.toList());
//      String newLine = IntStream.range(1,688).boxed().map(number -> new Integer(number).toString()).reduce("", (a,b) -> a+b);
//      newLine+=System.lineSeparator();
      String newLine = "";
      for(int i = 0; i<allSpeciesInOrder.length;i++){
        if(OTUsPicked.contains(allSpeciesInOrder[i])) {
          newLine+= (countRightGuesses[0])+";"; 
        }else{
          newLine+= 0+";";
        }
      }
      newLine=newLine.substring(0, newLine.length()-1)+System.lineSeparator(); //remove last semicolon
      
      try {
        FileWriter fw = new FileWriter(resultStorage, true);
        fw.write(newLine);
        fw.close();
      } catch (IOException e) {
        e.printStackTrace();
      }      
    }
    /**
     * Visualize the results of the trained net, in the console and as a graph
     * @param inputAndOutput
     * @param net
     * @throws InterruptedException
     */
    public static void resultEvaluation(DataSet inputAndOutput,
        MultiLayerNetwork net) throws InterruptedException {
      Evaluation eval = new Evaluation(2);
      System.out.println("Testing on test samples only");
      //evaluate the model on the test set
      INDArray output2 = net.output(inputAndOutput.getFeatureMatrix()); //output gives a 'guesstimate' to the eval-function for comparison. not necessary
      eval.eval(inputAndOutput.getLabels(), output2);
      log.info(eval.stats());
      //Print the evaluation statistics
      System.out.println(eval.stats());
      
      XYSeriesCollection c = new XYSeriesCollection();
      PlotUtil plot = new PlotUtil();
      INDArray outputPlot = CSVReadSpecies.prepareOutputForPlotting(output2);

      plot.createSeries(c, outputPlot.getRow(0).transpose(), 0, "Control 1");
      plot.createSeries(c, outputPlot.getRow(1).transpose(), 0, "Control 2");
      plot.createSeries(c, outputPlot.getRow(2).transpose(), 0, "Exp 1");
      plot.createSeries(c, outputPlot.getRow(3).transpose(), 0, "Exp 2");
      //plot.createSeries(c, predicted, 0, "Predicted test data");
      plot.plotDataset(c);
      TimeUnit.MINUTES.sleep(12);
    }
    
    /**
     * (old,) no replicates version
     * @param inputAndOutput
     */
    private static void partitionGroundTruthData(DataSet inputAndOutput) {
      int numExamples = inputAndOutput.numExamples();
      //SplitTestAndTrain temp = inputAndOutput.splitTestAndTrain(numExamples-VALIDATION_QUANTITY, new Random()); //40 out of 64 for training (=10 out of 16 time points)
      //SplitTestAndTrain temp = inputAndOutput.splitTestAndTrain(numExamples-VALIDATION_QUANTITY); // should only take out last time point
//      testData = temp.getTest();
//      trainingData = temp.getTrain();
      int leaveOutIndex = new Random().nextInt(numExamples);
      //DEBUG
      //leaveOutIndex = numExamples;
      INDArray firstHalfFeatures = null;
      INDArray firstHalfLabels = null;
      INDArray secondHalfFeatures = null;
      INDArray secondHalfLabels = null;
      
      //get(dim1,dim2,....,dimN)     
      if(leaveOutIndex == 0){
        testData.setFeatures(inputAndOutput.getFeatures().getRow(0));
        testData.setLabels(inputAndOutput.getLabels().getRow(0));
      }else{
        firstHalfFeatures = inputAndOutput.getFeatures().get(interval(0, leaveOutIndex), all());
        firstHalfLabels = inputAndOutput.getLabels().get(interval(0, leaveOutIndex), all());
      }
      
      if(!(leaveOutIndex==numExamples)){
        if(leaveOutIndex+1==numExamples){
          secondHalfFeatures = inputAndOutput.getFeatures().getRow(leaveOutIndex);
          secondHalfLabels = inputAndOutput.getLabels().getRow(leaveOutIndex);
        }else{
          secondHalfFeatures = inputAndOutput.getFeatures().get(interval(leaveOutIndex+1, numExamples), all());
          secondHalfLabels = inputAndOutput.getLabels().get(interval(leaveOutIndex+1, numExamples), all());
        }
      }
      if(leaveOutIndex == 0){
        trainingData.setFeatures(secondHalfFeatures);
        trainingData.setLabels(secondHalfLabels);
      }
      
      testData.setFeatures(inputAndOutput.getFeatures().getRow(leaveOutIndex));
      testData.setLabels(inputAndOutput.getLabels().getRow(leaveOutIndex));
      
      if(!(leaveOutIndex==numExamples || leaveOutIndex == 0)){
      trainingData.setFeatures(vstack(firstHalfFeatures,secondHalfFeatures));
      trainingData.setLabels(vstack(firstHalfLabels,secondHalfLabels));
	} else { // leaveOutIndex == numExamples or == 0
	    if (leaveOutIndex == numExamples) {
		trainingData.setFeatures(firstHalfFeatures);
		trainingData.setLabels(firstHalfLabels);
	    } else { // index == 0
		trainingData.setFeatures(secondHalfFeatures);
		trainingData.setLabels(secondHalfLabels);
	    }
	}
      if(trainingData.numExamples()==0){
	  System.out.println("empty training set! Split failed");
      }
      return;
    }
    /**
     * (new) version with replicates (3 assumed)
     * Because replicates seem to be missing randomly in the data, a block of FIVE points get taken out for test data,
     * so that no replicate stays in the training data 
     * ASSUMPTION 1: 3 replicates
     * 
     * @param inputAndOutput
     */
    private static void partitionGroundTruthDataReplicates(DataSet inputAndOutput) {
	      int numExamples = inputAndOutput.numExamples();
	      assert(numExamples > 5);
	      int[] leaveOutArray;
	      int leaveOutIndex = new Random().nextInt(numExamples);
	      boolean beginning = (leaveOutIndex <6);
	      boolean end = (numExamples - leaveOutIndex < 6);
	      boolean mid = !(beginning||end);
	      
	      if(beginning){
		  leaveOutArray = new int[]{0,1,2,3,4};
		  testData.setFeatures(inputAndOutput.getFeatures().getRows(leaveOutArray));
		  testData.setLabels(inputAndOutput.getLabels().getRows(leaveOutArray));
		  trainingData.setFeatures(inputAndOutput.getFeatures().getRows(Array.range(5, numExamples)));
		  trainingData.setLabels(inputAndOutput.getLabels().getRows(Array.range(5, numExamples)));
	      }
	      if(end){
		  leaveOutArray = new int[]{numExamples-5,numExamples-4,numExamples-3,numExamples-2,numExamples-1};
		  testData.setFeatures(inputAndOutput.getFeatures().getRows(leaveOutArray));
		  testData.setLabels(inputAndOutput.getLabels().getRows(leaveOutArray));
		  trainingData.setFeatures(inputAndOutput.getFeatures().getRows(Array.range(0, numExamples-6)));
		  trainingData.setLabels(inputAndOutput.getLabels().getRows(Array.range(0, numExamples-6)));
	      }
	      
	      if(mid){
	      //DEBUG
	      //leaveOutIndex = numExamples;
	      INDArray firstHalfFeatures = null;
	      INDArray firstHalfLabels = null;
	      INDArray secondHalfFeatures = null;
	      INDArray secondHalfLabels = null;
	      
	      leaveOutArray = new int[]{leaveOutIndex-2,leaveOutIndex-1,leaveOutIndex,leaveOutIndex+1,leaveOutIndex+2};
	      testData.setFeatures(inputAndOutput.getFeatures().getRows(leaveOutArray));
	      testData.setLabels(inputAndOutput.getLabels().getRows(leaveOutArray));
	      
	      firstHalfFeatures = inputAndOutput.getFeatures().get(interval(0,leaveOutIndex-2)); //what about "all()"?
	      firstHalfLabels = inputAndOutput.getLabels().get(interval(0,leaveOutIndex-2));
	      
	      secondHalfFeatures = inputAndOutput.getFeatures().get(interval(leaveOutIndex+3, numExamples));
	      secondHalfLabels = inputAndOutput.getLabels().get(interval(leaveOutIndex+3, numExamples));
	           
	      trainingData.setFeatures(vstack(firstHalfFeatures,secondHalfFeatures));
	      trainingData.setLabels(vstack(firstHalfLabels,secondHalfLabels));
	            
	      if(trainingData.numExamples()==0){
		  System.out.println("empty training set! Split failed");
	      }
	      }
	      return;
	    }
    
    /**
     * Splits the available data into a training and validation set.
     * Adapt for different experiments
     * Changes static variables outside its scope (it has side effects)
     * @param inputAndOutput {@code DataSet} containing all available data 
     * @param replicates assumes 3 replicates 
     */
    public static void partitionGroundTruthData(DataSet inputAndOutput, boolean replicates) {
	if(replicates) {
	    partitionGroundTruthDataReplicates(inputAndOutput);
	}else{
	    partitionGroundTruthData(inputAndOutput);
	}
    }
    
    /**
     * t-SNE (t-Distributed Stochastic Neighbor Embedding) is a dimensionality reduction technique
     * like PCA/NDMS etc.
     * @param data
     * @throws IOException file doesnt exist on desktop?
     */
    
    public static void tDistributedStochasticNeighborEmbedding(DataSet data) throws IOException{
      assert(data.getExampleMetaData()!= null);
      assert(data.getExampleMetaData().get(0).getClass() == String.class);
      
      
      BarnesHutTsne tsne = new BarnesHutTsne.Builder()
          .setMaxIter(100).theta(0.5)
          .normalize(false)
          .learningRate(500)
          .useAdaGrad(false)
//          .usePca(false)
          .build();
      File picture = new File(System.getProperty("user.dir")+System.getProperty("file.separator")+"Desktop"+System.getProperty("file.separator"));
      tsne.fit(data.getFeatures());
      tsne.saveAsFile((List<String>) (List<?>) data.getExampleMetaData(), picture.getAbsolutePath());
    }
}
