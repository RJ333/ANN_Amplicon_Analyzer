package de.fraunhofer.igd.visanox.converter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ucar.ma2.Array;
import ucar.ma2.IndexIterator;
import ucar.ma2.Range;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;
import ucar.nc2.dataset.NetcdfDataset;

/**
 * Analysieren und Konvertieren von netcdf-Daten (4D-Simulationsdaten) im Projekt VisAnox.
 * 
 * Die Konfiguration des Builders kann entweder programmatisch mit BuilderProperties-Objekt, per converter.properties-Datei 
 * oder per Kommandozeilenaufruf erfolgen.
 *
 * @author Thomas Ruth, Fraunhofer IGD Rostock
 */
public class NetCdfVolumeReader {
	private static final Log logger = LogFactory.getLog(NetCdfVolumeReader.class); 

	private final BuilderProperties properties;

	public static void main(String args[]) {
		logger.info("VisAnox netCdfVolumeReader: Reads simulation data from NetCDF files.\n(C) 2014, Fraunhofer IGD Rostock\n");
    	
		if (args.length == 1 && !args[0].endsWith(".properties")) { // Only print informations, no conversion
			printNCFileInfos(args[0]);
			
		} else {

			final BuilderProperties properties;
			final BuilderProperties propsFromFile;
			// Wenn abweichender Pfad zu Config-Datei angegeben, diese nutzen!
			if ((args.length == 1) && args[0].endsWith(".properties")){
				propsFromFile = configureFromPropertyFile(args[0]);
			} else {
				propsFromFile = configureFromPropertyFile(null);
			}
			if (propsFromFile != null) {
				properties = propsFromFile;
			} else { // No converter.properties file found/used
				properties = new BuilderProperties(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
			}

			if (BuilderProperties.MODE_INFO.equals(properties.getMode())) {
				// Only print informations, no conversion
				printNCFileInfos(properties.getInputfile());
				return;
			} else {
				// do the full blown conversion job...
				final NetCdfVolumeReader x3dBuilder = new NetCdfVolumeReader(properties);
				x3dBuilder.readInputGrid();
			}

		}
	}
	
	/**
	 * Konstruktor, der ein Konfigurationsobjekt erwartet. Damit ist die eingebettete Nutzung des Builders moeglich.
	 *
	 * @param properties Konfiguration für die Konvertierung 
	 */
	public NetCdfVolumeReader(final BuilderProperties builderProperties) {
		this.properties = builderProperties;
		
		if (properties == null) {
			throw new RuntimeException("Builder properties are missing.");
		}

		if (properties.isVerbose()) {
			printParameters(properties);
		}
	}

	/**
	 * Konstruktor, der im Classpath die Datei 'converter.properties' mit der Konfiguration des Builders erwartet.
	 */
	public NetCdfVolumeReader() {
		this(configureFromPropertyFile(null));
	}
	
	private static BuilderProperties configureFromPropertyFile(final String propertyFilePath) {
		final Properties props = new Properties();
		Reader configReader = null;
		BuilderProperties properties = null;
		try {
			if (propertyFilePath != null) {
				configReader = new FileReader(propertyFilePath);
			} else {
				configReader = new FileReader("converter.properties");
			}
			props.load(configReader);
			logger.info("Found configuration file 'converter.properties', ignoring command line configuration.");
			if (!props.isEmpty()){
				properties = new BuilderProperties();
				BeanUtils.populate(properties, props);
			} else {
				logger.info("Converter property file is empty. Continuing with command line parameter configuration.");
			}
		} catch (FileNotFoundException e) {
			logger.info("Could not find converter property file. Continuing with command line parameter configuration.");
		} catch (IOException e) {
			logger.error("Error: Could not read converter property file.");
		} catch (IllegalAccessException e) {
			logger.error("Error: Could not configure converter from property file (maybe wrong/unknown property names?): " + e.getMessage() );
		}
	      catch (InvocationTargetException e) {
		    logger.error("Error: Could not configure converter from property file (maybe wrong/unknown property names?): " + e.getMessage() );
	    }
		if (configReader != null) {
			try {
				configReader.close();
			} catch (IOException e) {
				logger.error("Error: Could not close converter property file.");
			}
		}
		return properties;
	}

	/**
	 * Methode zum Auslesen eines 4D-Arrays (time, Z, lat, lon) aus einer .nc Datei und Schreiben 
	 * eines PNG-Slices zum Einbinden als VolumeData in X3DOM-Modellen.
	 */
	public void readInputGrid() {
		final long startTime = System.nanoTime();
		
		NetcdfFile dataFile = null;
		
		final String inputFilename = properties.getInputfile();
		final String variableToParse = properties.getHeightVariable();
		final boolean printInfo =  properties.isVerbose();
		final String outputFilename = properties.getOutputfile();
		
		try {
			try {
				// Open the file.
				dataFile = NetcdfDataset.openDataset(inputFilename);
				
				if (printInfo) { // Show metainfo
					printNCInfos(dataFile);
				}
				
				logger.info("");
				logger.info("----------------- Computation Status informations -------------------------");

	    	   	// Determine and validate Variable for volume grid values
				final Variable volumeVar = dataFile.findVariable(variableToParse);
				if (volumeVar == null) {
					logger.error("Error: unknown variable name specified: " + variableToParse);
					return;
				} else {
					logger.info("Using variable '" + variableToParse + "' for volume data generation: " + volumeVar.getDescription());
				}

				if (volumeVar.getRank() < 3){
					logger.error("Selected variable contains probably not a volume (not 3- or moredimensional)");
					return;
				} else {
					logger.info("Selected variable has " + volumeVar.getRank() + " dimensions: " + volumeVar.getDimensionsString());
				}
				
				// Hier die refenzierten Dimensions des Grid auslesen, prüfen, ob es Koordinaten sind
				// (NetCDF-Konvention ist: Koordinaten sind Variablen mit einer gleichnamigen Dimension)
				final List<Dimension> gridDimensions = volumeVar.getDimensions();
				
				final Variable[] coordVar = new Variable[4]; // Array mit den beiden Positionsvariablen
				for (int i = 0; i < gridDimensions.size(); i++) {
					final Variable cv = dataFile.findVariable(gridDimensions.get(i).getName()); 
					if ((cv != null) && cv.isCoordinateVariable()){
						// Alles ok, Koordinaten-Variable speichern
						logger.info("grid coordinate #" + i + " is " + cv.getDODSName());
						coordVar[i] = cv;
						
					} else {
						logger.error("Error: Variable dimension is not a coordinate dimension: " + cv.getName());
						logger.error("Selected variable is probably not a volume data set");
						return;
					}
				}
				
				// Variante 2, um an das Koordinatensystem (und die einzelnen Werte des zugrundeliegenden Grids) zu kommen
				final NetcdfDataset dataSet = new ucar.nc2.dataset.NetcdfDataset(dataFile);
				//dataSet.getCoordinateSystems().get(0).isCoordinateSystemFor(heightVar);
				//dataSet.getCoordinateSystems().get(0).isGeoReferencing();
				double originLat = dataSet.getCoordinateAxes().get(0).read().getDouble(0);
				
				// Die ersten 2 X- und y-Koordinaten, um Abstand und Ursprung zu bestimmen
				final List<Range> start = new ArrayList<Range>(1);
				start.add(new Range(2));

				// Auslesen der ersten zwei Werte pro Dimension
				final Array Coords0 = coordVar[0].read(start); // time
				final Array Coords1 = coordVar[1].read(start); // zax
				final Array Coords2 = coordVar[2].read(start); // latc
				final Array Coords3 = coordVar[3].read(start); // lonc
				
				// Test: Bereitstellen des NetCDF-Arrays (je die ersten zwei Index-Werte)
				final List<Range> startValues = new ArrayList<Range>(4);
				startValues.add(new Range(2));
				startValues.add(new Range(2));
				startValues.add(new Range(2));
				startValues.add(new Range(2));
				final Array grid = volumeVar.read(startValues);
				
				// Tiefenwerte
				final Array depths = coordVar[1].read();
				
				final String generatorMode = properties.getGridGeneration();
				logger.info("Start generation of volume data sets, trying to transfer input array with mode: " + generatorMode);
				
				for (int step = 0; step < volumeVar.getShape()[0]; step++) {				
					final List<float[][]> convertedVolume;
					if (generatorMode.equals(BuilderProperties.GENERATION_FULL)) {
						convertedVolume = createFullVolume(volumeVar, step);
					} else {
						logger.error("Error: unknown volume generation mode: " + generatorMode);
						convertedVolume = null;
					}
					
					// Alle Slices eines Volumes in ein grosses PNG schreiben (dass dann als ImageTextureAtlas verwendet werden kann)
					PNGSliceWriter pngWriter = new PNGSliceWriter();
					pngWriter.writeVolume(convertedVolume, String.format(outputFilename, step));
				}
				
				logger.info("Finished!");
				
			} catch (Exception e) {
		    	   e.printStackTrace();
			} finally {
				if (dataFile != null){
					dataFile.close(); 
				}
			}
		} catch (Exception e) {// Catch exception if any
			e.printStackTrace();
		}
		
		logger.info("computation time: " + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS) + "ms");
	}

	/**
	 * Liest einen konkreten Datenwürfel aus einer netCDF-Datei aus. time ist der Index des ersten Slices (hier der Zeitpunkt).
	 */
	private List<float[][]> createFullVolume(Variable volumeVar, int time) throws IOException {
		int arrayDim0 = volumeVar.getShape()[0]; // 10 fuer BalticSea1nm.mean.z.nc (time)
		int arrayDim1 = volumeVar.getShape()[1]; //100 fuer BalticSea1nm.mean.z.nc (zax)
		int arrayDim2 = volumeVar.getShape()[2]; //378 fuer BalticSea1nm.mean.z.nc (latc)
		int arrayDim3 = volumeVar.getShape()[3]; //396 fuer BalticSea1nm.mean.z.nc (lonc)
		
		int valueCount = arrayDim1 * arrayDim2 * arrayDim3;
		logger.info("Input array has " + valueCount + " values.");
		logger.info("Slices (dimension 'z'): " + arrayDim1 + ", cell values per slice: " + (arrayDim2 * arrayDim3));
		
		// Bereitstellen der NetCDF-Arrays
		final List<float[][]> result = new ArrayList<float[][]>();

		// Aktuell nur den 1. Zeitpunkt nehmen (time=0), per erstem slice()
		try {
			// In Tiefenscheiben die Werte auslesen
			for (int d = 0; d < arrayDim1; d++) {
				if (properties.isVerbose()) {
					logger.info("Read slice " + d + " from volume:");
				}
				final Array grid = volumeVar.slice(0, time).slice(0, d).read();
				// Auslesen der NetCDF-Arrays
				float[][] array = readSlice(arrayDim2, arrayDim3, grid);
				//float[][] array = readSliceFlipped(arrayDim2, arrayDim3, arrayDim2 * arrayDim3, grid);
		
				result.add(array);
			}

			return result;
		} catch(Exception ex){
			ex.printStackTrace(); // TODO ordentlich machen
		}
		return null; // Nur im Fehlerfall
	}

	/**
	 * Auslesen eines einzelnen 2-dim. Slices aus einem NetCDF-Array in ein Java-Array.
	 */
	private static float[][] readSlice(final int arrayDim1, final int arrayDim2, final Array grid) {
		final float[][] array = new float[arrayDim1][arrayDim2];
		int count = 0;
		
		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			for (int i = 0; i < arrayDim1; i++) {
				for (int j = 0; j < arrayDim2; j++) {
					array[i][j] = iter.getFloatNext();
					if (!Float.isNaN(array[i][j])) {
						//logger.info(array[i][j]);
						count++;
					}
				}
			}
		}
		logger.info("Valid cell values (not NaN): " + count);
		return array;
	}

	/**
	 * Auslesen eines einzelnen NetCDF-Arrays in ein Java-Array, dabei Vertauschen von Zeilen und Spalten (180 Grad-Rotation).
	 */
	private static float[][] readSliceFlipped(final int arrayDim1, final int arrayDim2, final int valueCount, final Array grid) {
		final float[][] array = new float[arrayDim1][arrayDim2];
		int count = 0;

		if (grid != null) {
			// Alternativ auch mit Range.Iterator iter = ranges.get(0).getIterator() machbar...
			int idx1 = arrayDim1 - 1;
			int idx2;
			for (int i = 0; i < valueCount; i = i + arrayDim2) {
				idx2 = arrayDim2 - 1;
				for (int j = 0; j < arrayDim2; j++) {
					// Vertauschen von Zeilen und Spalten 
					array[idx1][idx2] = grid.getFloat(i + j);
					
					if (!Float.isNaN(array[idx1][idx2])) {
						//logger.info(array[i][j]);
						count++;
					}
					
					idx2--;
				}
				idx1--;
			}
		}
		logger.info("Valid cell values (not NaN): " + count);
		return array;
	}
	
	/**
	 * Auslesen eines einzelnen 3-dim. NetCDF-Arrays in ein Java-Array.
	 */
	private static double[][][] readGrid(final int arrayDim1, final int arrayDim2, final int arrayDim3, final Array grid) {
		final double[][][] array = new double[arrayDim1][arrayDim2][arrayDim3];

		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			for (int i = 0; i < arrayDim1; i++) {
				for (int j = 0; j < arrayDim2; j++) {
					for (int k = 0; j < arrayDim3; k++) {
						array[i][j][k] = iter.getDoubleNext();
					}
				}
			}
		}
		return array;
	}
	
	private static void printParameters(BuilderProperties properties) {
		logger.info("------------------ Specified parameters ------------------------");
		logger.info("Operation mode: " + properties.getMode());
		logger.info("Input grid file: " + properties.getInputfile());
		logger.info("Output X3D file: " + properties.getOutputfile());
		logger.info("Height variable for rendered elevation grid: " + properties.getHeightVariable());
		logger.info("Verbose (Print grid and colorscale details): " + properties.isVerbose());
		logger.info("Positive scale factor: " + properties.getPositiveScale());
		logger.info("Negative scale factor: " + properties.getNegativeScale());
		logger.info("Used colorscale: " + properties.getColorPaletteFile());
		logger.info("Used variable for coloring: " + (properties.getColorVariable() != null ? properties.getColorVariable() : properties.getHeightVariable()));
		logger.info("Used variable for highlighting: " + properties.getHighlightVariable());
		logger.info("X3D template folder: " + properties.getTemplateFolder());
	}
	
	
	public static void printNCFileInfos(final String fileName) {
		NetcdfFile dataFile = null;
		try {
			dataFile = NetcdfDataset.openDataset(fileName);
			printNCInfos(dataFile);
			
		} catch (IOException e) {
			logger.error("Error: Could not open netcdf file '" + fileName + "': " + e.getMessage());
		} finally {
			if (dataFile != null){
				try {
					dataFile.close();
				} catch (IOException e) {
					logger.error("Error: Could not close netcdf file '" + fileName + "': " + e.getMessage());
				}
			}
		}
	}
	
	private static void printNCInfos(final NetcdfFile dataFile) {
		if (dataFile != null) {
			logger.info("--------------------- NetCDF Data Detail Info -----------------------------");
	       	logger.info(dataFile.getDetailInfo());
	    	logger.info("----------------- FileTypeDescription --------------------------");
			logger.info(dataFile.getFileTypeDescription());
			logger.info("---------------------- Variables -------------------------------");
			logger.info(dataFile.getVariables()); //Variable = Mehrdimensionales Array mit Name, Typ und Dimensionen
			logger.info("--------------------- Dimensions -------------------------------");
			logger.info(dataFile.getDimensions()); //Länge der zugehörigen Variablen
			logger.info("------------------ Global Attributes ---------------------------");
			logger.info(dataFile.getGlobalAttributes()); //Metadaten als Key-Value-Paare zu Variablen oder der ganzen File
		}
		else{
			logger.error("Error: Inputfile is null.");
		}
	}
}
