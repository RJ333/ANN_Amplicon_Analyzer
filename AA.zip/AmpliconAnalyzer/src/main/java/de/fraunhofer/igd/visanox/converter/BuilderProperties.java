package de.fraunhofer.igd.visanox.converter;

public final class BuilderProperties {
	public final static String GENERATION_FULL ="full"; 
	public final static String GENERATION_TILED ="tiled";
	public final static String GENERATION_REDUCED ="reduced";
	
	public final static String MODE_CONVERT ="convert";
	public final static String MODE_INFO ="info";
	
	private String inputfile;
	private String outputfile;
	private String mode = MODE_INFO;
	private boolean verbose = true; 
	private String heightVariable;
	private boolean heightValues = true;
	private boolean useGeoNodes = true;
	private String positiveScale;
	private String negativeScale;
	private String colorPaletteFile;
	private String colorPaletteFilePath;
	private String templateFolder;
	private String colorVariable;
	private String highlightVariable;
	private String gridGeneration = GENERATION_FULL; // full, tiled oder reduced
	private long maxNumberOfGridNodes = 65536;
	private boolean shading;
	private long smoothing = 0;
	private double waterTransparency = 0.5;


	BuilderProperties() {
		// Empty constructor, used for population with BeanUtils
	}
	
	public BuilderProperties(String inputfile, String outputfile,
			String heightVariable, String verbose, String positiveScale,
			String negativeScale, String colorPaletteFile,
			String templateFolder) {
		this.inputfile = inputfile;
		this.outputfile = outputfile;
		this.heightVariable = heightVariable;
		this.verbose = Boolean.parseBoolean(verbose);
		this.positiveScale = positiveScale;
		this.negativeScale = negativeScale;
		this.colorPaletteFile = colorPaletteFile;
		this.templateFolder = templateFolder;
	}

	public String getInputfile() {
		return inputfile;
	}

	public void setInputfile(String inputfile) {
		this.inputfile = inputfile;
	}

	public String getOutputfile() {
		return outputfile;
	}

	public void setOutputfile(String outputfile) {
		this.outputfile = outputfile;
	}

	public String getHeightVariable() {
		return heightVariable;
	}

	public void setHeightVariable(String heightVariable) {
		this.heightVariable = heightVariable;
	}

	public boolean isHeightValues() {
		return heightValues;
	}

	public void setHeightValues(boolean heightValues) {
		this.heightValues = heightValues;
	}

	/**
	 * @return the useGeoNodes
	 */
	public boolean isUseGeoNodes() {
		return useGeoNodes;
	}

	/**
	 * @param useGeoNodes the useGeoNodes to set
	 */
	public void setUseGeoNodes(boolean useGeoNodes) {
		this.useGeoNodes = useGeoNodes;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getPositiveScale() {
		return positiveScale;
	}

	public void setPositiveScale(String positiveScale) {
		this.positiveScale = positiveScale;
	}

	public String getNegativeScale() {
		return negativeScale;
	}

	public void setNegativeScale(String negativeScale) {
		this.negativeScale = negativeScale;
	}

	public String getColorPaletteFile() {
		return colorPaletteFile;
	}

	public void setColorPaletteFile(String colorPaletteFile) {
		this.colorPaletteFile = colorPaletteFile;
	}

	public String getColorPaletteFilePath() {
		return colorPaletteFilePath;
	}

	public void setColorPaletteFilePath(String colorPaletteFilePath) {
		this.colorPaletteFilePath = colorPaletteFilePath;
	}

	public String getTemplateFolder() {
		return templateFolder;
	}

	public void setTemplateFolder(String templateFolder) {
		this.templateFolder = templateFolder;
	}

	public String getColorVariable() {
		return colorVariable;
	}

	public void setColorVariable(String colorVariable) {
		this.colorVariable = colorVariable;
	}

	public boolean isVerbose() {
		return verbose;
	}
	
	public void setVerbose(boolean verbose) {
		this.verbose = verbose;
	}

	public String getGridGeneration() {
		return gridGeneration;
	}

	public void setGridGeneration(String gridGeneration) {
		this.gridGeneration = gridGeneration;
	}

	public long getMaxNumberOfGridNodes() {
		return maxNumberOfGridNodes;
	}

	public void setMaxNumberOfGridNodes(long maxNumberOfGridNodes) {
		this.maxNumberOfGridNodes = maxNumberOfGridNodes;
	}

	public String getHighlightVariable() {
		return highlightVariable;
	}
	
	public void setHighlightVariable(String highlightVariable) {
		this.highlightVariable = highlightVariable;
	}

	public boolean isShading() {
		return shading;
	}

	public void setShading(boolean shading) {
		this.shading = shading;
	}

	public long getSmoothing() {
		return smoothing;
	}

	public void setSmoothing(long smoothing) {
		this.smoothing = smoothing;
	}

	public double getWaterTransparency() {
		return waterTransparency;
	}

	public void setWaterTransparency(double waterTransparency) {
		this.waterTransparency = waterTransparency;
	}
}
