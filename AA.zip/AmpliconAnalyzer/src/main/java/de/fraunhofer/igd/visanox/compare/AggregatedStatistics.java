package de.fraunhofer.igd.visanox.compare;

import java.util.ArrayList;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.math3.util.Pair;

/**
 * This class is for aggregating the statistics of N samples (files)
 * It is a singleton
 */
public class AggregatedStatistics{
  private static AggregatedStatistics instance;
  
  //DEBUG: static Arraylist size potential error source!
  private static ArrayList<Pair<Integer,Double>> meanEntropy = new ArrayList<Pair<Integer,Double>>(500);
  
  //empty, private constructor
  private AggregatedStatistics(){};
  
  public static synchronized AggregatedStatistics getInstance () {
    if (AggregatedStatistics.instance == null) {
      AggregatedStatistics.instance = new AggregatedStatistics ();
    }
    return AggregatedStatistics.instance;
  }
  
  
  
  public static synchronized void addEntropy(double[] entropy){
    int n = 0;
    double oldEntropyMean = 0;
    for(int i = 0; i < entropy.length; i++){
      try{
        n = meanEntropy.get(i).getKey();
        oldEntropyMean = meanEntropy.get(i).getSecond();
        //idea for next line:
        //instead of building a new Pair-object, save references (needs to be objects instead of primitives) 
        //and update them (would be n and oldEntropy)
        meanEntropy.set(i,new Pair<Integer,Double>(++n,oldEntropyMean*n/++n+entropy[i]/++n));  
      }catch(Exception e){
        meanEntropy.add(i,new Pair<Integer,Double>(new Integer(1),new Double(entropy[i])));        
      }
    }
  }

  public double[] getMeanEntropy() {
    Double[] result = {};
    result = meanEntropy.stream().map(pair -> pair.getSecond()).collect(Collectors.toList()).toArray(result);
    return ArrayUtils.toPrimitive(result);
  }
  
  
}
