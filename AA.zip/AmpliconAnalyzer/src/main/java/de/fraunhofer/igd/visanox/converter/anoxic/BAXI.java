package de.fraunhofer.igd.visanox.converter.anoxic;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.vividsolutions.jts.io.ParseException;

public class BAXI {
	protected static final Log logger = LogFactory.getLog(BAXI.class); 
  
  /**
   * Searches the given directory recursively for .vis-Files and calculates
   * either anoxic or suboxic indices (Baltic anoxic situation index).
   * 
   * @param visFilesPath no files, has to exist in filesystem, access needed etc
   * @param path to .vis-Files from IOW
   * @param anoxic true => use H2S measurements; false => use low-O2-measurements
   * @return The key-String contains date in year and month: YYYYMM , the Value-Double is the BAXI which belongs to that .vis-File
   * @throws IOException thrown, when directory/files cant be read/accessed, dont exist etc.
   * @throws ParseException thrown, when .vis-Files not in expected format
   */
   public Map<String,Double> readAllVisFiles(String basinsPath, String visFilesPath, boolean anoxic) throws IOException, ParseException{
    Map<String,Double> results = new HashMap<String, Double>();
    File directory = new File(visFilesPath);
    if(!directory.exists()) throw new IllegalArgumentException("directory "+directory+" does not exist");
    if(!directory.isDirectory()) throw new IllegalArgumentException(directory+" is not a directory");
    
    String[] extension =  {"vis"};
    Collection<File> files = FileUtils.listFiles(directory,extension, true);  
    
    // TODO: Optimieren, ohne VolumeInterpolation-Objekt arbeitenm, sondern mit den statischen Methoden (siehe JUnit-Test) 
    for(File file : files){
      if(logger.isDebugEnabled()){
        logger.debug("-------------------------------------------------");
        logger.debug("Reading file: "+file.getName().substring(2,8)); //info gathered for IOW
        logger.debug("-------------------------------------------------");
      }
      VolumeInterpolation volInt = new VolumeInterpolation(basinsPath, file.getAbsolutePath());    
      results.put(file.getName().substring(2,8), computeDefinedBAXI(volInt.getInputData(), anoxic)); //cut the "tf" the filenames start with      
    }
    return results;
  }
   
   /**
    * Naive implementation, until further feedback from experts on that matter.
    * 
    * @param upperIntervalC Concentration measured on upper (lower depth) limit of layer
    * @param lowerIntervalC Concentration measured on lower (greater depth) limit of layer
    * @param maxC max/'best' concentration measured
    * @return maxC - simple implementation at the moment
    */
    private double computeConcentrationFactor(double upperIntervalC,
        double lowerIntervalC, double maxC) {
      if (upperIntervalC < 0 || lowerIntervalC < 0 || maxC < 0) {
        logger.warn("Negative concentration value used! C.-factor set to 1");
        return 1;
      }
      if (maxC <= 0.0d) {
        return 1;
      } else {
        return maxC;
      }
    }
  
  /**
   * input data, choose between anoxic (H2S-measurements) and suboxic (O2).
   * One BAXI-value itself is completely meaningless, it only makes some sense
   * in comparison to other BAXI-values. It is intended to roughly positively 
   * correlate with the volume of H2S/low-O2 water layers in the baltic sea.
   * There is no guarantee for this correlation, as the data available is usually
   * sparse and the calculation rather arbitrary.
   * 
   * ASSUMPTION 1: An O2-measurement always implies an H2S-measurement at the same location
   * 
   * @param measurements needs to be filled
   * @param anoxic true => use H2S measurements; false => use low-O2-measurements
   * @return indicator, mostly in the range of 3-10
   */
  public double computeDefinedBAXI(List<GridPointData> measurements, boolean anoxic){
    List<Double> upperValues = new ArrayList<>(measurements.size());
    List<Double> lowerValues = new ArrayList<>(measurements.size());
    
    //use distance of begin of H2S-layer to ground (the latter should always have a value present)
	if (anoxic) {
	  double concentrationFactor = 1;
		for (int i = 0; i < measurements.size(); i++) {
			final GridPointData gridPoint = measurements.get(i);
			//if(logger.isDebugEnabled()) logger.debug("Reading station: "+gridPoint.getStationname()); //info gathered for IOW
			
			if(gridPoint.getConcentrationMaxH2S().isPresent()){
			  concentrationFactor = computeConcentrationFactor(gridPoint.getConcentration_at_H2S_upper().get(), 
          gridPoint.getConcentration_at_H2S_lower().get(), 
          gridPoint.getConcentrationMaxH2S().get());
			  if(logger.isDebugEnabled()) logger.debug("H2S max concentration used: "+ gridPoint.getConcentrationMaxH2S().get());
			}
			lowerValues.add(i, gridPoint.getDepth()*concentrationFactor);  
			if (gridPoint.getReadingH2S_upper().isPresent()) {
				upperValues.add(i, gridPoint.getReadingH2S_upper().get()*concentrationFactor);  
			} else {
				upperValues.add(i, 0d);
			}
		}
	}
    
    //use distance from begin of H2S-layer to begin of low-O2-layer
	if (!anoxic) {
	  double concentrationFactor = 1;
		for (int i = 0; i < measurements.size(); i++) {
			final GridPointData gridPoint = measurements.get(i);
			
			if(gridPoint.getConcentrationBestO2().isPresent()){
			  concentrationFactor = computeConcentrationFactor(gridPoint.getConcentration_at_O2_upper().get(), 
          gridPoint.getConcentration_at_O2_lower().get(), 
          gridPoint.getConcentrationBestO2().get());
			  if(logger.isInfoEnabled()) logger.info("O2 best concentration used: "+ gridPoint.getConcentrationBestO2().get());
			}
			
			if (gridPoint.getReadingH2S_upper().isPresent()) {
				lowerValues.add(i, gridPoint.getReadingH2S_upper().get()*concentrationFactor);  //H2S is ok here, the actual O2-value would be better (didnt know it was present in the .vis-files)
			} else {
				lowerValues.add(i, gridPoint.getDepth()*concentrationFactor);
			}
			if (gridPoint.getReadingO2_upper().isPresent()) {
				upperValues.add(i, gridPoint.getReadingO2_upper().get()*concentrationFactor);
			} else {
				upperValues.add(i, 0d);
			}
		}
	}
    
    return computeGeneralBAXI(upperValues, lowerValues, measurements);
  }
  
  
  /**
   * This function computes a rough index which shall indicate the current presence of a 
   * certain fluid in the baltic sea, such as H2S.
   * The result is intended to correlate positively with the amount of that fluid in the
   * baltic sea. As the calculation is rather simple, this is unlikely to be very
   * precise or correlated with a high (close to 1) correlation coefficient at all.
   * 
   * 
   * Both inputs need to be of the same size, missing (zero, not null) values are only
   * allowed in the upperValues parameter. The number of missing values in relation 
   * to all values is used in the calculation, so do NOT skip measurements where the
   * fluid was missing.
   * 
   * @param upperValues measurements of the fluid to be indexed
   * @param lowerValues lower boundary (another fluid/bathymetry)
   * @return
   */
  private double computeGeneralBAXI(List<Double> upperValues, List<Double> lowerValues, List<GridPointData> stations){
	if (upperValues.size() != lowerValues.size() || upperValues.isEmpty() || upperValues == null)
		throw new IllegalArgumentException("Both lists need to be of the same size and not empty or null!");
	double result = 0;

    int numberOfMeasurements = 0;
    for(int i = 0; i<upperValues.size(); i++){
      if(upperValues.get(i)!=null&&upperValues.get(i)!=0.0d){
        if(lowerValues.get(i)<=upperValues.get(i)){ //inconsistent with 'reality', H2S-layer always below suboxic layer       	
        	logger.warn(String.format(
        			"lower value not greater than upper value (keep in mind, it is water depth!): lowerValue=%2.2f, upperValue=%2.2f,	station: "+stations.get(i).getStationname(),
        			lowerValues.get(i),
        			upperValues.get(i)));        	
        } else{
          result += lowerValues.get(i) - upperValues.get(i); //remember, its about water depths, so larger value == deeper
          numberOfMeasurements++;
        }
      }
    }
    
    return (result * numberOfMeasurements / upperValues.size()) / 75; //this number is just a scaling factor (change as you like)
  }
}
