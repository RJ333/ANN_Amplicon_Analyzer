package de.fraunhofer.igd.aa.machineLearning;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RefineryUtilities;
import org.nd4j.linalg.api.ndarray.INDArray;

/**
 * 
 * Code from DL4J Examples (SingleTimestepRegressionExample)
 *
 */
public class PlotUtil {

  public XYSeriesCollection createSeries(XYSeriesCollection seriesCollection, INDArray data, int offset, String name) {
    int nRows = data.rows();
    XYSeries series = new XYSeries(name);
    for (int i = 0; i < nRows; i++) {
        series.add(i + offset, data.getDouble(i));
    }

    seriesCollection.addSeries(series);

    return seriesCollection;
}

/**
 * Generate an xy plot of the datasets provided.
 */
  public void plotDataset(XYSeriesCollection c) {

    String title = "Amplicon Classification";
    String xAxisLabel = "sampling days";
    String yAxisLabel = "Neuron activation levels";
    PlotOrientation orientation = PlotOrientation.VERTICAL;
    boolean legend = true;
    boolean tooltips = false;
    boolean urls = false;
    JFreeChart chart = ChartFactory.createXYLineChart(title, xAxisLabel, yAxisLabel, c, orientation, legend, tooltips, urls);

    // get a reference to the plot for further customisation...
    final XYPlot plot = chart.getXYPlot();

    // Auto zoom to fit time series in initial window
    final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
    rangeAxis.setAutoRange(true);

    JPanel panel = new ChartPanel(chart);

    JFrame f = new JFrame();
    f.add(panel);
    f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    f.pack();
    f.setTitle("Training Data");

    RefineryUtilities.centerFrameOnScreen(f);
    f.setVisible(true);
}

}
