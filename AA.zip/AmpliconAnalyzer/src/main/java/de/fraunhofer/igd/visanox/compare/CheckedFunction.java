package de.fraunhofer.igd.visanox.compare;

import java.util.concurrent.ExecutionException;

@FunctionalInterface
interface CheckedFunction<T, R> {
   R apply(T t) throws InterruptedException,ExecutionException;
}