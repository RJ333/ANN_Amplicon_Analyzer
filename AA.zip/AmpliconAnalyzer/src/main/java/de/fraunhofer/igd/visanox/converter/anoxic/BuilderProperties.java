package de.fraunhofer.igd.visanox.converter.anoxic;

public final class BuilderProperties {
	public final static String GENERATION_FULL ="full"; 
	public final static String GENERATION_TILED ="tiled";
	public final static String GENERATION_REDUCED ="reduced";
	
	public final static String MODE_CONVERT ="convert";
	public final static String MODE_INFO ="info";
	
	private String inputfile;
	private String outputfile;
	private String mode = MODE_INFO;
	private boolean verbose = true; 
	private String heightVariable;
	private boolean heightValues = true;
	private boolean useGeoNodes = true;
	private boolean generateLandscape = false;
	private boolean generateCubewall = true;
	private String positiveScale;
	private String negativeScale;
	private String templateFolder;
	private String landMaskVariable;
	private String latVariable;
	private String lonVariable;
	private String basinsPath;
	private String iowDataFilePath;
	
	private String gridGeneration = GENERATION_FULL; // full, tiled oder reduced
	private long maxNumberOfGridNodes = 65536;
	private boolean shading = true;
	private long smoothing = 0;
	private double waterTransparency = 0.5;


	BuilderProperties() {
		// Empty constructor, used for population with BeanUtils
	}
	
	public BuilderProperties(String inputfile, String outputfile,
			String heightVariable, String landMaskVariable, String latVariable, String lonVariable, 
			boolean verbose, String positiveScale, String negativeScale, String templateFolder) {
		this.inputfile = inputfile;
		this.outputfile = outputfile;
		this.heightVariable = heightVariable;
		this.landMaskVariable = landMaskVariable;
		this.latVariable = latVariable;
		this.lonVariable = lonVariable;
		this.verbose = verbose;
		this.positiveScale = positiveScale;
		this.negativeScale = negativeScale;
		this.templateFolder = templateFolder;
	}

	public String getInputfile() {
		return inputfile;
	}

	public void setInputfile(String inputfile) {
		this.inputfile = inputfile;
	}

	public String getOutputfile() {
		return outputfile;
	}

	public void setOutputfile(String outputfile) {
		this.outputfile = outputfile;
	}

	public String getHeightVariable() {
		return heightVariable;
	}

	public void setHeightVariable(String heightVariable) {
		this.heightVariable = heightVariable;
	}

	public boolean isHeightValues() {
		return heightValues;
	}

	public void setHeightValues(boolean heightValues) {
		this.heightValues = heightValues;
	}

	/**
	 * @return the useGeoNodes
	 */
	public boolean isUseGeoNodes() {
		return useGeoNodes;
	}

	/**
	 * @param useGeoNodes the useGeoNodes to set
	 */
	public void setUseGeoNodes(boolean useGeoNodes) {
		this.useGeoNodes = useGeoNodes;
	}

	public boolean isGenerateLandscape() {
		return generateLandscape;
	}

	public void setGenerateLandscape(boolean generateLandscape) {
		this.generateLandscape = generateLandscape;
	}
	
	public boolean isGenerateCubewall() {
		return generateCubewall;
	}

	public void setGenerateCubewall(boolean generateCubewall) {
		this.generateCubewall = generateCubewall;
	}
	
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getPositiveScale() {
		return positiveScale;
	}

	public void setPositiveScale(String positiveScale) {
		this.positiveScale = positiveScale;
	}

	public String getNegativeScale() {
		return negativeScale;
	}

	public void setNegativeScale(String negativeScale) {
		this.negativeScale = negativeScale;
	}

	public String getTemplateFolder() {
		return templateFolder;
	}

	public void setTemplateFolder(String templateFolder) {
		this.templateFolder = templateFolder;
	}

	public String getLandMaskVariable() {
		return landMaskVariable;
	}

	public void setLandMaskVariable(String landMaskVariable) {
		this.landMaskVariable = landMaskVariable;
	}

	public boolean isVerbose() {
		return verbose;
	}
	
	public void setVerbose(boolean verbose) {
		this.verbose = verbose;
	}

	public String getGridGeneration() {
		return gridGeneration;
	}

	public void setGridGeneration(String gridGeneration) {
		this.gridGeneration = gridGeneration;
	}

	public long getMaxNumberOfGridNodes() {
		return maxNumberOfGridNodes;
	}

	public void setMaxNumberOfGridNodes(long maxNumberOfGridNodes) {
		this.maxNumberOfGridNodes = maxNumberOfGridNodes;
	}

	public String getLatVariable() {
		return latVariable;
	}
	
	public void setLatVariable(String latVariable) {
		this.latVariable = latVariable;
	}

	public String getLonVariable() {
		return lonVariable;
	}
	
	public void setLonVariable(String lonVariable) {
		this.lonVariable = lonVariable;
	}
	
	public String getBasinsPath() {
		return basinsPath;
	}

	public void setBasinsPath(String basinsPath) {
		this.basinsPath = basinsPath;
	}

	public String getIowDataFilePath() {
		return iowDataFilePath;
	}

	public void setIowDataFilePath(String iowDataFilePath) {
		this.iowDataFilePath = iowDataFilePath;
	}

	public boolean isShading() {
		return shading;
	}

	public void setShading(boolean shading) {
		this.shading = shading;
	}

	public long getSmoothing() {
		return smoothing;
	}

	public void setSmoothing(long smoothing) {
		this.smoothing = smoothing;
	}

	public double getWaterTransparency() {
		return waterTransparency;
	}

	public void setWaterTransparency(double waterTransparency) {
		this.waterTransparency = waterTransparency;
	}
}
