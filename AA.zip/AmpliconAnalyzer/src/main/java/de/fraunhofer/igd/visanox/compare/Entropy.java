package de.fraunhofer.igd.visanox.compare;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;


import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scala.collection.immutable.Seq;

import static java.util.stream.Collectors.*;
import static java.lang.Math.*;

public class Entropy {
  
  private static final Log logger = LogFactory.getLog(Entropy.class); 
  
  public static final float THRESHOLD_MIN_SEQ_LENGTH = 0.5f;
  public static final float MIN_VALUES_FOR_ENTROPY_CALC = 0.01f;
  
  private static final float MAX_ALLOWED_ENTROPY = 0.05f; //minimal Entropy for a 'flat' profile  
  private static int readsTotal;
  private static List<List<Sequence>> nodesMED = new ArrayList<List<Sequence>>();
  private static List<List<Sequence>> unfinishedNodesMED1 = new ArrayList<List<Sequence>>();
  private static List<List<Sequence>> unfinishedNodesMED2 = new ArrayList<List<Sequence>>();
  
  /**
   * Computes an entropy profile for a list of sequences (one sample)
   * IMPORTANT: method shortens sequences!! (no copy is made (yet))
   * Two kinds of cuts are made, to remove entropy over too few samples (probably inaccurate) and
   * to remove too short samples (usually pairing errors, containing mostly/only 'N')
   * @param sequences may not be empty/null!
   * @return entropy of each column, beginning with sequences.get(0)
   */
  public static double[] calculateShannonEntropy(List<Sequence> sequences){
    assert(sequences.size() > 0);
    readsTotal = sequences.size();
    return calculateShannonEntropy(sequences, THRESHOLD_MIN_SEQ_LENGTH, MIN_VALUES_FOR_ENTROPY_CALC);
    }
  
  
  //calculate entropy with T1-and T2-filtering
  //private and masked to be used with flexible parameters
  private static double[] calculateShannonEntropy(List<Sequence> sequences, 
      float minSequenceLength, float minColumnValues){
    sequences = t1Filtering(sequences, minSequenceLength); //also sorts the sequences
    final int seqSize = sequences.size(); //size after filtering
    if(seqSize<readsTotal*0.8) logger.warn("Cut out more than 20% of sequences while calculating Entropy, possible overlong sequences in dataset");
    
    final int maxSeqLength = sequences.get(0).length;
    
    char currentNucleotide = 'n';
    int columnLength;
    int shortestSequenceLength = sequences.stream().
        map(a -> a.length).
        min((a,b)->{ return (int) Math.signum(b-a); }).
        orElseGet(()-> {return 0;});
    
    double[] result = new double[shortestSequenceLength];
    int i = 0;
    for(;i<shortestSequenceLength; i++){
      columnLength = 0;
      Map<Character,Integer> letters = new HashMap<Character,Integer>(sequences.size());
      for(int j = 0; j<sequences.size(); j++){
        try{
          currentNucleotide = sequences.get(j).rawRead.charAt(i);
          columnLength++;
        }catch(Exception e){
          break;
        }
        if(letters.containsKey(currentNucleotide)){
          letters.put(currentNucleotide, (letters.get(currentNucleotide)+1));
        }else{
          letters.put(currentNucleotide, 1);
        }
      }
      //Threshold2-filtering (column length)
      if(columnLength < minColumnValues * sequences.size()) break;
      result[i] = letters.entrySet().stream().
          map(a->(double) a.getValue()).
          reduce(0d,(a,b)->letters.entrySet().size() == 1 ? a+0 : //happens, if entire column contains only one base. This would lead to division by zero in the (now) else-branch
            a+(b/seqSize)*abs((log(b/seqSize)/log(letters.entrySet().size()))
              ));
    }
    return ArrayUtils.subarray(result, 0, i); //trim
  }
  
  //computing entropy without T1-/T2-filtering, but with the purpose of creating MED-nodes
  private static double[] calculateShannonEntropyMED(List<Sequence> sequences){
      sequences = sequences.stream().sequential().sorted((a,b)->{ return (int) Math.signum(b.length-a.length);}).collect(Collectors.toList()); //sorted() uses .length for comparison?
      final int seqSize = sequences.size();
      final int maxSeqLength = sequences.get(0).length; //due to sorted
      final int maxCommonLength = sequences.get(sequences.size()-1).length; // shortest sequence at the bottom: its length is the last 'full' column for all sequences
      
      char currentNucleotide = 'n';
      int columnLength;
      double[] result = new double[maxSeqLength];
      int i = 0;
      for(;i<maxCommonLength; i++){
        columnLength = 0;
        Map<Character,Integer> letters = new HashMap<Character,Integer>(sequences.size());
        for(int j = 0; j<sequences.size(); j++){
          try{
            currentNucleotide = sequences.get(j).rawRead.charAt(i);
            columnLength++;
          }catch(Exception e){
            break;
          }
          if(letters.containsKey(currentNucleotide)){
            letters.put(currentNucleotide, (letters.get(currentNucleotide)+1));
          }else{
            letters.put(currentNucleotide, 1);
          }
        }
        //Create profile only 
        //if(columnLength < maxCommonLength) break;
        result[i] = letters.entrySet().stream().
            map(a->(double) a.getValue()).
            reduce(0d,(a,b)->letters.entrySet().size() == 1 ? a+0 : //happens, if entire column contains only one base. This would lead to division by zero in the (now) else-branch
              a+(b/seqSize)*Math.abs((Math.log(b/seqSize)/Math.log(letters.entrySet().size()))
                ));
      }
      assert(sequences.size()==ArrayUtils.subarray(result, 0, i).length);
      return ArrayUtils.subarray(result, 0, i); //trim      
  }
  
  /**
   * Iterating MED-node-construction (non-recursive to avoid stack overflows).
   * @param inputList
   * @return
   */
  public static List<List<Sequence>> splitReads(List<Sequence> inputList){
    unfinishedNodesMED1.add(inputList);
    boolean useCollection1 = true;
    while(!unfinishedNodesMED1.isEmpty()||!unfinishedNodesMED2.isEmpty()){
      ListIterator<List<Sequence>> it;
      if(useCollection1) {
        it = unfinishedNodesMED1.listIterator();
      }else{
        it = unfinishedNodesMED2.listIterator();
      }
      while(it.hasNext()){
        List<Sequence> currentList = it.next();
        splitByEntropy(currentList,useCollection1);
        }
      if(useCollection1) {
        unfinishedNodesMED1 = new ArrayList<List<Sequence>>(); 
      }else{
        unfinishedNodesMED2 = new ArrayList<List<Sequence>>();
      }
      useCollection1 = !useCollection1; //switch collection to avoid concurrency problems (with it.remove())
    }
    return nodesMED;
  }
  
  /**
   * Creates MED-nodes (Read doi:10.1038/ismej.2014.195 by Eren et. al)
   * Parameter names (m,n,N,...) according to the paper.
   * @param inputList List of Sequences, will be split 
   * @return List of Nodes, each containing 'atomic' List of Sequences, meaning, 
   * their entropy is at no point higher than a certain threshold
   */
  private static void splitByEntropy(List<Sequence> inputList, boolean useCollection1){
    assert(!inputList.isEmpty());
    assert(MAX_ALLOWED_ENTROPY>=0); //m = threshold, above which the sequences will still be split.
    
    System.out.println("Lines in: "+inputList.size());
    
    //inputList = t1Filtering(inputList,THRESHOLD_MIN_SEQ_LENGTH);
    double[] entropy = calculateShannonEntropyMED(inputList);
    double maxEntropy = DoubleStream.of(entropy).max().orElse(0d);
    if(maxEntropy < MAX_ALLOWED_ENTROPY){ //finished. cancel criteria 1, entropy "low enough"
      nodesMED.add(inputList);
      return;
    } else {
      int index = IntStream.range(0, entropy.length).filter(e -> entropy[e] == maxEntropy).reduce(0, (a,b)->b); // "=="-operator for double primitive working as intended?
      System.out.println("Splitting at base: "+(index+1));
      Character[] bases = new Character[inputList.size()];
      
      Map<Character,List<Sequence>> newNodes = new HashMap<>(5);
      //AtomicReference<Character> currentChar = new AtomicReference<Character>();
      char currentChar;
      //AtomicReference currentSequence = new AtomicReference<Sequence>();
      Sequence currentSequence;
      
      
      //gather column, on which the split is to be made
      for (int i = 0; i < inputList.size(); i++) {
        currentSequence = inputList.get(i);
        if(currentSequence.length<index) logger.fatal("Too short sequence in function 'splitByEntropy', probably a 'NNN...NN'-sequence", 
            new IllegalArgumentException("Too short sequence in function 'splitByEntropy': "+
            currentSequence));
        try{
        currentChar = ((Sequence) currentSequence).rawRead.charAt(index); //2DO: crashes for "NNN"-sequences!
        }catch(Exception e){
          e.printStackTrace();
          currentChar = 'x';
        }
        newNodes.computeIfAbsent(currentChar, k -> new ArrayList<Sequence>()).add(currentSequence);
      }
      
      List<List<Sequence>> result = new ArrayList<>();
      for(Entry<Character,List<Sequence>> currentEntry : newNodes.entrySet()){
//        if(currentEntry.getValue().size() < readsTotal*MIN_VALUES_FOR_ENTROPY_CALC){ //
//          nodesMED.add(currentEntry.getValue());
//        }else{
        if(useCollection1){
          unfinishedNodesMED1.add(currentEntry.getValue());
        }else{
          unfinishedNodesMED2.add(currentEntry.getValue());
          }
      }
      return;   
      //count each base (or N)
//      Map<Character,Integer> amounts = Stream.of(bases).collect(
//           groupingBy(
//              idx -> bases[index],
//              reducing(
//                  ((int) 0),
//                   a ->1,
//                  Integer::sum)));

//      Map<Character,List<Integer>> newNodes = IntStream.range(0, inputList.size()).collect(
//          (Supplier<Character>) Collectors.groupingBy(
//              i->inputList.get((int) i).rawRead.charAt(index), //go through column 'index'
//              Collectors.mapping(
//                  s->inputList.get((int) s),
//                  Collectors.toList())));
    }    
  }
  
  /**
   * Threshold1-filtering (sequence length)
   * NOTE: case of one/a few very long reads in the whole file NOT done yet (perhaps use median/mean?)
   * @param sequences
   * @param minLength
   * @return Collectors.toList returns an ArrayList, thus the specified return type
   */
  private static List<Sequence> t1Filtering(List<Sequence> sequences, float minLength){
    assert(!sequences.isEmpty());
    assert(minLength < 1 && minLength > 0);
    sequences.stream().sorted(); //should be sorted by seq. length (seq. overrides 'compareTo')
    final int min = (int) Math.floor(sequences.get(0).length*minLength);
    return sequences.stream().filter(p -> p.length > min).collect(Collectors.toList()); //why is there no "enclosing scope"-error here?
    }

}
