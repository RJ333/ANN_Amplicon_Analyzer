package de.fraunhofer.igd.visanox.prepare;

import static org.nd4j.linalg.factory.Nd4j.create;
import static org.nd4j.linalg.factory.Nd4j.vstack;
import static org.nd4j.linalg.factory.Nd4j.zeros;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.math3.util.Pair;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * 
 * @author jzabel
 *
 */
public class CSVReadSpecies {
  
  private static Logger log = LoggerFactory.getLogger(CSVReadSpecies.class);
  
//  private static long distinctStations;
  private static int neededBits;
  private static Map<String,ArrayList<Integer>> mapping = new HashMap<>();

  private Map<String,Pair<Integer,Double>> otus = new LinkedHashMap<>();
  //
  public static int[] CHOSEN_OTU_INDICES = {220,147,138,180,307,293,100,255,95,292};
  public static final int NUMBER_OF_OTUS_TO_KEEP = 20;//CHOSEN_OTU_INDICES.length;
  public static final int NUMBER_OF_SPECIES_TOTAL = 360;
  private static final boolean DEBUG = false;
  private boolean[] whichFeaturesToTake= new boolean[687];
  
  public static final String[] TOP_OTUS = {"Parvibaculum_Rhodobiaceae_Rhizobiales_Alphaproteobacteria_Proteobacteria","Hyphomonas_Hyphomonadaceae_Caulobacterales_Alphaproteobacteria_Proteobacteria","Gallaecimonas_Unknown-Family_Gammaproteobacteria-Incertae-Sedis_Gammaproteobacteria_Proteobacteria","Massilia_Oxalobacteraceae_Burkholderiales_Betaproteobacteria_Proteobacteria","Thalassobaculum_Rhodospirillaceae_Rhodospirillales_Alphaproteobacteria_Proteobacteria","Sphingopyxis_Sphingomonadaceae_Sphingomonadales_Alphaproteobacteria_Proteobacteria","Caulobacter_Caulobacteraceae_Caulobacterales_Alphaproteobacteria_Proteobacteria","Rhizobium_Rhizobiaceae_Rhizobiales_Alphaproteobacteria_Proteobacteria","Brevundimonas_Caulobacteraceae_Caulobacterales_Alphaproteobacteria_Proteobacteria","Sphingomonas_Sphingomonadaceae_Sphingomonadales_Alphaproteobacteria_Proteobacteria"};

  /**
   * primitive parsing at the moment, may be expanded if more data comes in
   * @param station
   * @return
   */
  private static String parseStationName(String station){
    return station.substring(4, 7);
  }
  
  /**
   *  determines {@link NUMBER_OF_OTUS_TO_KEEP} random features (species)
   */
  public void intizializeRandomFeaturesArray(){
    assert(NUMBER_OF_OTUS_TO_KEEP<NUMBER_OF_SPECIES_TOTAL);
    int countDown = NUMBER_OF_OTUS_TO_KEEP;
    Random rng = new Random();
    whichFeaturesToTake = new boolean[NUMBER_OF_SPECIES_TOTAL];
    int index;
    while(countDown > 0){
      index = rng.nextInt(NUMBER_OF_SPECIES_TOTAL);
      if(!whichFeaturesToTake[index]) {
        whichFeaturesToTake[index] = true;
        countDown--;
      }
    }
  }
  
  /**
   * puts the OTUs registered in CHOSEN_OTU_INDICES into the array which determines, which OTUs are picked
   */
  
  public void setChosenFeaturesArray(){
      for(int i = 0; i< CHOSEN_OTU_INDICES.length; i++){
	  int index = CHOSEN_OTU_INDICES[i]-1;
	  whichFeaturesToTake[index]=true;
      }
  }
  
  public void testFeatureSeparately(int index){
      whichFeaturesToTake = new boolean[NUMBER_OF_SPECIES_TOTAL];
      int speciesNr = CHOSEN_OTU_INDICES[index];
      whichFeaturesToTake[speciesNr-1]=true;
  }
  
  /**
   * Assumption1: OTUs ordered in decreasing order of importance (score)
   * @param index
   */
  public void testIncreasingNumberOfFeatures(int index){
      whichFeaturesToTake = new boolean[NUMBER_OF_SPECIES_TOTAL];
      for(int i = 0; i < index+1; i++){
	  whichFeaturesToTake[CHOSEN_OTU_INDICES[i]-1] = true;
      }
  }
  
  public void testRandomFeature(){
      whichFeaturesToTake = new boolean[NUMBER_OF_SPECIES_TOTAL];
      Random rng = new Random();
      int index = rng.nextInt(NUMBER_OF_SPECIES_TOTAL);
      while(ArrayUtils.contains(CHOSEN_OTU_INDICES, index)){
	  index = rng.nextInt(NUMBER_OF_SPECIES_TOTAL);
      }
      whichFeaturesToTake[index-1]=true;
  }
  
  /**
   * looks up TOP_OTU species' names and assigns their indices to CHOSEN_OTU_INDICES
   */
  public void findSpeciesIndices(){
      
  }
  
  public void takeAllFeatures(){
      Arrays.fill(whichFeaturesToTake, true);
  }
  
  /**
   * Builds a dictionary for stationNames in the {@code mapping} hashmap, 
   * as a binary representation for the neural net. Does not use more bits than necessary
   * @param list list of metaData. May contain duplicates. MUST CONTAIN Strings
   */
  private static void initializeStationMapping(List<String> list){
    
    neededBits = calcNeededBits(list);
    //BitSet bs = new BitSet(entities.size());
    int j = 0;
    for(int i = 0; i< list.size(); i++){ //cast from long to int no problem...?
      if(!mapping.containsKey(parseStationName(list.get(i)))){
        byte encoding = new Integer(j).byteValue(); //counts up binary
        j++;
        ArrayList<Integer> bits = new ArrayList<Integer>(neededBits);
        for(int k = 0; k<neededBits;k++){
          bits.add(getBit(k,encoding));
        }
        mapping.put(parseStationName((String) list.get(i)),bits);
      }    
    }
  }
  
  /**
   * Needs to find out the unique station names!
   * @param list
   * @return
   */
  private static int calcNeededBits(List<String> list){
    long distinctStations = list.stream().map(s -> parseStationName(s)).distinct().count();
    return new Double(Math.ceil(Math.log(distinctStations)/Math.log(2))).intValue(); //using log base change, b/c no log for base 2 available
  }
  
  //get a specific bit
  private static int getBit(int position, byte input)
  {
     return ((input >> position) & 1) == 1 ? 1 : 0;
  }
  
  /**
   * Reads csv-file from species
   * @param path
   * @return
   * @throws IOException
   */
  public Iterable<CSVRecord> readFile(String path) throws IOException{
  Reader reader = new FileReader(path);
  Iterable<CSVRecord> records = CSVFormat.EXCEL.parse(reader);
  return records;
  }
  
  //public Iterable<CSVRe>
  
  /**
   * Hardcoded encoding of stations as features for neural network input,
   * e.g.: AT1 -> 0,1,0.
   * @param dataSet must have (non null!) metaData attached to it, type MUST BE String 
   * @return expanded dataSet. needs log2(metaData.length) extra lines
   */
  private static void encodeMetaDataIntoInput(DataSet dataSet){
    assert(!dataSet.getExampleMetaData().isEmpty());
    assert(dataSet.getExampleMetaData().get(0).getClass().equals(String.class)); //check, if MetaData is of type String
    
    initializeStationMapping(dataSet.getExampleMetaData().stream().map(s -> (String) s).collect(Collectors.toList()));
    Iterator<Serializable> dsIter = dataSet.getExampleMetaData().iterator();
    float[][] encodedStations = new float[dataSet.getExampleMetaData().size()][neededBits];
    Serializable current; 
    for(int i = 0; i < encodedStations.length; i++){
      current = (String) dsIter.next();
      for(int j = 0; j < neededBits; j++){
        encodedStations[i][j] = mapping.get((parseStationName((String) current))).get(j);
      }      
    }
    System.out.println("Encoded array: "+ Arrays.toString(encodedStations));
    INDArray originalData = dataSet.getFeatures().transpose();
    INDArray additionalData = Nd4j.create(encodedStations).transpose();
    dataSet.setFeatures(vstack(originalData,additionalData).transpose());
  }
  
  
  
  
  /**
   * Necessary to prepare data for deeplearning4J.
   * Please note, that this is for a species file, not for FASTQ-Data itself. 
   * 
   * @param path .csv-file, NOT a FASTQ-File!
   * @param offSetForClassChange sample number, at which classification switches (samples are assumed to be ordered)
   * @param replicates true means, that there are 3 replicates of each sequencing sample
   * @return data in the form that DL4J needs
   * @throws IOException file at {@code path} cant be opened, does not exist, ...
   */
  
  public DataSet readAndTransposeAmpliconData(File file,
      int offSetForClassChange,boolean[] timepoints, boolean replicates) throws IOException {
    // IOW-data is in 'wrong' format, csv-files need to be transposed
    CSVParser csvParser = new CSVParser(new FileReader(file),
        CSVFormat.DEFAULT.withDelimiter(';'));
    List<CSVRecord> records = csvParser.getRecords();
    assert (!records.isEmpty());
    assert (offSetForClassChange < records.get(0).size());
    assert (NUMBER_OF_OTUS_TO_KEEP < records.size());
    if(replicates) offSetForClassChange = (offSetForClassChange-1)*3+1; // 3 replicates per sequencing time point
    
    if (offSetForClassChange <= -1)
      offSetForClassChange = records.size() + 2; // -1 means, only control
                                                 // samples, so dont change the
                                                 // class
    

    INDArray input = zeros(records.get(0).size() - 1, records.size()); // one
                                                                       // neuron
                                                                       // per
                                                                       // species
    INDArray output = zeros(records.get(0).size() - 1, 2); // even though there
                                                           // are only 2 classes
                                                           // (control/glyph),
                                                           // it needs two
                                                           // output neurons
                                                           // (see XOR-Example)
    List<String> metaData = new ArrayList<>(100);

    // records = selectMostAbundantOTUs(records, file);
    // records = selectOTUsRandomly(records);
    int i = 0, j = 0;
    for (CSVRecord line : records) { // ~687 -> input neurons, i
      if (i > 0 && whichFeaturesToTake[i - 1]) {
        for (String species : line) { // 16 (+label) -> sample nr., j
          if (i > 0 && j == 0)
            metaData.add(records.get(i).get(0)); // i>0: leave out first column                                                       
          if (i > 0 && j > 0 && timepoints[j-1]) {
              try{
            input.putScalar(new int[] { j - 1, i - 1 },Double.valueOf(species.replace(',', '.'))); // i>0 for header skipping first  column (species ames) 
              }catch(Exception e){
        	  System.out.println("Floating point number has multiple points (commas)");
              }
            output.putScalar(new int[] { j - 1, 0 },
                offSetForClassChange > j ? 1 : 0); // neuron 0 == control data,
                                                   // true until j reaches
                                                   // offset, then class changes
            output.putScalar(new int[] { j - 1, 1 },
                offSetForClassChange > j ? 0 : 1); // neuron 1 == glyph (not
                                                   // control data), true after
                                                   // offset reached
          }
          j++;
        }//end: FOR species
      }//end: IF
      j = 0;
      i++;
    }//end: FOR records
    DataSet dataSet = new DataSet(input, output); // labels = classes of
                                                  // classification problem
                                                  // (each class one integer)
    dataSet.setExampleMetaData(metaData);
    csvParser.close();
    return dataSet;
  }

  /**
   * Necessary to prepare data for deeplearning4J.
   * Please note, that this is for a species file, not for FASTQ-Data itself. 
   * 
   * This method parses the files of Christin Bennke automatically, using her conventions in sample names
   * (such as 1T3 for first replicate, time 3 (which is 60 minutes into the experiment) 
   * 
   * @param file .csv-file, NOT a FASTQ-File!
   * @param timepoints true == timepoint will be used, false == ignore time point for training AND validation
   * @return data in the form that DL4J needs
   * @throws IOException file at {@code path} cant be opened, does not exist, ...
   */
  
  public DataSet readChristinAmpliconData(File file, boolean[] timepoints) throws IOException{
    //IOW-data is in 'wrong' format, csv-files need to be transposed
    CSVParser csvParser = new CSVParser(new FileReader(file), CSVFormat.DEFAULT.withDelimiter(','));
    List<CSVRecord> records = csvParser.getRecords();
    assert(!records.isEmpty());
    
    INDArray input = zeros(records.get(0).size()-1, records.size()-1); //one neuron per species
    INDArray output = zeros(records.get(0).size()-1, 2); //even though there are only 2 classes (control/glyph), it needs two output neurons (see XOR-Example)
    List<String> metaData = new ArrayList<>(100);
    
    boolean experimentClass = false;
    CSVRecord csvr;
    for(int i = 0; i< records.size(); i++){ //~1100 OTUs in Christins data
      csvr = records.get(i); //line i
      for(int j = 0; j < csvr.size(); j++ ){ //~90 observation points. time axis not modeled this time 
        experimentClass = identifyClassificationBySampleName(records.get(0).get(j)); //determine: is it control or experiment?
        if(i==0 && j > 0) metaData.add(j-1, records.get(0).get(j)); //j>0: leave out first column
        if(i > 0 && j > 0 && timepoints[j-1]){ //i>0 for header skipping, j>0 for skipping first column (species names)
          input.putScalar(new int[]{j-1,i-1},Double.valueOf(csvr.get(j))); 
          output.putScalar(new int[]{j-1,0}, experimentClass ? 0 : 1); //neuron 0 == control
          output.putScalar(new int[]{j-1,1}, experimentClass ? 1 : 0); //neuron 1 == experiment
        }        
      }
    }
    System.out.println("Control examples: "+ output.getColumn(0).sum(0)+ System.lineSeparator()+
        "Experiment examples: "+ output.getColumn(1).sum(0)+ System.lineSeparator());
    DataSet dataSet = new DataSet(input, output); //labels = classes of classification problem (each class one integer)
    dataSet.setExampleMetaData(metaData);
    csvParser.close();
    encodeMetaDataIntoInput(dataSet);
    return dataSet;
    }

  protected List<CSVRecord> selectOTUsRandomly(List<CSVRecord> records) {
    Collections.shuffle(records);
    records = records.subList(0, NUMBER_OF_OTUS_TO_KEEP);
    return records;
  }
  
  protected List<CSVRecord> useSelectedOTUs(List<CSVRecord> records, File file) {
    int index = 0;
    if(DEBUG){
    double sum = 0;
    
    for(CSVRecord current : records){
      Stream<String> stream = StreamSupport.stream(current.spliterator(), false);
      sum = stream.skip(1).mapToDouble(entry -> Double.valueOf(entry.replace(',', '.'))).sum();
      otus.put(current.get(0),new Pair<Integer,Double>(index,sum));
      index++;
    }
    otus = otus.entrySet().stream().sequential().sorted((entry1,entry2)-> entry2.getValue().getSecond().compareTo(entry1.getValue().getSecond())).
        collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
            (e1, e2) -> e1, LinkedHashMap::new));
    }

    List<CSVRecord> result = new ArrayList<>();
    //Iterator<Pair<Integer,Double>> indices = otus.values().iterator();
    for(int i = 0; i<NUMBER_OF_OTUS_TO_KEEP; i++){
      //index = indices.next().getFirst();
      //result.add(records.get(index));
      result.add(records.get(CHOSEN_OTU_INDICES[i]));
    }
    if(DEBUG){
      Optional<String> otu = result.stream().map(rec -> rec.get(0)).reduce( (a,b) -> a+" "+b);
      log.info(NUMBER_OF_OTUS_TO_KEEP+" most abundant OTUs in file: "+file+System.lineSeparator()+otu);
    }  
    return result;
  }
  
  /**
   * Parser specifically for files from Dr. Christin Bennke, automatically classifies samples from their names,
   * using her convention.
   * 
   * @param name sample name, usually has a number, station name, CT0, ..., CT3 for "Control, Time 0, ... Time 3" (which will be labeled "control"==false) 
   * and 1T0, 1T1,...3T2,3T3 for first replication, Time 0, 1st repl. Time 1, ...., 3rd replicate time 2, 3rd replicate time 3 ("experiment" == true)
   * @return true == experiment, false == control
   */
  private static boolean identifyClassificationBySampleName(String name){
    //if(name.contains("-CT") || name.contains("_RNA") || name.contains("_DNA")) { //classification: Control vs h2o2
    if(name.contains("DNA")){
      return false;
    } else {
      return true;
    }
  }
  /**
   * Adds a last line that contains the (binary) classification as experiment, needed for WEKA
   * @param file table WITH header and WITH first column as OTU Names
   * @throws IOException 
   * @throws FileNotFoundException 
   */
  public static void addClassLabelsToAmpliconOTU(File file) throws FileNotFoundException, IOException{
    CSVParser csvParser = new CSVParser(new FileReader(file), CSVFormat.DEFAULT.withDelimiter(';'));
    List<CSVRecord> records = csvParser.getRecords();
    String newLine = "classification";
    for(int i = 1; i < records.get(0).size(); i++){ //start from 1: skip first (name) column
      if(identifyClassificationBySampleName(records.get(0).get(i))){
        newLine+=",1"; 
      }else{
        newLine+=",0";
      }
    }
    //newLine+=System.lineSeparator();
    FileWriter fw = new FileWriter(file, true);
    fw.append(newLine);
    csvParser.close();
    fw.close();
  }
  
  
  
  /**
   * method needed to merge 'chronological' data. The {@link merge} method of ND4J does that too, 
   * but requires the data to be 3D. Amplicon species data is only 2D: Species * Timepoints.
   * 
   * Assumption: 
   * 1) x-axis (dim0) = species
   * 2) y-axis (dim1) = timepoints
   * 
   * The input {@code DataSet}s will be stacked along their y-axis, 
   * so the y-axis of the merged set will be multiplied by sets.size()
   * @param sets REQUIRES uniform length input arrays (features and labels, both)
   * @return merged set. Contains the first element of every set, then the 2nd of every set etc.
   */
  public static DataSet mergeTimeBasedDataSets(List<DataSet> sets){
    assert(!sets.isEmpty());
    if(sets.size() == 1) return sets.get(0);

    int numberOfSets = sets.size();
    int numberOfTimepoints;
    
    INDArray mergedFeatures = sets.get(0).getFeatures().getRow(0);
    INDArray mergedLabels = sets.get(0).getLabels().getRow(0);
    
    //'flatten' 3D-data (species x files x timepoints) into 2D-array ( species x timepoints*files)
    for(int i = 0; i<50; i++){
      for(int j = 0; j<numberOfSets; j++){
	numberOfTimepoints = sets.get(j).numExamples();
        if( (i==0 && j == 0 ) || i>=numberOfTimepoints) {} //first elements have already been initialized
        else{
        mergedFeatures = vstack(mergedFeatures,sets.get(j).getFeatures().getRow(i));
        mergedLabels = vstack(mergedLabels,sets.get(j).getLabels().getRow(i));
        }
      }   
    }    
    DataSet result = new DataSet(mergedFeatures,mergedLabels);
    result.setExampleMetaData(sets.get(0).getExampleMetaData());
    return result;
  }
  
  
  
 /**
  * Simple merge of a list of Datasets into one dataset. 
  * takes the metadata of the first element as new metadata
  * @param sets
  * @return 
  */
  public static DataSet simpleMerge(List<DataSet> sets){
      assert(!sets.isEmpty());
      if(sets.size() == 1) return sets.get(0);
      DataSet result = DataSet.merge(sets);    
      result.setExampleMetaData(sets.get(0).getExampleMetaData());
      return result;    
  }
  
  
  /**
   * Cosmetic method, <b> specifically written for 2 x 2 input </b>, so don't use please.
   * Intention is to leave out redundant information for the output plot (one of the two output neurons is always 1 - (the other) )
   * Method takes two values each (control DNA, RNA, then experiment DNA, RNA) and merges them into one INDArray.
   * @param output INDArray with <b> two rows </b> and <b> length divisible by four!</b>
   * @return merged INDArray, same length as input but only one row
   */
  public static INDArray prepareOutputForPlotting(INDArray output){
    int length = output.shape()[0];
    if(length % 4 != 0) output.reshape(output.shape()[0] = length+(4-length % 4));  //reshape can't change length!
    int quarterArrayLength = (new Double(Math.ceil(output.size(0)/4))).intValue();
    
    //split the output into two new arrays, to plot the control and experiment separately 
    double[] glyphActivationsRNA = new double[quarterArrayLength];
    double[] controlActivationsRNA = new double[quarterArrayLength];
    double[] controlActivationsDNA = new double[quarterArrayLength];
    double[] glyphActivationsDNA = new double[quarterArrayLength];
    for(int i = 0; i < quarterArrayLength; i++){ //output should be 2 columns for the 2 output neurons. the rows are the timepoints
        controlActivationsRNA[i] = output.getDouble(4*i, 0);
        controlActivationsDNA[i] = output.getDouble(4*i+1 , 0);
        glyphActivationsRNA[i] = output.getDouble(4*i+2, i < 4 ? 0 : 1);
        glyphActivationsDNA[i] = output.getDouble(4*i+3, i < 4 ? 0 : 1);
    }
    return vstack(create(controlActivationsRNA), create(controlActivationsDNA), create(glyphActivationsRNA), create(glyphActivationsDNA));
  }
  
  /**
   * Method for reducing the inputdata for timepoint-based tests.
   * Make sure, the array length fits the number of time points in the input List!
   * (array.length == records.size()-1, minus one for row names, which will be ignored)
   * 
   * @param input table. Considered to have column names AND row names. Thus, list must be larger than 1 (first line considered to be column names) 
   * @param timepoints which timepoints TO KEEP. true == keep it, false == delete it. needs to be the length of number of time points in the CSV-records
   * @return reduced input set. List has the same length, but the CSV-records in it will be shorter or equal 
   */
  
//  public List<CSVRecord> filterOutTimePoints(List<CSVRecord> input, boolean[] timepoints){
//      assert(input.size()>1); //header assumed!
//      assert(timepoints.length == input.get(1).size()-1);
//      List<CSVRecord> output = new ArrayList<>(input.size());
//      for(int i = 1; i < input.size(); i++){
//	  CSVRecord current = input.get(i);
//	  CSVRecord currentNew = new CSVReco
//	  for(int j = 1; j < timepoints.length; j++){
//	      if(timepoints[j]){
//		    current.
//	      }
//	      
//	  }
//      }
//      
//      return input;
//  }
}
