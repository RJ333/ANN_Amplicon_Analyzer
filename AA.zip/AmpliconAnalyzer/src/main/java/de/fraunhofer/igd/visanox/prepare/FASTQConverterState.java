package de.fraunhofer.igd.visanox.prepare;

/**
 * States of the fastq-parser in FASTQConverter-Class
 */
enum FASTQConverterState
{
    UNKNOWN, READINGNAMEIDENTIFIER, READINGNAME, READINGOPTIONAL, READINGSEQUENCE, READINGQUALITY
}
