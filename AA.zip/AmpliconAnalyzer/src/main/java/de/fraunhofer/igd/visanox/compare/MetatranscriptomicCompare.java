package de.fraunhofer.igd.visanox.compare;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.math3.stat.inference.GTest;
import org.apache.commons.math3.stat.inference.KolmogorovSmirnovTest;

import de.fraunhofer.igd.visanox.statistic.*;

import com.vividsolutions.jts.io.ParseException;

public class MetatranscriptomicCompare {
  private static final boolean DEBUG = true;
  private static final float factorForGTest = 1000;
  protected static final Log logger = LogFactory.getLog(MetatranscriptomicCompare.class);

  /**
   * NOTE1: does NOT use certainty values (yet)
   * 
   * 
   * @param sequence1
   * @param sequence2
   * @return
   */
  public static double trivialOneToOneDistance(char[] sequence1, char[] sequence2){
    if(sequence1.length<sequence2.length) {
      char[] temp = sequence1;
      sequence1 = sequence2;
      sequence2 = temp;
    } //sequence2 is from now on NOT longer than sequence 1
    int lengthDiff = Math.abs(sequence1.length-sequence2.length);
    double maxResult = 0;
    for(int i = 0; i < lengthDiff; i++){ //slide shorter sequence along longer one
      double intermediateResult = 0;
      for(int j = 0; j < sequence2.length; j++){ //compare every sequence of shorter one
        if(sequence1[j] == sequence2[j+i]) intermediateResult++; 
      }
      intermediateResult /= sequence2.length;
      if(intermediateResult >= maxResult) maxResult = intermediateResult;
    }
    
    return maxResult;
  }
  
  public static double[] compareSamplesOneToOne(String file1, String file2, CSVPrinter distribution, CSVPrinter comparison) throws IOException, ParseException, ArchiveException, InterruptedException{
    return compareSamplesOneToOne(file1, file2, distribution, comparison, false);
  }
  
  /**
   * Method that takes to FASTQ-files as .fastq or .gz and compares them with different methods.
   * 
   * @param file1 
   * @param file2
   * @param distribution
   * @param comparison
   * @param alreadyPrinted
   * @return  
   * @throws IOException
   * @throws ParseException
   * @throws ArchiveException
   * @throws InterruptedException
   */
  
  public static double[] compareSamplesOneToOne(String file1, String file2, CSVPrinter distribution, CSVPrinter comparison, boolean alreadyPrinted) throws IOException, ParseException, ArchiveException, InterruptedException{
    double[] results = new double[5];
    FASTQStatistics stats1 = new FASTQStatistics();
    FASTQStatistics stats2 = new FASTQStatistics();
    List<Sequence> sequences1 = ParseFASTQ.readFASTQfile(file1, stats1);
    List<Sequence> sequences2 = ParseFASTQ.readFASTQfile(file2, stats2);

    long[] sample1 = new long[4]; //convention of order of bases in this code: A,T(U),C,G
    long[] sample2 = new long[4];    
    
    sample1[0] = stats1.numberOfAdenine.longValue();
    sample2[0] = stats2.numberOfAdenine.longValue();
    sample1[1] = stats1.numberOfUracil.longValue();
    sample2[1] = stats2.numberOfUracil.longValue();
    sample1[2] = stats1.numberOfCytosin.longValue();
    sample2[2] = stats2.numberOfCytosin.longValue();
    sample1[3] = stats1.numberOfGuanine.longValue();
    sample2[3] = stats2.numberOfGuanine.longValue();
    
    GTest gtest = new GTest();
    //KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();

    /*
    if(DEBUG) System.out.printf("A:%,d | %,d "+System.lineSeparator()+
        "T:%,d | %,d "+System.lineSeparator()+
        "C:%,d | %,d "+System.lineSeparator()+
        "G:%,d | %,d ",sample1[0],sample2[0],sample1[1],sample2[1],sample1[2],sample2[2],sample1[3],sample2[3]);
    */

    logger.info(String.format("A:%,d | %,d "+System.lineSeparator()+
        "T:%,d | %,d "+System.lineSeparator()+
        "C:%,d | %,d "+System.lineSeparator()+
        "G:%,d | %,d ",sample1[0],sample2[0],sample1[1],sample2[1],sample1[2],sample2[2],sample1[3],sample2[3]));
    
    results[0] = gtest.gTestDataSetsComparison(sample1,sample2); // == Pearson's chi-square for goodness-of-fit?!
    //results[1] = ksTest.kolmogorovSmirnovTest(Arrays.stream(sample1, 0, sample1.length).asDoubleStream().toArray(),Arrays.stream(sample2, 0, sample2.length).asDoubleStream().toArray());
    results[1] = CramersV.remodeledCramers_V_biasCorrected(sample1, sample2)[1];
    results[2] = CramersV.remodeledCramers_V_biasCorrected(sample1, sample2)[0];
    
    
    long[] fractions1 = new long[4]; //convention of order of bases in this code: A,T(U),C,G
    long[] fractions2 = new long[4];
    
    fractions1[0] = (long) (stats1.getNucleotidePercentages().get(FASTQStatistics.ADENINE)*factorForGTest);
    fractions2[0] = (long) (stats2.getNucleotidePercentages().get(FASTQStatistics.ADENINE)*factorForGTest);
    fractions1[1] = (long) (stats1.getNucleotidePercentages().get(FASTQStatistics.THYMINE)*factorForGTest);
    fractions2[1] = (long) (stats2.getNucleotidePercentages().get(FASTQStatistics.THYMINE)*factorForGTest);
    fractions1[2] = (long) (stats1.getNucleotidePercentages().get(FASTQStatistics.CYTOSINE)*factorForGTest);
    fractions2[2] = (long) (stats2.getNucleotidePercentages().get(FASTQStatistics.CYTOSINE)*factorForGTest);
    fractions1[3] = (long) (stats1.getNucleotidePercentages().get(FASTQStatistics.GUANINE)*factorForGTest);
    fractions2[3] = (long) (stats2.getNucleotidePercentages().get(FASTQStatistics.GUANINE)*factorForGTest);
    
    results[3] = gtest.gTestDataSetsComparison(fractions1, fractions2);
    
    double[] entropy1 = Entropy.calculateShannonEntropy(sequences1);
    double[] entropy2 = Entropy.calculateShannonEntropy(sequences2);
    
    AggregatedStatistics.addEntropy(entropy1);
    AggregatedStatistics.addEntropy(entropy2);
    
    System.out.println(Arrays.toString(entropy1));
    System.out.println(Arrays.toString(entropy2));
    
    if(!alreadyPrinted){
    // <franz>
    // print first dist
    double sum = sample1[0]+sample1[1]+sample1[2]+sample1[3];
    String[] dist = new String[] {
            file1.replaceAll(".*\\\\", ""),
            String.valueOf(fractions1[0]),
            String.valueOf(fractions1[1]),
            String.valueOf(fractions1[2]),
            String.valueOf(fractions1[3]),
            Arrays.stream(entropy1).sequential().boxed().map((Double e)-> e.toString()).reduce(StringUtils.EMPTY, (s1,s2)-> s1+","+s2 ),
    };
    distribution.printRecord(dist);
    
    
    // print second dist
    sum = sample2[0]+sample2[1]+sample2[2]+sample2[3];
    dist = new String[] {
            file2.replaceAll(".*\\\\", ""),
            String.valueOf(fractions2[0]),
            String.valueOf(fractions2[1]),
            String.valueOf(fractions2[2]),
            String.valueOf(fractions2[3]),
            Arrays.stream(entropy2).sequential().boxed().map((Double e)-> e.toString()).reduce(StringUtils.EMPTY, (s1,s2)-> s1+","+s2 ),          
    };
    distribution.printRecord(dist);
    }

    // print comp
    String[] comp = new String[] {
            file1.replaceAll(".*\\\\", ""),
            file2.replaceAll(".*\\\\", ""),
            String.valueOf((double)sample1[0]/sample2[0]),
            String.valueOf((double)sample1[1]/sample2[1]),
            String.valueOf((double)sample1[2]/sample2[2]),
            String.valueOf((double)sample1[3]/sample2[3]),
            String.valueOf(results[0]),//atm: GTest
            String.valueOf(results[1]),//remodeled CramersV
            String.valueOf(results[2]) //Chi-Square
    };
    comparison.printRecord(comp);
    // </franz>
    
    return results;
  }
}
