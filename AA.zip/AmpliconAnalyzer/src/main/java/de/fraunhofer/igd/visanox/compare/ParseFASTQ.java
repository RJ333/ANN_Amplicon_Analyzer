package de.fraunhofer.igd.visanox.compare;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipInputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.biojava.bio.program.fastq.FastqVariant;

//import ucar.nc2.units.TimeUnit;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.collect.Lists;
import com.vividsolutions.jts.io.ParseException;
//import org.utgenome.thirdparty.*;

import net.java.truevfs.access.TFileInputStream;

public class ParseFASTQ {
  
  protected static final Log logger = LogFactory.getLog(ParseFASTQ.class); 
  public final static char[] nucleotideBases = {'A','T','C','G'};
  private static int countSequences = 0;
  
  public static List<Sequence> readFASTQfile(String file) throws IOException,
  ParseException, ArchiveException, InterruptedException {
    return readFASTQfile(file, null);    
  }
  
  @Deprecated
    /**
   * Unzips .gz-files, creates a .txt-file from it 
   * takes too long for very large files (e.g. a 3gb .gz-file will become a 16gb .txt-file)
   * Deprecated: Use TrueVFS (Virtual File System)
   * @param file the path to the zipped text-file
   * @return txt-file as a String
   * @throws IOException
   */
  private static String unzipArchives(String file) throws IOException {
    String txtFile = file.replaceFirst("\\..*+", ".txt"); //double backslash, to escape the Java-String backslash
    
    byte[] buffer = new byte[1024*16];
    
    try{

      GZIPInputStream archiveInputStream = 
       new GZIPInputStream(new TFileInputStream(file));

      FileOutputStream out = 
           new FileOutputStream(txtFile);

       int len;
       while ((len = archiveInputStream.read(buffer)) > 0) {
         out.write(buffer, 0, len); //TODO: dauert zu lange. .gz-Datei: etwa 3.3gb -> entpackt als txt: etwa 16gb
       }

       archiveInputStream.close();
       out.close();
      }finally{
    }
    return txtFile; //TODO: zu groß im Hauptspeicher, lieber wegschreiben?
  }
  
  /**
 * opens .gz-files, returns them as a String-Object
 * @param file the path to the zipped text-file
 * @return txt-file as a String
 * @throws IOException
 */
protected static String openGZIP(String file) throws IOException {  
  byte[] buffer = new byte[512*16];
  String returnString = "";
  int count = 0;
  long time = System.nanoTime();
  try{

    GZIPInputStream archiveInputStream = 
     new GZIPInputStream(new TFileInputStream(file)); 
     int len;
     String test = "";
     while ((len = archiveInputStream.read(buffer)) > 0) {
       test = new String(buffer);
       //System.out.println(test); //DEBUG
       //returnString+=test;
       count++;
     }
     
     archiveInputStream.close();
    }finally{
  }
  System.out.println("Number of lines read: "+count); //DEBUG
  System.out.println("Time needed: "+Math.abs((float)System.nanoTime()-time)/1000000000+"s");
  return returnString;
}
  
  public static List<Sequence> readFASTQfile(String path, FASTQStatistics stats) throws IOException, ParseException, ArchiveException, InterruptedException{
      if(!path.endsWith("gz")){
        logger.info("File "+path.toString()+" doesnt end with .gz , I will assume for the moment, that it is some other file (report/statistics etc)");
      }
      //if(path)
      return readFASTQtxtFile(path,stats);
    }    

  
  /**
   * Parse a FASTQ-file and if a pointer to a statistics-object is provided, 
   * it counts nucleotide total numbers.
   * @param path  Path to FASTQ-file, may theoretically be of any kind, archive, URL, ... (see TrueVFS-documentation) 
   * @param stats Pointer to stats-object
   * @return Returns a list of Sequence-objects containing all reads and probabilities, one of each per object
   * @throws IOException  if file not found/no permission/...
   * @throws ParseException file needs to be exact FASTQ-format (line1: ID, line2: read, line3:+, line4: certainty symbols)
   * @throws InterruptedException If the workStealingPool doesn't finish after 10minutes.
   */
  private static List<Sequence> readFASTQtxtFile(String path, FASTQStatistics stats) throws IOException,
      ParseException, ArchiveException, InterruptedException {
    
    ExecutorService executor = Executors.newWorkStealingPool();
    
    final int chunksize = 1000; //IMPORTANT: number needs to be divisible by 4 !!!
    
    boolean fastQ = !path.endsWith("fna"); //true: FASTQ, false: FNA (no quality, only 2 lines per sequence)
    
    File file = new File(path);
    BufferedReader br;
    FileInputStream fs = new FileInputStream(file);
    if(path.endsWith(".zip")){
      ZipInputStream zps = new ZipInputStream(fs);
      br = new BufferedReader(new InputStreamReader(zps));
    }
    if(path.endsWith(".gz")){
      GZIPInputStream gzs = new GZIPInputStream(fs);
      br = new BufferedReader(new InputStreamReader(gzs));
      //Encoding?
      }else{ 
      br = new BufferedReader(new InputStreamReader(fs));
      }
    List<Future<List<Sequence>>> results = new ArrayList<Future<List<Sequence>>>();
    int lineTotal = 0; //debug-code
    long time = System.currentTimeMillis(); //debug-code
    String currentLine = "";
    List<String> batchOfLines = new ArrayList<>(chunksize);
    int linesRead = 0;
    while (null != (currentLine = br.readLine())) { //vlt mit br.lines() direkt in den executor streamen?
      if(linesRead == chunksize){  //after gathering 'chunksize' lines, put them to the threadpool and gather the next batch
        results.add(executor.submit(parsePart(new Builder<String>().addAll(batchOfLines).build(), stats, fastQ)));
        //no problem here, Java initializes the new arrays at new memory locations, 
        //and garbage collector keeps it until the executer is finished with it
        
        batchOfLines = new ArrayList<>(chunksize); //DEBUG: one problem here - old strings dont get GC'ed, because they are still contained in the Futures (see code below)
        linesRead = 0;
        }
      batchOfLines.add(currentLine);
      linesRead++;
      lineTotal++;

      //System.out.println("Current result-variable size: "+results.size()); //DEBUG
      //results.clear(); with this it works, so 'results' is the culprit here 
    }
    results.add(executor.submit(parsePart(new Builder<String>().addAll(batchOfLines).build(), stats,fastQ)));
    
    //DEBUG NOTE: the following code will currently not be reached
    if(logger.isDebugEnabled()) logger.debug(lineTotal+" lines read in total from file "+path+System.lineSeparator()+
        +((System.currentTimeMillis()-time))); //debug-code
    br.close();
      
    time = System.currentTimeMillis(); //debug-code
    executor.shutdown();
    executor.awaitTermination(10, TimeUnit.SECONDS);

    if(!executor.isTerminated()) System.out.println("Asynchronous tasks not completed yet!"); 
    //unpack results from future-containers (map), wait for them at max 5minutes and put them in a List(reduce)
    List<Future<List<Sequence>>> blub2 = results;
    List<Sequence> temp1;
    for(Future<List<Sequence>> current : blub2){
      try {
        temp1 = current.get(5L,TimeUnit.MINUTES);
      } catch (ExecutionException | TimeoutException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    
    List<Sequence> blub = results.stream()
        .map(s->{
          try{
            return s.get(5L,TimeUnit.MINUTES);} catch (Exception e){
              throw new RuntimeException(e);
        }}).reduce(new ArrayList<Sequence>(), (el1,el2)->{
          ((List<Sequence>) el1).addAll((List<Sequence>) el2); 
          return el1;
          });
    
    if(logger.isDebugEnabled()) logger.debug("Sequences total: "+blub.size()+System.lineSeparator()+
        +((System.currentTimeMillis()-time))); //debug-code
    executor.shutdown();
    return blub;
  }
  
  
  
  private static Callable<List<Sequence>> parsePart(List<String> lines,
      FASTQStatistics stats, boolean fastQ) {
    //countSequences++; //DEBUG
    //System.out.println(countSequences); //DEBUG
    return new Callable<List<Sequence>>() {
      @Override
      public List<Sequence> call() throws Exception {
        return parseFASTQLines(lines, stats,fastQ);
      }
    };
  }
    

   private static List<Sequence> parseFASTQLines(List<String> parsedLines, FASTQStatistics stats, boolean fastQ){
     if(parsedLines.size() % 4 != 0){ 
       if(logger.isWarnEnabled()) logger.warn("FASTQ-file's lines not divisable by 4, format might be wrong");
       }
     List<Sequence> reads = new ArrayList<Sequence>();
     if(parsedLines.isEmpty()) return reads;
     if(fastQ) {
       reads = readFASTQ(stats, parsedLines);
     } else {
       reads = readFNA(stats,parsedLines);
     }
    //System.out.println("Returning sequence list "+countSequences); //DEBUG
    return reads;
  }

  protected static List<Sequence> readFASTQ(FASTQStatistics stats, List<String> parsedLines) {
    String currentLine;
     String currentSeq = "";
     String currentId = "";
     String currentQuality;
     //check for "NNNNNNN..."-sequences, seems
     boolean containsOnlyN = true; 
     int countN;
     
     List<Sequence> reads = new ArrayList<Sequence>();
     
   Iterator<String> it = parsedLines.iterator();  
   while(it.hasNext()){
     countN  = 0;
     containsOnlyN = true;
     currentLine = it.next();
      if (StringUtils.startsWith(currentLine, "@")) { //Id-line
        currentId = StringUtils.substring(currentLine, 1);
        currentSeq = it.next();
        it.next();// skip the "+"
        currentQuality = it.next();
        reads.add(new Sequence(currentId, currentSeq, currentQuality)); //else: dont store "NNNN..."-sequence
        
        if(!(stats == null )){ //Is the typecheck necessary? shouldnt be...
          stats.addReadToNucleotideDistribution(currentSeq);
          ImmutableList<Character> chars = Lists.charactersOf(currentSeq); //litters the memory!
          // UnmodifiableListIterator<Character> iter = chars.listIterator();
          for(Character currentNucleotide : chars){
            currentNucleotide = Character.toUpperCase(currentNucleotide);
            switch (currentNucleotide) {
            case 'A':
              stats.addAdenine();
              containsOnlyN = false;
              break;
            case 'C':
              stats.addCytosin();
              containsOnlyN = false;
              break;
            case 'G':
              stats.addGuanine();
              containsOnlyN = false;
              break;
            case 'U': case 'T': //for test purposes with DNA FASTQ-files
              stats.addUracil();
              containsOnlyN = false;
              break;
            case 'N':
              if(containsOnlyN){
                countN++;
              }else{
                stats.addUnidentified();
              }
              break;

            default:
              if(logger.isWarnEnabled()){
                logger.warn("Found a(n) "+currentNucleotide+" in read");
              }
              break;
            }
          }
          if(!containsOnlyN){
            stats.addNUnidentified(countN);
          }
          stats.addQualities(currentQuality.chars().mapToObj(i -> (char)i).collect(Collectors.toList()));
          //stats.addQualities(Sequence.errorProbability(FastqVariant.FASTQ_SANGER, currentQual)); //count error probabilities in stats object
        }//END (stats != null)
      }
    }
  return reads;
  }
  
  /**
   * FNA-files are merged reverse and forward reads. May contain "NN...NNN"-sequences, where merging presumably failed.
   * 
   * @param stats
   * @param parsedLines
   * @return
   */
  
  protected static List<Sequence> readFNA(FASTQStatistics stats, List<String> parsedLines) {
    String currentLine;
     String currentSeq = "";
     String currentId = "";
     String currentQuality = "";
     //check for "NNNNNNN..."-sequences, seems
     boolean containsOnlyN = true; 
     int countN;
     
     List<Sequence> reads = new ArrayList<Sequence>();
     
   Iterator<String> it = parsedLines.iterator();  
   while(it.hasNext()){
     countN  = 0;
     containsOnlyN = true;
     currentLine = it.next();
      if (StringUtils.startsWith(currentLine, ">")) { //Id-line
        currentId = StringUtils.substring(currentLine, 1);
        currentSeq = it.next();
        if(!(stats == null )){ 
          ImmutableList<Character> chars = Lists.charactersOf(currentSeq); //litters the memory!
          stats.addReadToNucleotideDistribution(currentSeq);
          for(Character currentNucleotide : chars){
            currentNucleotide = Character.toUpperCase(currentNucleotide);
            switch (currentNucleotide) {
            case 'A':
              stats.addAdenine();
              containsOnlyN = false;
              break;
            case 'C':
              stats.addCytosin();
              containsOnlyN = false;
              break;
            case 'G':
              stats.addGuanine();
              containsOnlyN = false;
              break;
            case 'U': case 'T': //for test purposes with DNA FASTQ-files
              stats.addUracil();
              containsOnlyN = false;
              break;
            case 'N':
              if(containsOnlyN){
                countN++;
              }else{
                stats.addUnidentified();
              }
              break;

            default:
              if(logger.isWarnEnabled()){
                logger.warn("Found a(n) "+currentNucleotide+" in read");
              }
              break;
            }
          }
          if(!containsOnlyN) stats.addNUnidentified(countN); //else: dont store "NNNN..."-sequence 
          stats.addQualities(currentQuality.chars().mapToObj(i -> (char)i).collect(Collectors.toList()));
          //stats.addQualities(Sequence.errorProbability(FastqVariant.FASTQ_SANGER, currentQual)); //count error probabilities in stats object
        }
        if(!currentSeq.matches("^N+$")) reads.add(new Sequence(currentId, currentSeq, currentQuality));
      }
    }
  return reads; //müsste hier irgendwo hängen bleiben
  }
  
  }

class FASTQStatistics{
  protected static final Log logToCSV = LogFactory.getLog("ResultsAsCSV");
  
  static final Character ADENINE = 'A';
  static final Character GUANINE = 'G';
  static final Character THYMINE = 'T';
  static final Character CYTOSINE = 'C';
  static final Character UNIDENTIFIED = 'N';
  //pyrimidines
  protected AtomicInteger numberOfAdenine = new AtomicInteger();
  protected AtomicInteger numberOfGuanine = new AtomicInteger();
  
  //purines
  protected AtomicInteger numberOfCytosin = new AtomicInteger();
  protected AtomicInteger numberOfUracil = new AtomicInteger(); //unmethylated thymine
  
  protected AtomicInteger numberOfUnidentified = new AtomicInteger();
  
  protected ConcurrentHashMap<Character,Integer> numberOfQualities = new ConcurrentHashMap<>();
  
  protected List<Sequence> sequences = new ArrayList<Sequence>();
  
  private int numberOfSequences = 0;
  
  //Character = A,T,C,G, key-Integer = number of that Base in read, value-Integer = amount of reads, that had 'key-int' of that base in it
  //e.g.: A,(3,5) means: 5 sequences in total had 3 Adenin in them
  protected Map<Character,Map<Integer,Integer>> nucleotideDistribution = new ConcurrentHashMap<Character,Map<Integer,Integer>>(5);
    
  
  
  public FASTQStatistics(){
    nucleotideDistribution.put(ADENINE, new ConcurrentHashMap<Integer,Integer>(165));
    nucleotideDistribution.put(CYTOSINE, new ConcurrentHashMap<Integer,Integer>(165));
    nucleotideDistribution.put(GUANINE, new ConcurrentHashMap<Integer,Integer>(165));
    nucleotideDistribution.put(THYMINE, new ConcurrentHashMap<Integer,Integer>(165));
    nucleotideDistribution.put(UNIDENTIFIED, new ConcurrentHashMap<Integer,Integer>(20));
    }

  public AtomicInteger getNumberOfAdenine() {
    return numberOfAdenine;
  }

  public AtomicInteger getNumberOfGuanine() {
    return numberOfGuanine;
  }

  public AtomicInteger getNumberOfCytosin() {
    return numberOfCytosin;
  }

  public AtomicInteger getNumberOfUracil() {
    return numberOfUracil;
  }

  public AtomicInteger getNumberOfUnidentified() {
    return numberOfUnidentified;
  }
  
  public Map<Character,Integer> getNumberOfQualities() {
    return numberOfQualities;
  }
  
  public void addAdenine(){
    numberOfAdenine.incrementAndGet();
  }
  public void addGuanine(){
    numberOfGuanine.incrementAndGet();
  }
  public void addCytosin(){
    numberOfCytosin.incrementAndGet();
  }
  public void addUracil(){
    numberOfUracil.incrementAndGet();
  }
  public void addUnidentified(){
    numberOfUnidentified.incrementAndGet();
  }
  public void addNUnidentified(int n){
    numberOfUnidentified.addAndGet(n);
  }
  
  public void addSequences(List<Sequence> seq){
    sequences.addAll(seq);
  }
  
  public List<Sequence> getSequences(){
    return this.sequences;
  }
  
  public void addQualities(Iterable<Character> qualityScores){
    for(Character current : qualityScores){
      if(numberOfQualities.containsKey(current)){
        numberOfQualities.computeIfPresent(current, (c,i) -> ++i);
      }else{
        numberOfQualities.putIfAbsent(current, 1);
      }
    }    
  }
  
  public void addReadToNucleotideDistribution(String read){
    assert(read.length()>0);
    Map<Character,Long> readStats = read.chars().mapToObj(i -> (char)i).collect(Collectors.groupingBy(x -> x,Collectors.counting()));
    for(Character baseType : readStats.keySet()){
      if(nucleotideDistribution.get(baseType).containsKey(Math.toIntExact(readStats.get(baseType)))){
        int oldCount = nucleotideDistribution.get(baseType).get(Math.toIntExact(readStats.get(baseType)));
        nucleotideDistribution.get(baseType).put(Math.toIntExact(readStats.get(baseType)), ++oldCount);
      }else{
        nucleotideDistribution.get(baseType).put(Math.toIntExact(readStats.get(baseType)), 1);
      }     
    }
  }
  
  /**
   * Nucleotides of one file as percentages
   * @return Map of nucleotides and corresponding percentage in file
   */
  public Map<Character, Float> getNucleotidePercentages(){
    Map<Character,Float> summary = new HashMap<Character, Float>(6);
    int total = IntStream.of(numberOfAdenine.get(),numberOfCytosin.get(),numberOfGuanine.get(),numberOfUnidentified.get(),numberOfUracil.get()).sum();
    summary.put(ADENINE,  ((float)numberOfAdenine.get()/total*100));
    summary.put(GUANINE, ((float)numberOfGuanine.get()/total*100));
    summary.put(CYTOSINE,  ((float)numberOfCytosin.get()/total*100));
    summary.put(THYMINE, ((float)numberOfUracil.get()/total*100));
    summary.put(UNIDENTIFIED, ((float)numberOfUnidentified.get()/total*100));
    summary.put('M', (float) total); //total number
    
    return summary;    
  }
  

  
  
  /**
   * The object that the call is made from is kept, the one whose address is given
   * can be put away.
   * @param stats add this object's numbers to the calling object
   */
//  public void mergeStats(FASTQStatistics stats){ 
//    this.numberOfAdenine.addAndGet(stats.getNumberOfAdenine().intValue());
//    this.numberOfCytosin.addAndGet(stats.getNumberOfCytosin().intValue());
//    this.numberOfGuanine.addAndGet(stats.getNumberOfGuanine().intValue());
//    this.numberOfUnidentified.addAndGet(stats.getNumberOfUnidentified().intValue());
//    this.numberOfUracil.addAndGet(stats.getNumberOfUracil().intValue());
//    
//    //not sure, if this is the right way around (which object stays)
//    stats.getNumberOfQualities().forEach((k,v) -> this.numberOfQualities.merge(k, v, Integer::sum));
//  }
  
  public static void printSummary(Map<Character,Float> summary){
    summary.forEach((s,f) -> System.out.printf(s+": %,.2f%n",f));
  }
  
  public void printNucleotideDistribution(){
    nucleotideDistribution.toString();
//    nucleotideDistribution.forEach((c,map) -> {
//      map.));
//    }
  }
//  public static void printErrorSummary(Map<Double,Integer> errorAmounts){
//    errorAmounts.forEach((d,i) -> System.out.printf("Error: %,.5f%n ,amount: "+i,d));
//  }
  
  public static void printErrorStatistics(Map<Character, Integer> map){
    System.out.printf("ErrorStatistics:%n");
    Map<Double,Integer> result = map.entrySet().stream().
      collect(Collectors.toMap(
          entry -> Sequence.errorProbability(FastqVariant.FASTQ_SANGER, entry.getKey()),
          entry -> entry.getValue()));     
    
    result.entrySet().stream().sorted(Comparator.comparing(Map.Entry::getKey))
    .forEach((entry) -> 
       System.out.printf("Error:  %,.8f  amount: %,d %n",entry.getKey(),entry.getValue()));
    System.out.printf("ErrorValueSum: %,d",result.values().stream().collect(Collectors.summingInt(s->s)));
  }

}

/**
 * This class aggregates the results of ONE sample (== 1 FASTQ-file).
 * For N-sample-statistics, see @link FASTQStatistics
 * @author jzabel
 *
 */
class perSampleStatistics {
  protected static final Log logger = LogFactory.getLog(perSampleStatistics.class); 

  //Counts the number of exact occurrences of all sequences
  Map<Sequence,Integer> sequenceDistribution = new HashMap<>();
  private boolean sequencesOrdered = false;
  
  
  public void addSequence(Sequence seq){
    sequencesOrdered = false;
    if(sequenceDistribution.containsKey(seq)){
      sequenceDistribution.put(seq, sequenceDistribution.get(seq)+1);
    }else{
      sequenceDistribution.put(seq, 1);
    }
  }
  
  public int[][] getSequenceDistribution(){
    int[][] result = new int[50][2];
    for(int current : sequenceDistribution.values()){
      if(current>50) logger.warn("Found more than 50 identical sequences in one file");
    }
    return result;
  }
//code from sof
  protected static <K, V extends Comparable<? super V>> Map<K, V> sortByValue( Map<K, V> map ){
    Map<K, V> result = new LinkedHashMap<>();
    Stream<Map.Entry<K, V>> st = map.entrySet().stream();

    st.sorted(Map.Entry.comparingByValue()).forEachOrdered( e -> result.put(e.getKey(), e.getValue()) );

  return result;
  }
}

