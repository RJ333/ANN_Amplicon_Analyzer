package de.fraunhofer.igd.visanox.connection;

/**
 * Maps coordinatos to xy
 */
class Projector {
    double oLon;
    double oLat;
    double mLon;
    double mLat;
    int sW;
    int sH;

    Projector (double oLon, double oLat, double mLon, double mLat, int screenWidth, int screenHeight) {
        this.oLon = oLon;
        this.oLat = oLat;
        this.mLon = mLon;
        this.mLat = mLat;
        this.sW = screenWidth;
        this.sH = screenHeight;
    }

    int[] worldToScreen (double lon, double lat) {
        int x = (int)Math.round((lon-this.oLon)/(this.mLon-this.oLon)*(double)this.sW);
        int y = (int)Math.round((lat-this.oLat)/(this.mLat-this.oLat)*(double)this.sH);
        return new int[] {x, y};
    }
}