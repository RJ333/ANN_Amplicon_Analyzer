package de.fraunhofer.igd.visanox.compare;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.biojava.bio.program.fastq.FastqVariant;

/**
 * From wiki:
 * A FASTQ file normally uses four lines per sequence.

    Line 1 begins with a '@' character and is followed by a sequence identifier and an optional description (like a FASTA title line).
    Line 2 is the raw sequence letters.
    Line 3 begins with a '+' character and is optionally followed by the same sequence identifier (and any description) again.
    Line 4 encodes the quality values for the sequence in Line 2, and must contain the same number of symbols as letters in the sequence.

 * @author jzabel
 *
 */


public class Sequence implements Comparable<Sequence> {
  private static final Log logger = LogFactory.getLog(Sequence.class); 
  //private static int countSuccesses = 0;
  String identifier; //Line 1
  String rawRead;
  //the following will be implemented when needed
  //List<Pair<Character,Character>> rawRead; //Line2+4
  //Line 3 is omitted, as it seems it provides no relevant information 
  //List<Pair<Character,Character>> qualitySymbols; //Line4
  
  int length;
  
  public Sequence(String identifier,String sequence, String qualityScore){
    if(!qualityScore.isEmpty()){ //if it is empty, it's probably another format than FASTQ, such as FNA
      if(sequence.length() != qualityScore.length()){
        if(logger.isWarnEnabled()) logger.warn("Sequence and quality score dont have the same length");
      }
    }
    this.rawRead = sequence;
    this.identifier = identifier;
    length = sequence.length();
    //this.qualityScore = errorProbabilities(FastqVariant.FASTQ_SANGER,qualityScore); //IOW-data should be Illumina 1.8+, which uses Sanger
    }
  
  //method unusable atm, it fills the memory with too many Doubles :-(
  static protected Double errorProbability(FastqVariant companyFormat, Character qualityScore){
    return companyFormat.errorProbability(qualityScore); 
  }
  
  @Override
  public boolean equals(Object obj){
    if(null == obj) return false;
    if(obj.getClass() == Sequence.class){
      Sequence seq = (Sequence)obj;
      return this.rawRead.equals(seq.rawRead);
      }
    else return false;
  }
  
  @Override
  public int hashCode(){
    return rawRead.hashCode();
    }
  
  /**
   * Overridden for ordering purposes (entropy)
   * NOTE:didn't work for stream.sorted() :-/
   */
  @Override
  public int compareTo(Sequence o) {
    if(this.length < o.length){
      return 1;
    } else {
      if(this.length == o.length){
        return 0;
      } else {
        return -1;
      }
    }
  }
  
  
  @Override
  public String toString(){
    return rawRead;
  }

}


