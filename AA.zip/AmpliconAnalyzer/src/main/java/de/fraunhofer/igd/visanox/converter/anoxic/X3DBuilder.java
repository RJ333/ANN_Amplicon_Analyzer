package de.fraunhofer.igd.visanox.converter.anoxic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ucar.ma2.Array;
import ucar.ma2.IndexIterator;
import ucar.ma2.InvalidRangeException;
import ucar.ma2.Range;
import ucar.nc2.Dimension;
import ucar.nc2.NetcdfFile;
import ucar.nc2.Variable;
import ucar.nc2.dataset.NetcdfDataset;

import com.vividsolutions.jts.io.ParseException;

//import de.fraunhofer.igd.visanox.converter.PNGWriter;

/**
 * Erzeugen von X3D-Hoehenfeldern fuer VisAnox (GeoElevationGrids oder ElevationGrids).
 * Die Konfiguration des Builders kann entweder programmatisch mit BuilderProperties-Objekt, per converter.properties-Datei 
 * oder per Kommandozeilenaufruf erfolgen.
 *
 * @author Thomas Ruth, Fraunhofer IGD Rostock
 */
public class X3DBuilder {
	private static final Log logger = LogFactory.getLog(X3DBuilder.class); 
	
	
	//private static final String SPACING = "0.016"; 
	//private static final String GEO_GRID_ORIGIN = "9.20833  53.40417 0";
	private static final String TEMPLATE_NAME = "template.x3d";

	private final BuilderProperties properties;

	public static void main(String args[]) {
		logger.info("X3D Builder: Converts bathymetric grids from NetCDF files together with kriging data for anoxic and suboxic zones to X3D elevation grids.\n"
				+ "(C) 2015, Fraunhofer IGD Rostock\n");
    	
		if (args.length == 1 && !args[0].endsWith(".properties")) { // Only print informations, no conversion
			printNCFileInfos(args[0]);
			
		} else {

			final BuilderProperties properties;
			final BuilderProperties propsFromFile;
			// Wenn abweichender Pfad zu Config-Datei angegeben, diese nutzen!
			if ((args.length == 1) && args[0].endsWith(".properties")){
				propsFromFile = configureFromPropertyFile(args[0]);
			} else {
				propsFromFile = configureFromPropertyFile(null);
			}
			if (propsFromFile != null) {
				properties = propsFromFile;
			} else { // No converter.properties file found/used
				// Error: no (valid) configuration found
				logger.error("No valid configuration found, neither custom properties file nor (valid) converter.properties file.\n");
				logger.error("Possible usages: ");
				logger.error("1. X3DBuilder <inputfilename>[.nc|.grd] (only print information about the input grid file)");
				logger.error("2. X3DBuilder <configurationfilename>.properties");
				logger.error("3. X3DBuilder (no command line parameter, requires converter.properties file in root folder)");
				return;
			}

			if (BuilderProperties.MODE_INFO.equals(properties.getMode())) {
				// Only print information, no conversion
				printNCFileInfos(properties.getInputfile());
				return;
			} else {
				// do the full blown conversion job...
				final X3DBuilder x3dBuilder = new X3DBuilder(properties);
				x3dBuilder.convertGrid2X3D();
			}

		}
	}
	
	/**
	 * Konstruktor, der ein Konfigurationsobjekt erwartet. Damit ist die eingebettete Nutzung des Builders moeglich.
	 *
	 * @param properties Konfiguration für die Konvertierung 
	 */
	public X3DBuilder(final BuilderProperties builderProperties) {
		this.properties = builderProperties;
		
		if (properties == null) {
			throw new RuntimeException("Builder properties are missing.");
		}

		if (properties.isVerbose()) {
			printParameters(properties);
		}
		
	}

	/**
	 * Konstruktor, der im Classpath die Datei 'converter.properties' mit der Konfiguration des Builders erwartet.
	 */
	public X3DBuilder() {
		this(configureFromPropertyFile(null));
	}
	
	private static BuilderProperties configureFromPropertyFile(final String propertyFilePath) {
		final Properties props = new Properties();
		Reader configReader = null;
		BuilderProperties properties = null;
		try {
			if (propertyFilePath != null) {
				configReader = new FileReader(propertyFilePath);
			} else {
				configReader = new FileReader("converter.properties");
			}
			props.load(configReader);
			logger.info("Found configuration file 'converter.properties', ignoring command line configuration.");
			if (!props.isEmpty()){
				properties = new BuilderProperties();
				BeanUtils.populate(properties, props);
			} else {
				logger.info("Converter property file is empty. Continuing with command line parameter configuration.");
			}
		} catch (FileNotFoundException e) {
			logger.info("Could not find converter property file. Continuing with command line parameter configuration.");
		} catch (IOException e) {
			logger.error("Error: Could not read converter property file.");
		} catch (IllegalAccessException e) {
			logger.error("Error: Could not configure converter from property file (maybe wrong/unknown property names?): " + e.getMessage() );
		}
	      catch (InvocationTargetException e) {
		    logger.error("Error: Could not configure converter from property file (maybe wrong/unknown property names?): " + e.getMessage() );
	    }
		if (configReader != null) {
			try {
				configReader.close();
			} catch (IOException e) {
				logger.error("Error: Could not close converter property file.");
			}
		}
		return properties;
	}

	private static void printParameters(BuilderProperties properties) {
		logger.info("------------------ Specified parameters ------------------------");
		logger.info("Operation mode: " + properties.getMode());
		logger.info("Input grid file: " + properties.getInputfile());
		logger.info("Output X3D file: " + properties.getOutputfile());
		logger.info("Height variable for rendered elevation grid: " + properties.getHeightVariable());
		logger.info("Verbose (Print grid content and kriging process details): " + properties.isVerbose());
		logger.info("Positive scale factor: " + properties.getPositiveScale());
		logger.info("Negative scale factor: " + properties.getNegativeScale());
		logger.info("Used variable for landmask: " + (properties.getLandMaskVariable() != null ? properties.getLandMaskVariable() : properties.getHeightVariable()));
		logger.info("X3D template folder: " + properties.getTemplateFolder());
	}
    
    
	/**
	 * Methode zum Auslesen eines Höhenfelds aus einer .nc Datei und Schreiben einer 3D-Szene im X3D-Format.
	 */
	public void convertGrid2X3D() {
		final long startTime = System.nanoTime();
		
		FileWriter fstream = null;
		BufferedWriter out = null;
		
		FileReader input = null;
		BufferedReader bufRead = null;
		NetcdfFile dataFile = null;
		
		final String inputFilename = properties.getInputfile();
		final String outputFilename = properties.getOutputfile();
		int pathSepIndex = (outputFilename.lastIndexOf("/")!= -1) ? outputFilename.lastIndexOf("/") : outputFilename.lastIndexOf("\\"); 
		final String outputFoldername = outputFilename.substring(0, pathSepIndex);
		final String variableToParse = properties.getHeightVariable();
		final String variableForLandmask = properties.getLandMaskVariable();
		final String variableForLat = properties.getLatVariable();
		final String variableForLon = properties.getLonVariable();
		final String basinsPath = properties.getBasinsPath(); 			// Für Kriging: Verzeichnis mit Ostsee-Becken
		final String iowDataFilePath = properties.getIowDataFilePath(); // Kriging-Input mit den Monitoringfahrt-Messdaten
		
		final boolean printInfo =  properties.isVerbose();
		final String positiveScale =  properties.getPositiveScale();
		final String negativeScale = properties.getNegativeScale();
		final String templateFolderName = properties.getTemplateFolder();
		
		try {
			// Create file
			fstream = new FileWriter(outputFilename);
			out = new BufferedWriter(fstream, 15000);
			input = new FileReader(templateFolderName + "\\" + TEMPLATE_NAME);
			bufRead = new BufferedReader(input);
	
			String line = bufRead.readLine();
			
			try {
				// Open the file.
				dataFile = NetcdfDataset.openDataset(inputFilename);
				
				if (printInfo) { // Show metainfo
					printNCInfos(dataFile);
				}
				
				logger.info("Computation Status information:");

	    	   	// Determine and validate Variable for height shading
				final Variable heightVar = dataFile.findVariable(variableToParse);
				if (heightVar == null) {
					logger.error(" Error: unknown variable name specified: " + variableToParse);
					closeAndDelete(outputFilename, out, input, dataFile);
					return;
				} else {
					logger.info(" Using variable '" + variableToParse + "' for ElevationGrid rendering: " + heightVar.getDescription());
				}

				if (heightVar.getRank() != 2){
					logger.error(" Selected variable contains probably not a grid (not 2-dimensional)");
					closeAndDelete(outputFilename, out, input, dataFile);
					return;
				}
				
				// Hier die refenzierten Dimensions des Grid auslesen, prüfen, ob es Koordinaten sind
				// (NetCDF-Konvention ist: Koordinaten sind Variablen mit einer gleichnamigen Dimension)
				final List<Dimension> gridDimensions = heightVar.getDimensions();
				
				final Variable[] coordVar = new Variable[2]; // Array mit den beiden Positionsvariablen
				for (int i = 0; i < gridDimensions.size(); i++) {
					final Variable cv = dataFile.findVariable(gridDimensions.get(i).getName()); 
					if ((cv != null) && cv.isCoordinateVariable()){
						// Alles ok, Koordinaten-Variable speichern
						coordVar[i] = cv;
					} else {
						logger.error(" Error: Variable dimension is not a coordinate dimension: " + cv.getName());
						logger.error(" Selected variable is probably not a grid");
						closeAndDelete(outputFilename, out, input, dataFile);
						return;
					}
				}
				
				// Variante 2, um an das Koordinatensystem (und die einzelnen Werte des zugrundeliegenden Grids) zu kommen
				// final NetcdfDataset dataSet = new ucar.nc2.dataset.NetcdfDataset(dataFile);
				// dataSet.getCoordinateSystems().get(0).isCoordinateSystemFor(heightVar);
				// dataSet.getCoordinateSystems().get(0).isGeoReferencing();
				// double originLat = dataSet.getCoordinateAxes().get(0).read().getDouble(0);
				
				// Die ersten 2 X- und y-Koordinaten, um Abstand und Ursprung zu bestimmen
				final List<Range> start = new ArrayList<Range>(1);
				start.add(new Range(2));
				
				final Array xCoords = coordVar[1].read(start);
				final Array yCoords = coordVar[0].read(start);

				// Determine Variable for landmask
	    	   	final Variable landmaskVar;
	    	   	if(variableForLandmask != null){
	    	   		landmaskVar = dataFile.findVariable(variableForLandmask);
	    	   		if (landmaskVar == null) {
	    	   			logger.error(" WARNING: unknown variable name for landmask specified: " + variableForLandmask);
	    	   		} else {
	    	   			logger.info(" Using variable '" + variableForLandmask + "' for landmask: " + landmaskVar.getDescription());
	    	   		}
	    	   	} else {
	    	   		logger.info(" Using variable '" + variableToParse + "' for landmask: " + heightVar.getDescription());
	    	   		landmaskVar = null;
	    	   	}
		   			
	    	   	// Determine Variable for lat & lon
	    	   	final Variable latVar;
	    	   	if(variableForLat != null){
	    	   		latVar = dataFile.findVariable(variableForLat);
	    	   		if (latVar == null) {
	    	   			logger.error(" WARNING: unknown variable name for latitude specified: " + variableForLat);
	    	   		} else {
	    	   			logger.info(" Using variable '" + variableForLat + "' for latitude: " + latVar.getDescription());
	    	   		}
	    	   	} else {
	    	   		logger.error(" Without values for latitude no kriging is possible!");
	    	   		latVar = null;
	    	   	}
	    	   	
	    	   	final Variable lonVar;
	    	   	if(variableForLon != null){
	    	   		lonVar = dataFile.findVariable(variableForLon);
	    	   		if (lonVar == null) {
	    	   			logger.error(" WARNING: unknown variable name for longitude specified: " + variableForLon);
	    	   		} else {
	    	   			logger.info(" Using variable '" + variableForLon + "' for longitude: " + lonVar.getDescription());
	    	   		}
	    	   	} else {
	    	   		logger.error(" Without values for longitude no kriging is possible!");
	    	   		lonVar = null;
	    	   	}
	    	   	
	   			// Aktuelles Erzeugungsdatum im <head>-Abschnitt einfuegen
// Temporaer aus wg. PURE-Template
//	   			while (!line.startsWith("</head>")) {
//					out.write(line + "\n");
//					line = bufRead.readLine();
//				}
//	   			out.write("<meta name='created' content='" + new Date(System.currentTimeMillis()).toGMTString() + "\'/>\n");
//	   			
//	   			out.write("<meta name='grid data source' content='" + inputFilename + "\'/>\n");
//				out.write("<meta name='grid data file type' content='" + dataFile.getFileTypeId() + "\'/>\n");
	   			
				while (!line.equals("<!--LandscapeGrid-->")) {
					out.write(line + "\n");
					line = bufRead.readLine();
				}
				out.write(line + "\n");
	   			
				final String generatorMode = properties.getGridGeneration();
				logger.info("Start generation of elevation grid, trying to transfer input grid with mode: " + generatorMode);
				
				final Map<String,double[][]> convertedGrids;
				if (generatorMode.equals(BuilderProperties.GENERATION_FULL)) {
					convertedGrids = createFullGrid(heightVar, landmaskVar, latVar, lonVar, basinsPath, iowDataFilePath);
				} else if (generatorMode.equals(BuilderProperties.GENERATION_REDUCED)) {
					convertedGrids = createReducedGrids(heightVar, landmaskVar, latVar, lonVar, basinsPath, iowDataFilePath);
				} else if (generatorMode.equals(BuilderProperties.GENERATION_TILED)) {
					convertedGrids = createTiledGrids();
				} else {
					logger.error("Error: unknown grid generation mode: " + generatorMode);
					convertedGrids = null;
				}
				
				double[][] coords = convertedGrids.get("coords");
				double[][] landMask = convertedGrids.get("colorCoords");
				double[][] hypoxCoords = convertedGrids.get("hypoxCoords");
				double[][] anoxCoords = convertedGrids.get("anoxCoords");
				
				double[][] stride = convertedGrids.get("stride");
				float xSpacing = (xCoords.getFloat(1) - xCoords.getFloat(0)) * (float) stride[0][0];
				float ySpacing = (yCoords.getFloat(1) - yCoords.getFloat(0)) * (float) stride[0][0];

				float xOrigin = xCoords.getFloat(0) - 0.5f * xSpacing;
				float yOrigin = yCoords.getFloat(0) - 0.5f * ySpacing;

				final String origin = String.valueOf(xOrigin) + " " + String.valueOf(yOrigin) + " 0";
				// TODO: Hier Ursache für falsche Positionierung? (Grid wird ja mit "bottomUp" eingelesen, von unten nach oben --> Ursprung wird aber oben gelesen)
				
	   			int negScale = Integer.parseInt(negativeScale);
	   			int posScale = Integer.parseInt(positiveScale);

	   			ElevationgridBuilder eBuilder;
	   			// 1. Generate bathymetry (sea floor topography)
				if (properties.isGenerateLandscape()){
		   			eBuilder = new ElevationgridBuilder(coords, negScale, posScale);
					if (landMask != null) {
						eBuilder.setCoordsColor(landMask);
					}
					
					Map<String, String> args = new HashMap<String, String>();
					args.put("DEF", "Landscape");
					args.put("solid", "true");
					args.put("xDimension", coords[0].length + "");
					args.put("zDimension", coords.length + "");
					args.put("normalPerVertex", "true");
					args.put("colorPerVertex", "true");
					args.put("ccw", "true");
					args.put("creaseAngle", Long.toString(properties.getSmoothing()));
					if (properties.isUseGeoNodes()) { 		// <GeoElevationGrid> oder <ElevationGrid> nutzen
						args.put("appearance.nodeType", "GeoElevationGrid");
						args.put("geoGridOrigin", origin);
						args.put("geoSystem", "\"GD\" \"WE\" \"longitude_first\" \"longitude_first\"");
						args.put("yScale", "20");
						args.put("xSpacing", String.valueOf(xSpacing));
						args.put("zSpacing", String.valueOf(ySpacing));
					} else {
						args.put("appearance.nodeType", "ElevationGrid");
						args.put("xSpacing", "100");
						args.put("zSpacing", "100");
					}
					if (properties.isShading()) {
						args.put("appearance.shading", ""); // Gouraud-Shading der Oberfläche
					}
					if (landmaskVar == null) {
						args.put("texture", ""); // Erzeugung einer Einfärbung als Textur (Basis sind die Höhenwerte)
					} else {
						args.put("color", "");	// Erzeugung einer Einfärbung als Farbarray (Basis beliebiges Grid)
					}
					args.put("cutLandSurface", "true"); // Landerhoehungen abschneiden
					if (properties.isGenerateCubewall()) args.put("generateCubewalls", "true");
					
		   			final StringBuffer grid = eBuilder.buildElevationgrid(args);
					if (grid != null) {
						out.write(grid.toString());
					} else {
		   				logger.error("ERROR: Elevation grid build failed.");
		   				closeAndDelete(outputFilename, out, input, dataFile);
						return;
		   			}
		   			out.write("\n");
				}
	   			
	   			// 2. Generation top surface of hypoxic area
	   			eBuilder = new ElevationgridBuilder(anoxCoords, negScale, posScale);
	   			
	   			final Map<String, String> args2 = new HashMap<String, String>();
	   			args2.put("appearance.diffuseColor", "1.0 0.0 0.0");
	   			args2.put("appearance.transparency", "0.20");
	   			args2.put("DEF", "AnoxSurface");
	   			args2.put("solid", "true");
				args2.put("xDimension", coords[0].length + "");
				args2.put("zDimension", coords.length + "");
	   			args2.put("normalPerVertex", "true");
	   			args2.put("ccw", "true");
	   			args2.put("creaseAngle", "0");
				if (properties.isUseGeoNodes()) { 		// <GeoElevationGrid> oder <ElevationGrid> nutzen
					args2.put("appearance.nodeType", "GeoElevationGrid");
					args2.put("geoGridOrigin", origin);
					args2.put("geoSystem", "\"GD\" \"WE\" \"longitude_first\" \"longitude_first\"");
		   			args2.put("yScale", "20");
		   			args2.put("xSpacing", String.valueOf(xSpacing));
					args2.put("zSpacing", String.valueOf(ySpacing));
				} else {
					args2.put("appearance.nodeType", "ElevationGrid");
					args2.put("xSpacing", "100");
					args2.put("zSpacing", "100");
				}
				//args2.put("cutLandSurface", "true"); // Landerhoehungen abschneiden
				
	   			final StringBuffer anoxSurfaceGrid = eBuilder.buildElevationgrid(args2);
	   			
				if (anoxSurfaceGrid != null) {
					out.write(anoxSurfaceGrid.toString());
				} else {
	   				logger.error("ERROR: Elevation grid build failed.");
	   				closeAndDelete(outputFilename, out, input, dataFile);
					return;
	   			}				
	   			out.write("\n");	

	   			// 3. Generation top surface of hypoxic area
	   			eBuilder = new ElevationgridBuilder(hypoxCoords, negScale, posScale);
	   			
	   			final Map<String, String> args3 = new HashMap<String, String>();
	   			args3.put("appearance.diffuseColor", "0.0 0.0 0.0");
	   			args3.put("appearance.transparency", "0.40");
	   			args3.put("DEF", "HypoxSurface");
	   			args3.put("solid", "true");
				args3.put("xDimension", coords[0].length + "");
				args3.put("zDimension", coords.length + "");
	   			args3.put("normalPerVertex", "true");
	   			args3.put("ccw", "true");
	   			args3.put("creaseAngle", "0");
				if (properties.isUseGeoNodes()) { 		// <GeoElevationGrid> oder <ElevationGrid> nutzen
					args3.put("appearance.nodeType", "GeoElevationGrid");
					args3.put("geoGridOrigin", origin);
					args3.put("geoSystem", "\"GD\" \"WE\" \"longitude_first\" \"longitude_first\"");
		   			args3.put("yScale", "20");
		   			args3.put("xSpacing", String.valueOf(xSpacing));
					args3.put("zSpacing", String.valueOf(ySpacing));
				} else {
					args3.put("appearance.nodeType", "ElevationGrid");
					args3.put("xSpacing", "100");
					args3.put("zSpacing", "100");
				}
				//args3.put("cutLandSurface", "true"); // Landerhoehungen abschneiden
				
	   			final StringBuffer hypoxSurfaceGrid = eBuilder.buildElevationgrid(args3);
	   			
				if (hypoxSurfaceGrid != null) {
					out.write(hypoxSurfaceGrid.toString());
				} else {
	   				logger.error("ERROR: Elevation grid build failed.");
	   				closeAndDelete(outputFilename, out, input, dataFile);
					return;
	   			}				
	   			out.write("\n");
	   			 			
	   			// Rest vom Template verarbeiten
	   			line = bufRead.readLine();
				while (line != null) {
					out.write(line + "\n");
					line = bufRead.readLine();
				}
	   			
				if (properties.getMode().equals(BuilderProperties.MODE_INFO)){ // Falls nur INFO-Mode, nix persistent speichern 
					closeAndDelete(outputFilename, out, input, dataFile);
				} else {
					fillOutputFolder(templateFolderName, outputFoldername);					
				}
				
				logger.info("Finished!");
				
			} catch (Exception e) {
				   closeAndDelete(outputFilename, out, input, dataFile);
		    	   e.printStackTrace();
			} finally {
				if (out != null){
					out.close();
				}
				if (input != null){
					input.close();
				}
				if (dataFile != null){
					dataFile.close(); 
				}
			}
		} catch (Exception e) {// Catch exception if any
			try {
				closeAndDelete(outputFilename, out, input, dataFile);
			} catch (IOException e1) {
				logger.error("ERROR: Could not close file.");
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		logger.info("computation time: " + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS) + "ms");
	}

	private Map<String, double[][]> createTiledGrids() {
		logger.error("ERROR: Generation mode not supported yet.");
		return null;
	}

	private Map<String, double[][]> createReducedGrids(Variable heightVar, Variable landmaskVar, Variable latVar, Variable lonVar, 
			String basinsPath, String iowDataFilePath) throws IOException {
		int arrayDim1 = heightVar.getShape(0); //360 fuer iow_topo1 (Y)
		int arrayDim2 = heightVar.getShape(1); //370 fuer iow_topo1 (X)
		int valueCount = arrayDim1 * arrayDim2;
		logger.info("Input grid has " + valueCount + " values.");

		// Simples Subsampling vorbereiten (jeder 2./3./4.... Wert des Original-Arrays)
		float frac = 1;
		long maxGridValues = properties.getMaxNumberOfGridNodes();
		logger.info("Trying to reduce input grid so that the generated grid has less than " + maxGridValues + " values.");
		while (valueCount > maxGridValues) {
			frac++;
			// Ist beim Teilen einer Arraydimension, z.B. durch 3 ein Nachkommarest da, kann ein Wert mehr ausgelesen werden, deshalb aufrunden!
			// z.B. 4x4-Array: Wird jeder 3. ausgelesen, habe ich ein 2x2-Array (0. Wert, 4. Wert des Original-Arrays)
			valueCount = (int) (Math.ceil(arrayDim1/frac) * Math.ceil(arrayDim2/frac));
		}
		if (frac > 1) {
			logger.info("Grid reduction using a stride of " + frac + " on both dimensions. Generated grid has " + valueCount + " values.");
		} else {
			logger.info("No grid reduction needed. Full input grid will be transferred.");
		}
		
		int oldArrayDim1 = arrayDim1;
		int oldArrayDim2 = arrayDim2;
		
		arrayDim1 = (int) Math.ceil(arrayDim1 / frac);
		arrayDim2 = (int) Math.ceil(arrayDim2 / frac);
		
		// Bereitstellen der NetCDF-Arrays
		final List<Range> ranges = new ArrayList<Range>(2);
		Array grid = null;
		Array gridLandmask = null;

		try {
			ranges.add(new Range(0, oldArrayDim1 - 1, (int) frac));
			ranges.add(new Range(0, oldArrayDim2 - 1, (int) frac));
			grid = heightVar.read(ranges);
			
			if (landmaskVar != null) {
				if (landmaskVar != heightVar) {
					gridLandmask = landmaskVar.read(ranges);
				} else {
					gridLandmask = grid;
				}
			}

		} catch (InvalidRangeException e) {
			e.printStackTrace();
		}
		// TODO Anpassen: Strides mitnutzen beim LatLon-Auslesen
		final Array lat = getLatArray(latVar);
		final Array lon = getLonArray(lonVar);
		
		// Auslesen der NetCDF-Arrays
		return readGrids(landmaskVar, arrayDim1, arrayDim2, valueCount, frac, grid, gridLandmask, lat, lon, basinsPath, iowDataFilePath);
	}
	
	private Map<String, double[][]> createFullGrid(Variable heightVar, Variable landmaskVar, Variable latVar, Variable lonVar, 
			String basinsPath, String iowDataFilePath) throws IOException {
		int arrayDim1 = heightVar.getShape()[0]; //360 fuer iow_topo1
		int arrayDim2 = heightVar.getShape()[1]; //370 fuer iow_topo1
		
		int valueCount = arrayDim1 * arrayDim2;
		logger.info("Input grid has " + valueCount + " values.");
		
		// Bereitstellen der NetCDF-Arrays
		final Array grid = heightVar.read();

		Array landMask = null;
		if (landmaskVar != null) {
			if (landmaskVar != heightVar) {
				landMask = landmaskVar.read();
			} else {
				logger.error("No separate landmask variable configured.. We will see what we can do without it...");
				// TODO Als Fallback dann alles mit Höhe > 0 als Land betrachten
			}
		}
		final Array lat = getLatArray(latVar);
		final Array lon = getLonArray(lonVar);

		// Auslesen der NetCDF-Arrays
		return readGrids(landmaskVar, arrayDim1, arrayDim2, valueCount, 1.0, grid, landMask, lat, lon, basinsPath, iowDataFilePath);
	}

	private Array getLatArray(Variable latVar) throws IOException {
		Array lat = null;
		if (latVar != null) {
			lat = latVar.read();
		} else {
			logger.error("No separate latitude variable configured.. We will see what we can do without it...");
		}
		return lat;
	}

	private Array getLonArray(Variable lonVar) throws IOException {
		Array lon = null;
		if (lonVar != null) {
			lon = lonVar.read();
		} else {
			logger.error("No separate longitude variable configured.. We will see what we can do without it...");
		}
		return lon;
	}

	/**
	 * Auslesen aller NetCDF-Arrays in Java-Arrays und bei Bedarf Rotieren + Invertieren. Dann Aufruf des Kriging.
	 */
	private Map<String, double[][]> readGrids(final Variable colorVar, final int arrayDim1, final int arrayDim2, final int valueCount, 
			final double stride, final Array grid, final Array gridLandmask, final Array lat, final Array lon, String basinsPath, String iowDataFilePath) {
		final double[][] coords;
		final double[][] landMask;
		final double[][] anoxCoords = new double[arrayDim1][arrayDim2];
		final double[][] hypoxCoords = new double[arrayDim1][arrayDim2];
		
		// TODO: Idee: Läßt sich z-Fighting optisch bekämpfen, wenn deckungsgleiche Bereiche gebaut werden ODER die Farbe in deckungsgleichen Bereichen gleich ist?
		// (z.B. Anox-Fläche im Bereich der Nicht-Anoxie genau die gleiche Höhe und Farbe wie Land geben)
		
		// Steps: 1. Auslesen von height, landMask, xCoord, yCoord (die LatLon-Koordinaten aus dem netCDF)
		// 		  2. Durchlaufen der Methode VolumeInterpolation.ordinaryKriging() mit xCoord, yCoord
		//		  3. Erzeugen von drei Grids: Bottom (nur Bathymetrie), anox, hypox
		
		
		if (properties.isUseGeoNodes()) {
			coords = readGrid(arrayDim1, arrayDim2, valueCount, grid);
			landMask = colorVar != null ? readGrid(arrayDim1, arrayDim2, valueCount, gridLandmask) : null;
			// TODO: Erzeugung anoxCoords nachziehen
		} else {
			coords = readGridBottomUp(arrayDim1, arrayDim2, valueCount, grid);
			landMask = colorVar != null ? readGridBottomUp(arrayDim1, arrayDim2, valueCount, gridLandmask) : null;
			final double[] latValues = read1DBottomUp(arrayDim1, lat);
			final double[] lonValues = read1D(arrayDim2, lon);
			
			logger.info("Lets start the kriging process for the whole input grid...");
			VolumeInterpolation volInt;
			try {
				volInt = new VolumeInterpolation(basinsPath, iowDataFilePath, properties.isVerbose());
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				volInt = null;
			}
		    
		    double maxO = 1000, maxH2S = 1000;
		    for (int i = 0; i < arrayDim1; i++) {
				for (int j = 0; j < arrayDim2; j++) {
					double interpolation;
					if (landMask[i][j] == 0.0) {
						interpolation = volInt.ordinaryKriging(lonValues[j], latValues[i], volInt.O2Variogram, 1.80)[0];
						maxO = (interpolation != -999.0 && maxO > interpolation) ? interpolation : maxO;
					} else {
						interpolation = -999.0;
					}
					hypoxCoords[i][j] = (interpolation == -999.0) ? interpolation : -interpolation; // Werte ohne Hypoxie unter die Topographie schieben
				}
			}
			for (int i = 0; i < arrayDim1; i++) {
				for (int j = 0; j < arrayDim2; j++) {
					double interpolation;
					if (landMask[i][j] == 0.0) {
						interpolation = volInt.ordinaryKriging(lonValues[j], latValues[i], volInt.H2SVariogram, 1.8)[1];
						maxH2S = (interpolation != -999.0 && maxH2S > interpolation) ? interpolation : maxH2S;
					} else {
						interpolation = -999.0;
					}
					anoxCoords[i][j] = (interpolation == -999.0) ? interpolation : -interpolation; // Werte ohne Anoxie unter die Topographie schieben
				}
			}
			if (properties.isVerbose()){
				logger.info("Lowest (interpolated) hypoxic depth: " + maxO);
				logger.info("Lowest (interpolated) anoxic depth: " + maxH2S);
			}
			
			// PNGWriter pngTest = new PNGWriter();
			// pngTest.writeVolume(hypoxCoords, "test.png");
		}
		
		if (!properties.isHeightValues()) {
			invertHeightArray(coords);
		}
		
		Map<String, double[][]> result = new HashMap<String, double[][]>();
		result.put("coords", coords);
		result.put("colorCoords", landMask);
		result.put("hypoxCoords", hypoxCoords);
		result.put("anoxCoords", anoxCoords);
		result.put("stride", new double[][] {{stride}});
		return result;
	}
	
	/**
	 * Auslesen eines einzelnen NetCDF-Arrays in ein Java-Array, dabei Vertauschen von Zeilen und Spalten (180 Grad-Rotation).
	 */
	private static double[][] readGridFlipped(final int arrayDim1, final int arrayDim2, final int valueCount, final Array grid) {
		final double[][] array = new double[arrayDim1][arrayDim2];

		if (grid != null) {
			// Alternativ auch mit Range.Iterator iter = ranges.get(0).getIterator() machbar...
			int idx1 = arrayDim1 - 1;
			int idx2;
			for (int i = 0; i < valueCount; i = i + arrayDim2) {
				idx2 = arrayDim2 - 1;
				for (int j = 0; j < arrayDim2; j++) {
					// Vertauschen von Zeilen und Spalten 
					array[idx1][idx2] = grid.getDouble(i + j);
					idx2--;
				}
				idx1--;
			}
		}
		return array;
	}
	
	/**
	 * Auslesen eines einzelnen NetCDF-Arrays in ein Java-Array, dabei Spiegelung der Zeilen (Schreiben von unten nach oben).
	 */
	private static double[][] readGridBottomUp(final int arrayDim1, final int arrayDim2, final int valueCount, final Array grid) {
		final double[][] array = new double[arrayDim1][arrayDim2];

		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			int idx1 = arrayDim1 - 1;
			for (int i = arrayDim1 - 1; i > 0; i--) {
				for (int j = 0; j < arrayDim2; j++) {
					// Spiegelung der Zeilen, d.h. von unten nach oben schreiben
					array[i][j] = iter.getDoubleNext();
				}
				idx1--;
			}
		}
		return array;
	}

	/**
	 * Auslesen eines einzelnen 1D-NetCDF-Arrays in ein Java-Array, dabei Spiegelung der Zeilen (Schreiben von unten nach oben).
	 */
	private static double[] read1DBottomUp(final int arrayDim1, final Array grid) {
		final double[] array = new double[arrayDim1];

		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			for (int i = arrayDim1 - 1; i >= 0; i--) {
				// Spiegelung der Zeilen, d.h. von unten nach oben schreiben
				array[i] = iter.getDoubleNext();
			}
		}
		return array;
	}
	
	private static double[] read1D(final int arrayDim, final Array grid) {
		final double[] array = new double[arrayDim];

		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			for (int i = 0; i < arrayDim; i++) {
				array[i] = iter.getDoubleNext();
			}
		}
		return array;
	}
	
	/**
	 * Auslesen eines einzelnen NetCDF-Arrays in ein Java-Array, dabei Spiegelung der Spalten (Schreiben der Werte von Rechts nach Links).
	 */
	private static double[][] readGridLeftToRight(final int arrayDim1, final int arrayDim2, final int valueCount, final Array grid) {
		final double[][] array = new double[arrayDim1][arrayDim2];

		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			for (int i = 0; i < arrayDim1; i++) {
				for (int j = arrayDim2 - 1; j >0; j--) {
					// Spiegelung der Spalten
					array[i][j] = iter.getDoubleNext(); 
				}
			}
		}
		return array;
	}
	
	/**
	 * Auslesen eines einzelnen NetCDF-Arrays in ein Java-Array.
	 */
	private static double[][] readGrid(final int arrayDim1, final int arrayDim2, final int valueCount, final Array grid) {
		final double[][] array = new double[arrayDim1][arrayDim2];

		if (grid != null) {
			final IndexIterator iter = grid.getIndexIterator();
			for (int i = 0; i < arrayDim1; i++) {
				for (int j = 0; j < arrayDim2; j++) {
					array[i][j] = iter.getDoubleNext();
				}
			}
		}
		return array;
	}
	
	/**
	 * Do in-place inversion of the array values.
	 */
	private static void invertHeightArray(double[][] coords) {
		for (int i = 0; i < coords.length; i++) {
			double[] row = coords[i];
			for (int j = 0; j < row.length; j++) {
				row[j] = 0 - row[j];
			}
		}
	}

	private void fillOutputFolder(final String templateFolderName, final String outputFolderName) throws IOException {
		//Copy necessary files to output directory
		final File folder = new File(templateFolderName + "\\");
		final File[] listOfFiles = folder.listFiles();
		final File destDir = new File(outputFolderName);

		for (int i = 0; i < listOfFiles.length; i++) {
			final File fileName = listOfFiles[i];
			if (fileName.getName().equals(TEMPLATE_NAME)) {
				continue;
			} else if (fileName.isDirectory()) {
				if (!fileName.getName().startsWith(".")) {
					// Unterverzeichnisse nicht rekursiv mitkopieren (z.B. images oder css)
					FileUtils.copyDirectory(fileName, new File(destDir, fileName.getName()), FileFilterUtils.notFileFilter(DirectoryFileFilter.DIRECTORY));
					continue;
				} else {
					continue;
				}
			}
			FileUtils.copyFileToDirectory(fileName, destDir);
		}
	}

	private void closeAndDelete(final String outputFilename, final BufferedWriter out, final FileReader input,
			NetcdfFile dataFile) throws IOException {

		if (out != null) {
			out.close();
		}
		if (input != null) {
			input.close();
		}
		if (dataFile != null) {
			dataFile.close();
		}

		final File file = new File(outputFilename);
		if (file != null) {
			boolean success = file.delete();
			if (!success) {
				logger.info("Deletion of empty output folder failed.");
				System.exit(0);
			} else {
				logger.info("Empty output file deleted.");
			}
		}
	}
	
	public static void printNCFileInfos(final String fileName) {
		NetcdfFile dataFile = null;
		try {
			dataFile = NetcdfDataset.openDataset(fileName);
			printNCInfos(dataFile);
			
		} catch (IOException e) {
			logger.error("Error: Could not open netcdf file '" + fileName + "': " + e.getMessage());
		} finally {
			if (dataFile != null){
				try {
					dataFile.close();
				} catch (IOException e) {
					logger.error("Error: Could not close netcdf file '" + fileName + "': " + e.getMessage());
				}
			}
		}
	}
	
	private static void printNCInfos(final NetcdfFile dataFile) {
		if (dataFile != null) {
			logger.info("--------------------- NetCDF Data Detail Info -----------------------------");
	       	logger.info(dataFile.getDetailInfo());
	    	logger.info("----------------- FileTypeDescription --------------------------");
			logger.info(dataFile.getFileTypeDescription());
			logger.info("---------------------- Variables -------------------------------");
			logger.info(dataFile.getVariables()); //Variable = Mehrdimensionales Array mit Name, Typ und Dimensionen
			logger.info("--------------------- Dimensions -------------------------------");
			logger.info(dataFile.getDimensions()); //Länge der zugehörigen Variablen
			logger.info("------------------ Global Attributes ---------------------------");
			logger.info(dataFile.getGlobalAttributes()); //Metadaten als Key-Value-Paare zu Variablen oder der ganzen File
		}
		else{
			logger.error("Error: Inputfile is null.");
		}
	}

	
}
