package de.fraunhofer.igd.visanox.converter;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Schreibt Volumedaten als Scheiben/Slices in ein 2D-Graustufen-PNG.
 * (Nutzbar in X3DOM innerhalb eines ImageTextureAtlas-Knotens).
 * 
 * @author Thomas Ruth, Fraunhofer IGD, 2014
 */
// TODO Hartkodiertes Aufskalieren der volume-Datenwerte auf die 8Bit-Graustufenskala dynamisch machen (aktuell fix auf int von 0 - 40)
// Entsprechenden Input aus den metadaten von netCDF ziehen
public class PNGSliceWriter {
	private static final Log logger = LogFactory.getLog(PNGSliceWriter.class); 

	private String usagePattern = "<ImageTextureAtlas containerField='voxels' url='%s' numberOfSlices='%d' slicesOverX='%d' slicesOverY='%d'/>";
	
	public PNGSliceWriter() {
		
	}
	
	/**
	 * Schreibt ein übergebenes Volume als Graustufenwert-Slices in ein PNG.
	 * Die Anzahl der slices (Keys in der Map) bestimmt dabei die Anzahl der Slices.
	 */
	public void writeVolume(final List<float[][]> volume, final String outputFileName) {
		StringBuilder sb = new StringBuilder();
		sb.append("Write out volume as sliced grayscale PNG image");

		int slices = volume.size();
		int slicesOverX = (int) Math.ceil(Math.sqrt(slices+0d));
		int slicesOverY = (int) Math.ceil((slices+0d) / slicesOverX);
		
		// Annahme, dass alle Slices gleich groß sind
		int width = volume.get(0)[0].length; // 1. Dimension
		int height = volume.get(0)[0].length; // 2. Dimension
		try {
			BufferedImage bi = new BufferedImage(width * slicesOverX, height * slicesOverY, BufferedImage.TYPE_BYTE_GRAY);
			WritableRaster r = bi.getRaster();

			float scale = 256f / 40f; // Für hartkodiertes Hochskalieren für psu_Werte zwischen 0 und 40
			
			// Hier das volume-Array durchlaufen und scheibchenweise in das PNG übertragen
			for (int s = 0; s < slices; s++) {
				float[][] sl = volume.get(s);
				int xOffset = (s % slicesOverX) * width;
				int row = s / slicesOverY;
				int yOffset = row * height;
				
				for (int i = 0; i < sl.length; i++) {
					for (int j = 0; j < sl[i].length; j++) {
						// Konversion in integer-Werte (+ hartkodiertes Hochskalieren für psu-Werte, Wertebereich 0-40
						final float vf = sl[i][j];
						final int value = Float.isNaN(vf) ? 0 : (int) (vf * scale);
						r.setPixel(i + xOffset, j + yOffset, new int[] { value});
					}
				}
				sb.append('.');
			}
			logger.info(sb.toString());
			ImageIO.write(bi, "PNG", new File(outputFileName));
			
			logger.info("Wrote volume slice to file: " + outputFileName);
			logger.info("x3dom usage: " + String.format(usagePattern, outputFileName, slices, slicesOverX, slicesOverY));

		} catch (IOException ie) {
			// TODO Ordentliches Fehlerhandling...
			ie.printStackTrace();
		}
	}
}