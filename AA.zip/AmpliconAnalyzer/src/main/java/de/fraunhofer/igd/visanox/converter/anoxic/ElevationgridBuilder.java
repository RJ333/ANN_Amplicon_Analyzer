package de.fraunhofer.igd.visanox.converter.anoxic;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ElevationgridBuilder {
	private static final Log logger = LogFactory.getLog(ElevationgridBuilder.class); 

	private double[][] coords;
	private double[][] coordsColor;
	private int negScale = 1;
	private	int posScale = 1;
	
	public ElevationgridBuilder(final double[][] coords, final int negScale, final int posScale){
		this.coords = coords;
		this.negScale =negScale;
		this.posScale = posScale;
	}

	
	public StringBuffer buildElevationgrid(final Map<String, String> args) {
		logger.info("Computing Elevation grid " + args.get("DEF"));
		final StringBuffer buffer = new StringBuffer(50000);

		// 1. Shape-, Appearance- und Material-Knoten generieren
		buffer.append("<Shape>\n");
		createAppearance(args, buffer, args.get("DEF"));
		
		buffer.append("<" + args.get("appearance.nodeType") + " "); // <GeoElevationGrid> oder <ElevationGrid>
		
		for(String s: args.keySet()){
			if(!s.equals("color") && !s.equals("texture") &&	// Farb-Parameter ausfiltern
			   !s.startsWith("appearance.") &&	 				// Appearance-Parameter ausfiltern
			   !s.startsWith("cutLandSurface")){				// Parameter zum Abschneiden von Landerhebungen
				buffer.append(s + "=\'" + args.get(s) + "\' ");	// Alle anderen direkt durchreichen
			}
		}
		
		// 2. X3D-Höhenfeld generieren
		buffer.append("\nheight=\'");
		int nanCount = 0, posCount = 0;
		boolean cutLandSurface = args.keySet().contains("cutLandSurface");
		
		for (int i = 0; i < coords.length; i++) {
			for (int j = 0; j < coords[0].length; j++) {
				final double originalValue = coords[i][j];

				if (Double.isNaN(originalValue)){
					// In optimierten netCDF steht oft NaN, wenn nicht belegt
					//logger.info("Original value is NaN: " + originalValue + "(i: " + i + " j: " + j + ")");
					nanCount++;
					buffer.append("0.001 ");						// Gehe von Landflaechen aus, daher leicht hoeher
				} else if (originalValue < 0) {
					buffer.append((originalValue * negScale) + " ");	//Schreibe skalierte Daten der Landschaft
					continue;
				} else if (originalValue > 0) {
					if (cutLandSurface) {
						// Cut landscapes based on the height
						buffer.append("0.001 ");						// Gehe von Landflaechen aus und glaette diese
					} else {
						buffer.append((originalValue * posScale) + " ");	//Schreibe skalierte Daten der Landschaft
					}
					posCount++;
					continue;
				} else { // if (originalValue == 0)
					buffer.append(originalValue + " ");				//Schreibe Daten der Landschaft
				}
			}
			buffer.append("\n");
		}
		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("\'>\n");
		logger.info(nanCount + " original elevation values were NaN, and converted to 0.001");
		logger.info(posCount + " original elevation values had positive height (land elevation), and converted to 0.001");
				
		// 3. Color- und TextureCoordinate-Knoten generieren

		buffer.append("</" + args.get("appearance.nodeType") + ">\n");
		buffer.append("</Shape>");

		
		// 4. Cube-Walls erzeugen (IndexedFaceSets um den Boden herum, d.h. 4 Seitenflächen)
		boolean generateCubeWalls = args.keySet().contains("generateCubewalls");
		
		// TODO: Optimierung, wenn Depth immer 0, dann nur ersten und letzten merken, damit weniger coords erzeugt werden
		
		if (generateCubeWalls){
			// Wall 1: Entlang der z-Achse, x ist konstant (0), Höhenwerte sind y
			double[] wallCoords = new double[coords.length];
			int[] wallIndex = new int[coords.length];
			
			for (int i = 0; i < coords.length; i++) {
				final double originalValue = coords[i][0];
				wallIndex[i] = i;
				wallCoords[i] = fillCoordArray(originalValue, cutLandSurface);
			}		
			writeCubeWall(args, buffer, 1, wallCoords, wallIndex, 0, ((coords.length-1) * 100));
			
			// Wall 2: Entlang der x-Achse, z ist konstant (0), Höhenwerte sind y
			wallCoords = new double[coords[0].length];
			wallIndex = new int[coords[0].length];
			
			for (int i = 0; i < coords[0].length; i++) {
				final double originalValue = coords[0][i];
				wallIndex[i] = i;
				wallCoords[i] = fillCoordArray(originalValue, cutLandSurface);
			}		
			writeCubeWall(args, buffer, 2, wallCoords, wallIndex, ((coords[0].length-1) * 100), 0);
			
			// Wall 3: Entlang der z-Achse, x ist konstant (lastCol + xSpacing), Höhenwerte sind y
			wallCoords = new double[coords.length];
			wallIndex = new int[coords.length];
			
			int lastCol = coords[0].length - 1;
			for (int i = 0; i < coords.length; i++) {
				final double originalValue = coords[i][lastCol];
				wallIndex[i] = i;
				wallCoords[i] = fillCoordArray(originalValue, cutLandSurface);
			}		
			writeCubeWall(args, buffer, 3, wallCoords, wallIndex, lastCol * 100, ((coords.length-1) * 100));
					
			// Wall 4: Entlang der x-Achse, z ist konstant (lastRow * zSpacing), Höhenwerte sind y
			wallCoords = new double[coords[0].length];
			wallIndex = new int[coords[0].length];
			
			int lastRow = coords.length - 1;
			for (int i = 0; i < coords[0].length; i++) {
				final double originalValue = coords[lastRow][i];
				wallIndex[i] = i;
				wallCoords[i] = fillCoordArray(originalValue, cutLandSurface);
			}		
			writeCubeWall(args, buffer, 4, wallCoords, wallIndex, ((coords[0].length-1) * 100), lastRow * 100);
		}
		return buffer;
	}


	private void createAppearance(final Map<String, String> args, final StringBuffer buffer, final String materialName) {
		if (args.keySet().contains("appearance.transparency") || args.keySet().contains("appearance.diffuseColor") 
			|| args.keySet().contains("appearance.shading")	|| args.keySet().contains("texture")) { 
			// add an appearance node
			buffer.append("\t<Appearance>\n");

			if (args.keySet().contains("appearance.transparency")) {
				buffer.append("\t\t<Material DEF=\"" + materialName + "Material\" ");
				buffer.append("transparency =\"" + args.get("appearance.transparency") + "\" ");
				
				if (args.keySet().contains("appearance.diffuseColor")) {
					buffer.append("diffuseColor=\'" + args.get("appearance.diffuseColor") + "\' " + "/>\n");
				}
			}
			if (args.keySet().contains("appearance.shading")) {
				buffer.append("\t\t<Material/>\n");// Mit leerem Material-Knoten wird ein Gouraud-Shading vorgenommen!, sonst nur Flatshading (ohne Schattierung)
			}
			
			buffer.append("\t</Appearance>\n");
		}
	}

	
	private double fillCoordArray(final double originalValue, boolean cutLandSurface) {
		if (Double.isNaN(originalValue)){
			// In optimierten netCDF steht oft NaN, wenn nicht belegt
			//logger.info("Original value is NaN: " + originalValue + "(i: " + i + " j: " + j + ")");
			return 0.001;							// Gehe von Landflaechen aus, daher leicht hoeher
		} else if (originalValue < 0) {
			return originalValue * negScale;		//Schreibe skalierte Tiefe
		} else if (originalValue > 0) {
			if (cutLandSurface) {
				// Cut landscapes based on the height
				return 0.001;						// Gehe von Landflaechen aus und glaette diese
			} else {
				return originalValue * posScale;	//Schreibe skalierte Höhe
			}
		} else { // if (originalValue == 0)
			return originalValue;
		}
	}


	private void writeCubeWall(final Map<String, String> args, final StringBuffer buffer, int sideNum, double[] wallCoords, int[] wallIndex, int xOffset, int zOffset) {
		buffer.append("\n<Shape id='CubeWall_" + sideNum + "'>\n");
		createAppearance(args, buffer, args.get("CubeWall_" + sideNum));
		buffer.append("\t<IndexedFaceSet solid='false' ccw='false' convex='false' coordIndex='");

		// Durchlaufen der y-Werte und Indizes (Schreiben der Coords und Indizes in den Buffer)
		for (int i : wallIndex) {
			buffer.append(i + " ");
		}
		// Die letzten beiden Indizes (Punkte für Unterkante der Seitenfläche) manuell setzen
		buffer.append(wallCoords.length + " " + (wallCoords.length + 1));
		
		buffer.append(" 0'>\n\t\t<Coordinate point='");
		switch (sideNum) {
		case 1:
		case 3:
			for (int i = 0; i < wallCoords.length; i++) {
				buffer.append(" " + xOffset + " " + wallCoords[i] + " " + (i*100));
			}
			// Die letzten beiden Stützpunkte (Unterkante der Seitenfläche) manuell setzen
			buffer.append(" " + xOffset + " -10000 " + zOffset);
			buffer.append(" " + xOffset + " -10000 0");
			break;
		case 2:
		case 4:
			for (int i = 0; i < wallCoords.length; i++) {
				buffer.append((i*100) + " " + wallCoords[i] + " " + zOffset + " ");
			}
			// Die letzten beiden Stützpunkte (Unterkante der Seitenfläche) manuell setzen
			buffer.append(xOffset + " -10000 " + zOffset + " ");
			buffer.append(" 0 -10000 " + zOffset);
			break;	
		}
		buffer.append("'/>\n\t</IndexedFaceSet>\n</Shape>");
	}

	public void setCoordsColor(double[][] coordsColor) {
		this.coordsColor = coordsColor;
	}

}
