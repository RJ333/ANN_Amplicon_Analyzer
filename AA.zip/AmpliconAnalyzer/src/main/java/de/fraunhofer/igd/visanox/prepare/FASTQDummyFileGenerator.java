package de.fraunhofer.igd.visanox.prepare;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang.time.StopWatch;
import org.omg.CORBA.UNKNOWN;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.Random;
import java.util.zip.GZIPOutputStream;

/**
 * Generate Dummy FASTQ-Files
 * - uses specification found at http://maq.sourceforge.net/fastq.shtml (06.07.16)
 */
class FASTQDummyFileGenerator {
    private Function<Double, Double> qualityFunction;
    private Function<Double, Double> sequenceFunction;
    private Supplier<Integer> lengthFunction;

    private char[] validSequenceNameChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.:- ".toCharArray();
    private char[] validSequenceChars = "ATCGN".toCharArray(); //RNA-sequencing is done by reverse transcription, so no Uracil in reads
    private char[] validQualityChars = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~".toCharArray();


    FASTQDummyFileGenerator (Function<Double,Double> distribution, Function<Double,Double> quality, Supplier<Integer> length) {
        this.sequenceFunction = distribution; this.qualityFunction = quality; this.lengthFunction = length;
    }

    FASTQDummyFileGenerator (Function<Double,Double> distribution, Function<Double,Double> quality, int length) {
        this.sequenceFunction = distribution; this.qualityFunction = quality; this.lengthFunction = ()->(length);
    }

    private String generateSequenceBasedOnAlphabetAndFunction (int len, char[] alphabet, Function<Double, Double> func) {
        assert len > 0;
        char sequence[] = new char[len]; Random r = new Random(); int s_len = len;
        for (len--; len >= 0; sequence[len] = alphabet[(int) (func.apply((double) len / (double) s_len) * alphabet.length)], len--) { }
        return String.valueOf(sequence);
    }

    /***
     * Generates a valid Sequence Name
     * @param len lenght of name
     * @return valid sequence name of length len
     */
    String generateSequenceName(int len) {
        Random r = new Random();
        return this.generateSequenceBasedOnAlphabetAndFunction(len, this.validSequenceNameChars, (Double)->(r.nextDouble()));
    }

    /***
     * Generates a valid Sequence
     * @param len lenght of sequence
     * @return valid sequence of length len
     */
    String generateSequence (int len) {
        return this.generateSequenceBasedOnAlphabetAndFunction(len, this.validSequenceChars, this.sequenceFunction);
    }

    /***
     * Generates a valid Quality-Sequence
     * @param len lenght of sequence
     * @return valid quality-sequence of length len
     */
    String generateQuality (int len) {
        return this.generateSequenceBasedOnAlphabetAndFunction(len, this.validQualityChars, this.qualityFunction);
    }

    /***
     * Generates a FASTQ-Sequence-Block consisting of a Sequence-Name, Sequence and Quality
     * @return a FASTQ-Sequence-Block followed by a linebreak
     */
    String generateDummyBlock () {
        int len = this.lengthFunction.get();
        assert len > 24; // otherwise lenghtOfSequenceName <= 0
        int lengthOfSequenceName = len/5-4; // -4 for @, \n and +
        int lengthOfSequence = len/5*2-1;
        int lengthOfSequenceQuality = len/5*2-1;
        return "@" +
                this.generateSequenceName(lengthOfSequenceName) +
                '\n' +
                this.generateSequence(lengthOfSequence) +
                "\n+\n" +
                this.generateQuality(lengthOfSequenceQuality) +
                '\n';
    }

    /***
     * Generates a FASTQ-File filled with Dummy-Sequences
     * @param fileName path to where the file shall be saved
     * @param numberOfBlocks number of dummy-blocks that shall be generated
     * @throws FileNotFoundException
     */
    void generateDummyFile (String fileName, int numberOfBlocks) throws FileNotFoundException {
        assert numberOfBlocks > 0;
        PrintWriter f = new PrintWriter(fileName);
        for (; numberOfBlocks > 0; numberOfBlocks--, f.write(this.generateDummyBlock())) { }
        f.close();
    }

    /***
     * Generates a compressed FASTQ-File filled with Dummy-Sequences
     * @param fileName path to where the compressed file shall be saved
     * @param numberOfBlocks number of dummy-blocks that shall be generated
     * @throws FileNotFoundException
     */
    void generateCompressedDummyFile (String fileName, int numberOfBlocks) throws IOException {
        assert numberOfBlocks > 0;

        FileOutputStream f = new FileOutputStream(fileName);
        GZIPOutputStream f_gzip = new GZIPOutputStream(f);

        for (; numberOfBlocks > 0; numberOfBlocks--, f_gzip.write(this.generateDummyBlock().getBytes(StandardCharsets.US_ASCII))) { }

        f_gzip.close();
    }
}
