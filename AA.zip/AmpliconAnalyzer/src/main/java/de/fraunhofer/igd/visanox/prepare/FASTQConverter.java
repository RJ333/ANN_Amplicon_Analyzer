package de.fraunhofer.igd.visanox.prepare;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 * Can be used to convert fastq-files to csv-files
 *
 * Example-Output:
 * Label_0, Label_1, Label_2, Label_3, Label_4, Label_5, Label_6, Label_7
 * A, A, D, D, D, A, C, C
 * ...
 *
 * @remark DO NOT USE HUGE FILES! (All sequences are kept in memory!)
 */
class FASTQConverter {
    private char[] validSequenceNameChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.:- /".toCharArray();
    private char[] validSequenceChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.~".toCharArray();
    private char[] validQualityChars = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~".toCharArray();

    private String labelPrefix = "Label_";

    private static final Logger log = Logger.getLogger( FASTQConverter.class.getName() );

    /**
     * Use convertFASTQToCSV() to convert a fastq-file
     * to a csv-document
     */
    FASTQConverter() {
        this("Label_");
    }

    FASTQConverter (String labelPrefix) {
        this.labelPrefix = labelPrefix;
    }

    private boolean contains (char[] alphabet, char needle) {
        for (char c : alphabet) {
            if (needle == c) {
                return true;
            }
        }
        return false;
    }

    public void setLabelPrefix(String labelPrefix) {
        this.labelPrefix = labelPrefix;
    }

    /**
     * Converts a FASTQ-File to a CSV-File (',' = delimiter)
     * first row = position of character
     * n-th row = sequences (ONLY sequence - not quality)
     * column = character of sequence
     * prefix for header can be set using setLabelPrefix()
     * @param fastqFileName file that is going to be read
     * @param csvFileName path to output-file
     * @throws IOException
     */
    void convertFASTQToCSV(String fastqFileName, String csvFileName) throws IOException {
        convertFASTQToCSV(fastqFileName, csvFileName, CSVFormat.EXCEL.withDelimiter(';').withRecordSeparator('\n'));
    }

    /**
     * Converts a FASTQ-File to a CSV-File
     * first row = position of character
     * n-th row = sequences (ONLY sequence - not quality)
     * column = character of sequence
     * prefix for header can be set using setLabelPrefix()
     * @param fastqFileName file that is going to be read
     * @param csvFileName path to output-file
     * @param format format of the csv-file (delimiter e.g.)
     * @throws IOException
     */
    void convertFASTQToCSV (String fastqFileName, String csvFileName, CSVFormat format) throws IOException {
        FileWriter f = new FileWriter(csvFileName);
        CSVPrinter csv = new CSVPrinter(f,format);
        FileReader reader = new FileReader(fastqFileName);

        char[] buff = new char[1024];

        // Unknown = 0, readingSequenceName, readingSequence, readingSeparator, readingQuality, readingOptional
        FASTQConverterState state = FASTQConverterState.READINGNAMEIDENTIFIER;

        int maxLen = 0; // maximum sequence length
        int len;        // length of buffer

        ArrayList<String> currentRecord = new ArrayList<>();

        while ((len = reader.read(buff)) >= 0) {
            for (int buffPos = 0; buffPos < len; buffPos++) {
                //log.info(buff[buffPos]+" -> "+state.toString()+"\n");
                switch (state) {
                    case UNKNOWN: // read invalid input
                        log.warning("Unknown state: trying to recover...");if (buff[buffPos] == '@') {
                            state = FASTQConverterState.READINGNAME;
                        }
                        if (buff[buffPos] == '+') {
                            state = FASTQConverterState.READINGOPTIONAL;
                        }
                        break;
                    case READINGNAMEIDENTIFIER:
                        if (buff[buffPos] == '@') {
                            state = FASTQConverterState.READINGNAME;
                        } else  {
                            state = FASTQConverterState.UNKNOWN;
                        }
                        break;
                    case READINGNAME:
                        if (buff[buffPos] == '\n') {
                            state = FASTQConverterState.READINGSEQUENCE;
                        } else if (!this.contains(this.validSequenceNameChars,buff[buffPos])) {
                            state = FASTQConverterState.UNKNOWN;
                        }
                        break;
                    case READINGSEQUENCE:
                        if (buff[buffPos] == '\n') {
                            state = FASTQConverterState.READINGOPTIONAL;
                            if (maxLen == 0) {
                                ArrayList<String> header = new ArrayList<>();
                                for (int i = 0; i < currentRecord.size(); i++) {
                                    header.add(this.labelPrefix + Integer.valueOf(i).toString());
                                }
                                csv.printRecord(header);
                                maxLen = currentRecord.size();
                            }
                            csv.printRecord(currentRecord);
                            currentRecord = new ArrayList<>();
                        } else if (!this.contains(this.validSequenceChars,buff[buffPos])) {
                            state = FASTQConverterState.UNKNOWN;
                        } else if (currentRecord.size() >= maxLen && maxLen > 0) {
                            log.warning("Sequence longer than expected! (Longer than "+maxLen+")\n");
                        } else {
                            currentRecord.add(String.valueOf(buff[buffPos]));
                        }
                        break;
                    case READINGOPTIONAL:
                        if (buff[buffPos] == '\n') {
                            state = FASTQConverterState.READINGQUALITY;
                        } else if (buff[buffPos] == '+') {
                            state = FASTQConverterState.READINGOPTIONAL;
                        } else if (this.contains(this.validQualityChars,buff[buffPos])) {
                            state = FASTQConverterState.READINGQUALITY;
                        } else {
                            state = FASTQConverterState.UNKNOWN;
                        }
                        break;
                    case READINGQUALITY:
                        if (buff[buffPos] == '\n') {
                            state = FASTQConverterState.READINGNAMEIDENTIFIER;
                        } else if (!this.contains(this.validQualityChars,buff[buffPos])) {
                            state = FASTQConverterState.UNKNOWN;
                        }
                        break;
                    default:
                        state = FASTQConverterState.UNKNOWN;
                        break;
                }
            }
        }
        csv.close();
    }
}
