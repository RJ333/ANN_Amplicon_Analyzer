package de.fraunhofer.igd.aa.machineLearning;

import static org.nd4j.linalg.indexing.NDArrayIndex.interval;

import java.util.List;

import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;

public class CustomNDArrayHandling {
  
  /**
   * The {@link INDArray-library} already has a merge method, but it merges the sets 'batch-wise'.
   * What is needed here is to pick the first point in time from all dataSets and merge it into the new set,
   * then all second time points etc.
   * @param sets
   * @return
   */
//  public static DataSet mergeAmpliconFiles(List<DataSet> sets){
//    assert(!sets.isEmpty()); 
//    
//    DataSet timeData = new DataSet
//    INDArray mergedFeatures = Nd4j.crea
//    INDArray mergedLabels = sets.get(0).getLabels();
//    
//    for (int i = 0; i < sets.size(); i++) {
//      int nEx = arr.size(0);
//      indexes[0] = interval(rowCount, rowCount + nEx);
//      out.put(indexes, arr);
//      rowCount += nEx;
//  }
//    return new DataSet();
//  }

}
