package de.fraunhofer.igd.visanox.compare;

import org.biojava.bio.seq.DNATools;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.SimpleSymbolList;
import org.biojava.bio.symbol.SymbolList;
import org.biojava.bio.alignment.AlignmentPair;
import org.biojava.bio.alignment.NeedlemanWunsch;
import org.biojava.bio.alignment.SubstitutionMatrix;
import org.junit.Test;

import java.io.*;
import java.util.zip.GZIPInputStream;

/**
 * Created by Franz Bender on 31.08.2016.
 * Example for Needleman-Wunsch
 */
enum ParserState { Identifier, Sequence, Quality, Separator }

public class AlignmentExample {

    /***
     * Parse compressed fastq-file to BioJava SymbolList
     * @param path Path to compressed (*.fastq.gz) file
     * @return List of all symbols in file
     * @throws IOException
     * @throws IllegalSymbolException
     */
    public static SymbolList loadFASTQ (String path) throws IOException, IllegalSymbolException {
        GZIPInputStream inputStream = new GZIPInputStream(new BufferedInputStream(new FileInputStream(path)));
        Reader reader = new InputStreamReader(inputStream);

        // Init automaton
        int character;
        ParserState state = ParserState.Identifier;

        SimpleSymbolList list = new SimpleSymbolList(DNATools.getDNA());

        // Read file char by char
        while ((character = reader.read()) >= 0) {
            switch (state) {
                case Identifier:
                    if (character == '\n') {
                        state = ParserState.Sequence;
                    }
                    break;

                case Sequence:
                    if (character == '\n') {
                        state = ParserState.Separator;
                    } else {
                        switch (character) {
                            case 'A':
                                list.addSymbol(DNATools.a());
                                break;
                            case 'T':
                                list.addSymbol(DNATools.t());
                                break;
                            case 'C':
                                list.addSymbol(DNATools.c());
                                break;
                            case 'G':
                                list.addSymbol(DNATools.g());
                                break;
                        }
                    }
                    break;

                case Separator:
                    state = ParserState.Quality;
                    break;

                case Quality:
                    if (character == '\n') {
                        state = ParserState.Identifier;
                    }
                    break;
            }
        }

        return list;
    }

    @Test
    public void testAlignmentExample () {
        String file1 = "";
        String file2 = "";

        System.out.println("Start.\nWARNING: Parsing might take a while!\n");

        try {
            // read both files
            System.out.println("Parsing "+file1+"...");
            SymbolList list1 = this.loadFASTQ(file1);
            System.out.println("Finished (Length: "+list1.length()+").");

            System.out.println("Parsing "+file2+"...");
            SymbolList list2 = this.loadFASTQ(file2);
            System.out.println("Finished (Length: "+list2.length()+").");

            // calculate score
            System.out.println("Calculating...");

            NeedlemanWunsch wish = new NeedlemanWunsch(
                    (short) 0, // costs for match, replace etc.
                    (short) 2,
                    (short) 2,
                    (short) 2,
                    (short) 1,
                    SubstitutionMatrix.getNuc4_4());

            // start alignment an print score
            AlignmentPair a = wish.pairwiseAlignment(list1, list2);
            System.out.print(a.getScore());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (org.biojava.bio.BioException e) {
            e.printStackTrace();
        }

    }
}
