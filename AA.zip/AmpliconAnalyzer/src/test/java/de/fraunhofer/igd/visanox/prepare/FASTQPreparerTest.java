package de.fraunhofer.igd.visanox.prepare;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Tests for FASTQPreparer
 */
public class FASTQPreparerTest {
    @Test
    public void decompress() throws Exception {
        FASTQPreparer p = new FASTQPreparer("",50000);
        p.partition("C:\\_dev\\FASTQ-Test-Files\\really_big.gz","C:\\_dev\\FASTQ-Test-Files\\chunks.zip");
    }

}