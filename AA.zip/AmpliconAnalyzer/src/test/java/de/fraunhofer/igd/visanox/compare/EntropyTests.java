package de.fraunhofer.igd.visanox.compare;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JFileChooser;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.io.FileUtils;
import org.junit.Test;

import com.vividsolutions.jts.io.ParseException;

import net.java.truevfs.access.TFile;

public class EntropyTests {
  
  @Test
  public void testSplitByEntropy()throws IOException, ParseException, ArchiveException, InterruptedException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("P:\\Metagenomics\\Daten");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    fc.setDialogTitle("Choose file for entropy analysis");
    fc.showOpenDialog(null);
    File dir = fc.getSelectedFile();
    String[] extensions = new String[] { "gz", "fastq", "fq", "fna", "zip" };//ignore .7z, unpacking not possible atm    
    
    List<Sequence> sequences = ParseFASTQ.readFASTQfile(dir.getAbsolutePath());
    List<List<Sequence>> LOsequences = Entropy.splitReads(sequences);
    System.out.println("debugPoint");
  }
}
