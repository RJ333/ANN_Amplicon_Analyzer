package de.fraunhofer.igd.visanox.compare;

import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.apache.commons.math3.stat.inference.ChiSquareTest;
import org.apache.commons.math3.stat.inference.GTest;
import org.apache.commons.math3.distribution.ChiSquaredDistribution;
import org.junit.Ignore;
import org.junit.Test;

import de.fraunhofer.igd.visanox.statistic.CramersV;

public class CompareMetaTTests {
  
  public char[] generateSequence(){
    Random random = new Random();
    int length = random.nextInt(15)+140;
    char[] sequence1 = new char[length];
    for(int i = 0; i < length; i++){
      int base = random.nextInt(5);
      switch(base){
      case 0: sequence1[i]='A'; break;
      case 1: sequence1[i]='U'; break;
      case 2: sequence1[i]='C'; break;
      case 3: sequence1[i]='G'; break;
      case 4: sequence1[i]='N'; break;
      }
    }
    return sequence1;
  }
  
  @Ignore
  @Test
  public void testSimpleCompare() {
    System.out.println(MetatranscriptomicCompare.trivialOneToOneDistance(generateSequence(), generateSequence()));
  }
  
  /**
   * comparing test statistics, just for correctness tests
   */
  @Test
  public void testChiSquare() {
    long[] sample1 = {1234567,8901234,5678901,2345678,90};//A,T,C,G,N
    long[] sample2 = {1234560,8901244,5678921,2345578,80};
    ChiSquareTest chi_test = new ChiSquareTest();
    
    long[][] contingencyTableNew = {sample1,sample2};
    
    System.out.printf("Chi-square statistics for goodness-of-fit: %f"+System.lineSeparator(), chi_test.chiSquareDataSetsComparison(sample1, sample2));
    System.out.printf("Chi-square statistics for remodeled contingency table: %f"+System.lineSeparator(), chi_test.chiSquare(contingencyTableNew));
    System.out.printf("The respective p-Value for the : %f"+System.lineSeparator(), chi_test.chiSquareTestDataSetsComparison(sample1, sample2));
  }
  
  /**
   * comparing test statistics, just for correctness tests
   */
  @Test
  public void compareTests() {
    //from aquarientests
    long sum1 = 35666142;
    long sum2 = 41644708;
    long factor = 10000;
    long[] sample1 = {8872849,7428515,7588996,11772216,3566};//from file c100_s80_R1, ATCGN
    long[] sample2 = {10398684,8712072,8849500,13680287,4164};//from file c102_s82_R1, sum: 
    
    GTest gTest = new GTest();
    ChiSquareTest chi_test = new ChiSquareTest();
    System.out.printf("GTest for goodness-of-fit: %f"+System.lineSeparator(), gTest.gTestDataSetsComparison(sample1, sample2));
    System.out.printf("Chi-Square : %f"+System.lineSeparator(), chi_test.chiSquareTestDataSetsComparison(sample1, sample2));
    System.out.printf("CramersV with phiSquare+biasCorrection : %f"+System.lineSeparator(), CramersV.remodeledCramers_V_biasCorrected(sample1, sample2)[1]);
    System.out.printf("GTest for goodness-of-fit: %f"+System.lineSeparator(), gTest.gTestDataSetsComparison(sample1, sample2));
    
    long[] fractions1 = Arrays.stream(sample1).map(el -> el*factor/sum1).filter(s -> s != (long) 0).toArray();
    long[] fractions2 = Arrays.stream(sample2).map(el -> el*factor/sum2).filter(s -> s != (long) 0).toArray();
    
    System.out.printf("GTest for goodness-of-fit for fractions: %f"+System.lineSeparator(), gTest.gTestDataSetsComparison(fractions1, fractions2));
    System.out.printf("CramersV with phiSquare+biasCorrection : %f"+System.lineSeparator(), CramersV.remodeledCramers_V_biasCorrected(fractions1, fractions2)[1]);
  }

}