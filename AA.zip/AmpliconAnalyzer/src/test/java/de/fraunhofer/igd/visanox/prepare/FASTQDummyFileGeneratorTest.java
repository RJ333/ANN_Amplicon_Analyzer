package de.fraunhofer.igd.visanox.prepare;

import org.junit.Test;
import scala.Int;

import java.util.Random;

import static org.junit.Assert.*;

/**
 * Tests for FASTQDummyFileGenerator
 */
public class FASTQDummyFileGeneratorTest {
    @Test
    public void generateCompressedDummyFile() throws Exception {
        Random r = new Random();
        FASTQDummyFileGenerator f = new FASTQDummyFileGenerator(x->x,x->x,()->(150));
        f.generateCompressedDummyFile("C:\\_dev\\FASTQ-Test-Files\\really_big.gz",40449390*3); // (ca 16 GB File)
        f.generateCompressedDummyFile("C:\\_dev\\FASTQ-Test-Files\\really_big.gz",500); // (ca 16 GB File)
    }

    @Test
    public void generateDummyFile() throws Exception {
        Random r = new Random();
        FASTQDummyFileGenerator f; // = new FASTQDummyFileGenerator(x->x,x->x,()->(Double.valueOf(r.nextDouble()*50+25+100).intValue()));
        f = new FASTQDummyFileGenerator((x)->(x),(x)->(x),()->(150));
        f.generateDummyFile("C:\\_dev\\FASTQ-Test-Files\\raw_fastq.fastq",100);
    }

    @Test
    public void generateSequenceName() throws Exception {
        FASTQDummyFileGenerator f = new FASTQDummyFileGenerator(x->x,x->x,()->25);
        System.out.print(f.generateSequenceName(200));
    }

    @Test
    public void generateSequence() throws Exception {
        FASTQDummyFileGenerator f = new FASTQDummyFileGenerator(x->x,x->x,()->25);
        System.out.print(f.generateSequence(200));
    }

    @Test
    public void generateQuality() throws Exception {
        FASTQDummyFileGenerator f = new FASTQDummyFileGenerator(x->x,x->x,()->25);
        System.out.print(f.generateQuality(200));
    }

    @Test
    public void generateDummyBlock() throws Exception {
        Random r = new Random();
        FASTQDummyFileGenerator f = new FASTQDummyFileGenerator(x->x,x->x,()->(Double.valueOf(r.nextDouble()*50+25).intValue()));
        for (int i = 0; i < 20; i++, System.out.print(f.generateDummyBlock())) { }
    }
}