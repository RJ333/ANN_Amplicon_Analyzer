package de.fraunhofer.igd.visanox.converter.anoxic;


import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.junit.Ignore;
import org.junit.Test;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.io.ParseException;


public class VolumeInterpolationTests{
  //@Ignore("too much at the moment")
  @Test
	public void testOceanviewBuilder (){
		final BuilderProperties properties = new BuilderProperties("input/data/iowtopo2_rev03.nc", "output/test.x3d", 
				"Z_TOPO", "LANDMASK", "YT_J", "XT_I", true, "3", "10", "input/templates/x3d-pure");
		properties.setUseGeoNodes(false);
		properties.setGenerateLandscape(true);
		properties.setMode(BuilderProperties.MODE_CONVERT);
		properties.setBasinsPath("input/data/basins/");
		properties.setIowDataFilePath("src/test/resources/tf201202.vis");
		properties.setGenerateLandscape(true);
		
		final X3DBuilder x3dBuilder = new X3DBuilder(properties);		
		x3dBuilder.convertGrid2X3D();
	}

	@Test
	@Ignore
	public void testExceptionHandling() {
		final BuilderProperties properties = new BuilderProperties("input/data/iowtopo2_rev03.nc", "output/test.x3d", 
				"Z_TOPO", "LANDMASK", "YT_J", "XT_I", true, "3", "10", "input/templates/x3d-pure");
		properties.setUseGeoNodes(false);
		properties.setMode(BuilderProperties.MODE_INFO);
		properties.setBasinsPath("input/data/basins/");
		properties.setIowDataFilePath("src/test/resources/tf197005.vis"); // Fehlerhaft (SingularMatrixException)
		
		final X3DBuilder x3dBuilder = new X3DBuilder(properties);		
		x3dBuilder.convertGrid2X3D();
	}
	
	@Test
	@Ignore
	public void testOldFiles() {
		final BuilderProperties properties = new BuilderProperties("input/data/iowtopo2_rev03.nc", "output/test.x3d", 
				"Z_TOPO", "LANDMASK", "YT_J", "XT_I", true, "3", "10", "input/templates/x3d-pure");
		properties.setUseGeoNodes(false);
		properties.setMode(BuilderProperties.MODE_INFO);
		properties.setBasinsPath("input/data/basins/");
		properties.setIowDataFilePath("src/test/resources/vis1969-2015-reduced/tf196905.vis"); // Hat mal NoSuchElementException geworfen
		
		final X3DBuilder x3dBuilder = new X3DBuilder(properties);		
		x3dBuilder.convertGrid2X3D();
	}
  //@Ignore("not needed at the moment, should still work though")
  @Test
  public void testKrigingWithIOW_Data() throws IOException, ParseException{
    
    VolumeInterpolation volInt = new VolumeInterpolation("input/data/basins/", "src/test/resources/tf201305.vis");
    //test a station directly - interpolation must fit almost exactly (coordinates are rounded)
    double[] result = volInt.ordinaryKriging(20.051, 57.320498, volInt.H2SVariogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    
    //exact fit, O2 and H2S measurement available
    result = volInt.ordinaryKriging(20.334413, 58.441988, volInt.O2Variogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    
    //exact fit, O2 and H2S measurement available
    result = volInt.ordinaryKriging(19.898000, 58.000333, volInt.O2Variogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    
    //points for tf201305.vis where there is O2 and H2S in the vicinity:
    result = volInt.ordinaryKriging(20, 57, volInt.O2Variogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    
    
    
    result = volInt.ordinaryKriging(21, 55, volInt.H2SVariogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    
    result = volInt.ordinaryKriging(18, 56, volInt.H2SVariogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    
    result = volInt.ordinaryKriging(100, 100, volInt.H2SVariogram, 2.5);
    System.out.println("O2-estimate: "+result[0]+"\n"+
    "H2S-estimate: "+result[1]);
    }
    
  @Test
  //@Ignore
    public void testBAXI() throws IOException, ParseException{
      String iowDataFilePath = Paths.get("src/test/resources/tf201305.vis").toString();
      
      List<String> wktFiles = new ArrayList<String>(6);
      for(int i = 0; i<6; i++){
        wktFiles.add(i, Paths.get("input/data/basins/bsb"+(i+1)+".wkt").toString());
      }
	  Map<String, Polygon>  basins = VolumeInterpolation.readBalticSeaBasinsFromFile(wktFiles);
      List<GridPointData> iowData = VolumeInterpolation.readFromIOW_TSV_File(iowDataFilePath, basins);
      BAXI baxi = new BAXI();
      
      System.out.printf("BAXI H2S: %2.2f"+System.lineSeparator(),baxi.computeDefinedBAXI(iowData, true));
      System.out.printf("BAXI O2: %2.2f"+System.lineSeparator(),baxi.computeDefinedBAXI(iowData, false));
      
  	}
  
    @Test
    @Ignore
    public void testBAXIWithVolumeInterpolationObject() throws IOException, ParseException{
      // BAXI-Erzeugung mit vollständigem VolumeInterpolation-Objekt (obwohl nicht benötigt)
	  BAXI baxi = new BAXI();
      VolumeInterpolation volInt = new VolumeInterpolation("input/data/basins/", "src/test/resources/tf201202.vis");
      System.out.printf("BAXI H2S: %2.2f"+System.lineSeparator(),baxi.computeDefinedBAXI(volInt.getInputData(), true));
      System.out.printf("BAXI O2: %2.2f"+System.lineSeparator(),baxi.computeDefinedBAXI(volInt.getInputData(), false));
      
      volInt = new VolumeInterpolation("input/data/basins/", "src/test/resources/tf201205.vis");
      System.out.printf("BAXI H2S: %2.2f"+System.lineSeparator(),baxi.computeDefinedBAXI(volInt.getInputData(), true));
      System.out.printf("BAXI O2: %2.2f"+System.lineSeparator(),baxi.computeDefinedBAXI(volInt.getInputData(), false));
    }
    
    @Test
    //@Ignore
    public void testBAXIonDirectory() throws IOException, ParseException{
      BAXI baxi = new BAXI();
      Map<String,Double> result =  baxi.readAllVisFiles("input/data/basins/", "src/test/resources/", false);
      for (Entry<String, Double> currBaxi: result.entrySet()) {
    	  System.out.println(currBaxi.toString());
      }
	}
    
    @Test
    public void testBasinConstrainedKriging() throws IOException, ParseException{
      VolumeInterpolation volInt = new VolumeInterpolation("input/data/basins/", "src/test/resources/tf201202.vis");
      //points for tf201307.vis where there is O2 and H2S in the vicinity:
      
      //Eastern Gotland
      double[] result = volInt.ordinaryKriging(20, 57, volInt.O2Variogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Western Gotland
      result = volInt.ordinaryKriging(18, 58, volInt.O2Variogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Northern Gotland
      result = volInt.ordinaryKriging(19.5, 59, volInt.O2Variogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Arkona
      result = volInt.ordinaryKriging(13.5, 54.8, volInt.O2Variogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Bornholm
      result = volInt.ordinaryKriging(16, 54.8, volInt.O2Variogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Gdansk
      result = volInt.ordinaryKriging(19, 54.8, volInt.O2Variogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Gdansk
      result = volInt.ordinaryKriging(18.5, 55, volInt.H2SVariogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Gdansk
      result = volInt.ordinaryKriging(18, 55, volInt.H2SVariogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Gdansk
      result = volInt.ordinaryKriging(18, 54.75, volInt.H2SVariogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
      
      //Gdansk
      result = volInt.ordinaryKriging(100, 100, volInt.H2SVariogram, 2.5);
      System.out.println("O2-estimate: "+result[0]+"\n"+
      "H2S-estimate: "+result[1]);
    }
    
    @Test
    public void testBasinOverlaps() throws IOException, ParseException{
      VolumeInterpolation volInt = new VolumeInterpolation("input/data/basins/", "src/test/resources/tf201202.vis");
      List<String> wktFiles = new ArrayList<String>(6);
      for(int i = 0; i<6; i++){
        wktFiles.add(i, Paths.get("input/data/basins/bsb"+(i+1)+".wkt").toString());
      }
      Map<String, Polygon>  basins = VolumeInterpolation.readBalticSeaBasinsFromFile(wktFiles);
      SortedMap<String,Polygon> newMap = new TreeMap<String,Polygon>();
      newMap.putAll(basins);
      //yep, ugly as f**k! Jakob sucks at programming
      List<Entry<String,Polygon>> entries = new ArrayList((Set<Entry<String,Polygon>>)basins.entrySet());
      for(int i = 0; i < entries.size();i++) {
        Entry<String,Polygon> basin1 = entries.get(i);
        for(int j = i+1; j<entries.size();j++){
          Entry<String,Polygon> basin2 = entries.get(j);
          if(basin1.getValue().intersects(basin2.getValue())) System.out.println("intersection detected: "+basin1.getKey()+" and "+basin2.getKey());
          if(basin1.getValue().crosses(basin2.getValue())) System.out.println("crossing detected: "+basin1.getKey()+" and "+basin2.getKey());
          if(basin1.getValue().touches(basin2.getValue())) System.out.println("touch detected: "+basin1.getKey()+" and "+basin2.getKey());
        }       
      }
    }
     
}
