package de.fraunhofer.igd.visanox.prepare;

import org.junit.Test;

import javax.swing.*;

import java.io.File;

import static org.junit.Assert.*;

/**
 * Tests for FASQConverter
 */
public class FASTQConverterTest {
    @Test
    public void convertFASTQToCSV() throws Exception {
        FASTQConverter f = new FASTQConverter();
        final JFileChooser fc = new JFileChooser();
        File defaultDir = new File("C:\\_dev\\FASTQ-Test-Files");
        if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
        fc.showOpenDialog(null);
        f.convertFASTQToCSV(fc.getSelectedFile().getAbsolutePath(), fc.getSelectedFile().getAbsolutePath()+".csv");
    }

}