package de.fraunhofer.igd.visanox.compare;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.bytedeco.javacpp.opencv_core.Stream;
import org.junit.Test;

public class StatisticsTests {
    
    
    
    private double[] createDistribution(){
	//the useful species will be, o.B.d.A., indices 0 to 8.
	final int species = 687;
	final int selectedSpecies = 30;
	
	int[] scores = new int[species];
	Arrays.fill(scores, 0);
	int[] count = new int[species];
	Arrays.fill(count, 0);
	
	Random rng = new Random();
	int usefuls = 0;
	
	List<Integer> currentSelected;
		
	for(int exp = 0; exp < 1200; exp++){
	    
	    //choose species
	    int remaining = 30;
	    currentSelected = new ArrayList<Integer>(selectedSpecies);
	    usefuls = 0;
	    while(remaining > 0){
		int current = rng.nextInt(species);
		if(! currentSelected.contains(current)) {
		    currentSelected.add(current);
		    remaining--;
		    if (current < 9) usefuls++;
		}
	    }
	    int score = 0;
	    if(usefuls == 0){
		    score = 700-rng.nextInt(200);
		}
	    if(usefuls == 1){
		score = 920-rng.nextInt(60);
	    }
	    if(usefuls > 1){
		score = 970-rng.nextInt(100-usefuls*8);
	    }
	    
	    //give scores
	    for(Integer cur : currentSelected){
		scores[cur]+=score;
		count[cur]++;
	    }
	    
	}
	double[] averageScores = new double[species];
	IntStream.range(0, scores.length).forEach(i -> averageScores[i] = scores[i]/count[i]);
	
        return averageScores;
    }
    
    @Test
    public void testDistribution(){
	@SuppressWarnings("unused")
	double[] distribution = createDistribution();
	double[] restDistribution = Arrays.copyOfRange(distribution, 9, distribution.length);
	Arrays.sort(restDistribution);
	System.out.println("blub");
    }

}
