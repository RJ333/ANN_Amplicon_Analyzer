package de.fraunhofer.igd.visanox.compare;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.math3.util.Pair;
import org.junit.Ignore;
import org.junit.Test;

import com.vividsolutions.jts.io.ParseException;

import net.java.truevfs.access.TFile;
import net.java.truevfs.access.TPath;

public class ParseFASTQTests {
  protected static final Log logger = LogFactory.getLog(ParseFASTQTests.class); 
  @Test
  @Ignore
  public void testFileParsing() throws IOException, ParseException, ArchiveException, InterruptedException{
    
    final JFileChooser fc = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter("fastq"); //this shouldnt work?!
    fc.setFileFilter(filter);
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    String location = file.getAbsolutePath();
    
    List<Sequence> reads = ParseFASTQ.readFASTQfile(location);
    reads.stream().forEach(s -> System.out.println(s.identifier));
  }
  
  @Test
  @Ignore
  public void testArchiveInputStreamMethod() throws IOException, ParseException, ArchiveException{
    
    final JFileChooser fc = new JFileChooser();
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    ArchiveInputStream input = new ArchiveStreamFactory().createArchiveInputStream(new BufferedInputStream(Files.newInputStream(new TPath(file.getAbsolutePath()))));
    ArchiveEntry current;
    while((current = input.getNextEntry()) != null){
      System.out.println(current.toString());
    }
  }
  
  @Test
  @Ignore
  public void testTrueVFSMethods() throws IOException, ParseException, ArchiveException{
    
    final JFileChooser fc = new JFileChooser();
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    TFile input = new TFile(file);
    if(input.isArchive()) System.out.println("Virtual File System states, that "+input.getAbsolutePath()+" is an archive");
    
  }
  
  @Test
  //@Ignore //works but file chooser is inappropriate for repeated/automatic use
  public void testBasicStatistics() throws IOException, ParseException, ArchiveException, InterruptedException{
    File defaultDir = new File("P:\\Metagenomics\\Daten");
    
    final JFileChooser fc = new JFileChooser();
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    FileNameExtensionFilter filter = new FileNameExtensionFilter("FASTQ-files","fastq","gz","fq");
    fc.setFileFilter(filter);
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    String location = file.getAbsolutePath();
    
    FASTQStatistics stats = new FASTQStatistics();
    ParseFASTQ.readFASTQfile(location,stats);
    //reads.stream().forEach(s -> System.out.println(s.identifier));
    FASTQStatistics.printSummary(stats.getNucleotidePercentages());
    FASTQStatistics.printErrorStatistics(stats.getNumberOfQualities());
    stats.printNucleotideDistribution();
  }
  
  @Test
  public void testMultipleFiles()throws IOException, ParseException, ArchiveException, InterruptedException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("P:\\Metagenomics\\Daten");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fc.setDialogTitle("Choose directory from which all FASTQ-files will be loaded");
    fc.showOpenDialog(null);
    File dir = fc.getSelectedFile();
    String[] extensions = new String[] { "gz", "fastq", "fq", "fna", "zip" };//ignore .7z, unpacking not possible atm
    //Path trueVFSPath = new TPath(dir.getAbsolutePath());
    TFile tfile = new TFile(dir);
    
    //remove each selected file from 'tfiles', so that its not calculated again.
    //code introduced due to PC crashes/automatic reboots occuring during long calculations
    fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
    fc.setMultiSelectionEnabled(true);
    fc.setDialogTitle("Choose files or directories that are to be excluded from analysis");
    fc.showOpenDialog(null);
    List<File> filesalreadyDone = Arrays.asList(fc.getSelectedFiles());
    double[] results = {-99,-99};

    Collection<File> files = FileUtils.listFiles(dir, extensions, true); 
    files = files.stream().filter(file -> !filesalreadyDone.contains(file)).collect(Collectors.toList());
    List<TFile> tfiles = (List<TFile>) files.stream()
        .map(file -> {
        return new TFile(file);
        })
        .filter(f -> f != null)
        .sorted((File file1, File file2) -> {
          int number1 = Integer.parseInt(file1.getName().replaceAll("^\\D*?(-?\\d+).*$", "$1"));
          int number2 = Integer.parseInt(file2.getName().replaceAll("^\\D*?(-?\\d+).*$", "$1"));
          return Integer.compare(number1, number2);
        })
        .collect(Collectors.toList()); //.filter(file -> file.getAbsolutePath().endsWith("gz"))

    // <franz>
    CSVPrinter distPrinter = new CSVPrinter(new BufferedWriter(new FileWriter("dist.csv")), CSVFormat.DEFAULT);
    CSVPrinter compPrinter = new CSVPrinter(new BufferedWriter(new FileWriter("comp.csv")), CSVFormat.DEFAULT);

    String[] distHeader = new String[] {"file", "A", "T", "C", "G", "entropy"};
    String[] compHeader = new String[] {"file1", "file2", "A1/A2", "T1/T2", "C1/C2", "G1/G2", "test1", "test2", "test3"};

    distPrinter.printRecord(distHeader);
    compPrinter.printRecord(compHeader);
    // </franz>
    


    //tfiles.stream().filter(f -> str.)
    
    compareAllPairwise(files, tfiles, distPrinter, compPrinter);
    //compareOnlyNeighbors(files, tfiles, distPrinter, compPrinter, 4);
    // franz
    
    distPrinter.println();
    distPrinter.printRecord(ArrayUtils.toString(AggregatedStatistics.getInstance().getMeanEntropy()));
    
    distPrinter.close();
    compPrinter.close();
  }
  /**
   * Compares each file only with <b>lookahead</b> neighbors, to save computation time
   * 
   * @param files
   * @param tfiles
   * @param distPrinter
   * @param compPrinter
   * @param lookahead
   * @return
   * @throws IOException
   * @throws ParseException
   * @throws ArchiveException
   * @throws InterruptedException
   */
  protected double[] compareOnlyNeighbors(Collection<File> files, List<TFile> tfiles, CSVPrinter distPrinter,
      CSVPrinter compPrinter, int lookahead) throws IOException, ParseException,
      ArchiveException, InterruptedException {
    assert(lookahead > 0 && lookahead < files.size());
    double[] results = new double[5];
    for (int i = 0; i<files.size(); i++) {
      for(int j = i+1; j<=i+lookahead&&j<files.size(); j++){
        //if(j>=files.size()) break; //why did this not work??
        //(j=i+1): put each file only once in dist.csv
        results = MetatranscriptomicCompare.compareSamplesOneToOne(tfiles.get(i).getAbsolutePath(), tfiles.get(j).getAbsolutePath(), distPrinter, compPrinter,(j==i+1));
       logger.info("Comparing file: "+tfiles.get(i).getName().replaceFirst("\\..*", "")+" with: "+tfiles.get(j).getName()); 
       logger.info(String.format("G-Test: %,.6f %n", results[0])); 
       logger.info(String.format("KS-Test: %,.6f %n"+System.lineSeparator(), results[1])); 
      }      
    }
    return results;
  }
  
  /**
   * Compares each file with each other (but no file with itself)
   * 
   * @param results see  <a>MetatranscriptomicCompare.compareSamplesOneToOne</a>
   * @param files
   * @param tfiles
   * @param distPrinter
   * @param compPrinter
   * @return
   * @throws IOException
   * @throws ParseException
   * @throws ArchiveException
   * @throws InterruptedException
   */
  protected double[] compareAllPairwise(Collection<File> files, List<TFile> tfiles, CSVPrinter distPrinter,
      CSVPrinter compPrinter) throws IOException, ParseException,
      ArchiveException, InterruptedException {
    assert(files.size()==tfiles.size()); //just ignores this assert?!?!
    double[] results = new double[5];
    for (int i = 0; i<files.size(); i++) {
      for(int j = i+1; j<files.size(); j++){
        if(j==files.size()) break;
        //(j=i+1): put each file only once in dist.csv
        results = MetatranscriptomicCompare.compareSamplesOneToOne(tfiles.get(i).getAbsolutePath(), tfiles.get(j).getAbsolutePath(), distPrinter, compPrinter,(j==i+1));
       logger.info("Comparing file: "+tfiles.get(i).getName().replaceFirst("\\..*", "")+" with: "+tfiles.get(j).getName()); 
       logger.info(String.format("G-Test: %,.6f %n", results[0])); 
       logger.info(String.format("KS-Test: %,.6f %n"+System.lineSeparator(), results[1])); 
      }      
    }
    return results;
  }
  
  
  @Test
  public void testOpenGZIPFiles()throws IOException, ParseException, ArchiveException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("P:\\Metagenomics\\Daten");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    fc.showOpenDialog(null);
    File dir = fc.getSelectedFile();
    //Path trueVFSPath = new TPath(dir.getAbsolutePath());
    TFile tfile = new TFile(dir);
    System.out.print("Reading file: "+tfile.getName());
    ParseFASTQ.openGZIP(tfile.getAbsolutePath());
  }
  
  @Test
  public void testClassificationParsing() throws IOException, ParseException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("P:\\Metagenomics\\Daten");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fc.showOpenDialog(null);
    File dir = fc.getSelectedFile();
    String[] extensions = new String[] { "txt" };
    //Path trueVFSPath = new TPath(dir.getAbsolutePath());
    TFile tfile = new TFile(dir);
    Collection<File> files = FileUtils.listFiles(dir, extensions, true); 
    List<TFile> tfiles = (List<TFile>) files.stream().filter(file -> file.getAbsolutePath().toLowerCase().contains("classification")).map(file -> new TFile(file)).collect(Collectors.toList()); 
    for (int i = 0; i<tfiles.size(); i++) {
      System.out.println("Reading file: "+tfiles.get(i).getName());
      ClassificationResults results = ParseClassificationResults.parseClassification(tfiles.get(i).getAbsolutePath());
      System.out.println(results.toString());
    }
  }
  
  @Test
  public void testGZIPInputStreamLibrary() throws IOException, ParseException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("P:\\Metagenomics\\Daten");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    fc.showOpenDialog(null);
    File dir = fc.getSelectedFile();
    String[] extensions = new String[] { "gz" };
    //Path trueVFSPath = new TPath(dir.getAbsolutePath());
    int lineNumber = 0;
    BufferedReader br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(dir))));
    while(br.ready()){
      lineNumber++;
      System.out.println("Line "+lineNumber+ " "+br.readLine());
    }
    br.close();
  }
  
  
  //method for removing duplicates in output file: 'dist.csv', made to use R-visualizations
  @Test
  public void testMakeHeaderForRAndRemoveDuplicates() throws IOException {
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("C:\\Users\\jzabel\\Desktop\\promo\\daten");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    BufferedReader br = new BufferedReader(new FileReader(file));
    List<String> lines = new ArrayList<String>();
    String line ="";
    int max = 0;
    int countColumns;
    Pattern columnIdentifier = Pattern.compile(".,"); //identifying a new column
    Pattern filePattern = Pattern.compile("^[^,]+"); //grabbing the file name, beg. of line + non-comma-chars
    Matcher  matcher;
    Matcher currentFile;
    Set<String> files = new TreeSet<String>(); //filenames WITHIN the opened file
    String fileName;
    while (br.ready()) {
      line = br.readLine();
      
      if (line.matches("^\\s*$")){ //average entropy is separated by an empty line from the rest of the file
        lines.add(line);
        while (br.ready()){
        lines.add(br.readLine());
        }
        break;
      }else{
        
        
      currentFile = filePattern.matcher(line);
      currentFile.find();
      fileName = currentFile.group();
      if (!files.contains(fileName)) {
        lines.add(line);
        files.add(fileName);

        matcher = columnIdentifier.matcher(line);
        countColumns = 0;
        while (matcher.find()) {
          countColumns++;
        }
        if (countColumns > max)
          max = countColumns;
      }
    }}
    br.close();
    BufferedWriter fw = new BufferedWriter(new FileWriter(file));
    String add = "";
    for(int i = 0;i<max-1;i++){
      add+=i+",";
    }
    add+=max;
    line = "file,A,T,C,G,"+add; 
    lines.set(0, line);
    Iterator<String> lit = lines.listIterator();
    while(lit.hasNext()){
      fw.write(lit.next()+System.lineSeparator());
    }
    fw.close();
  }
  
  
  //the output from 'testMultipleFiles', which contains several results (such as the three statistical tests), will
  //be mapped to a matrix of one of these parameters each. rows = columns = samples, values = one parameter 
  @Test
  public void convertAAOutputFileToMatrixFormat() throws IOException {
    final String column = "test3";
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("C:\\test");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    BufferedReader br = new BufferedReader(new FileReader(file));
    Map<Pair<String,String>,Double> table = new HashMap<Pair<String,String>,Double>(); // (file1,file2), valueOfComparison
    
    CSVParser csvParser = new CSVParser(new FileReader(file), CSVFormat.DEFAULT.withFirstRecordAsHeader());
    csvParser.getRecords().forEach(rec -> {
      Pair<String,String> pair = new Pair<String,String>(rec.get("file1").replaceFirst("^(\\D?)(\\d\\d)(\\D)","$1"+"0"+"$2$3"),rec.get("file2").replaceFirst("^(\\D?)(\\d\\d)(\\D)","$1"+"0"+"$2$3"));
      table.put(pair, Double.valueOf(rec.get(column))); //this shouldnt work in streams...? not sure
      });
    
    //br = new BufferedReader(new FileReader(file)); //br.reset() won't do it, as it only jumps back to beginning of buffer, not necessarily to the beginning of the file
    Set<String> filenameSet = (Set<String>) table.keySet().stream().sequential().collect(HashSet<String>::new, (set,pair) -> {set.add(pair.getFirst()); set.add(pair.getSecond());}  , (set1,set2) -> set1.addAll(set2));
    List<String> filenamesOrdered = (List<String>) filenameSet.stream().sorted().collect(Collectors.toList());
    
    double[][] distanceMatrix = new double[filenamesOrdered.size()][filenamesOrdered.size()];
    
    int col = 0;
    int row = 0;
    for(Pair<String,String> entry : table.keySet()){
      col = filenamesOrdered.indexOf(entry.getFirst());
      row = filenamesOrdered.indexOf(entry.getSecond());
      try{
      distanceMatrix[row][col] = table.get(entry);
      distanceMatrix[col][row] = table.get(entry);
      }catch(Exception e){
        System.out.println("array error while reorganizing the data");
      }
    }
    
    BufferedWriter fw = new BufferedWriter(new FileWriter(new File(file.getAbsolutePath().replace(".csv", "mappedTo"+column+".csv"))));
    fw.write("sampleName,"+String.join(",", filenamesOrdered)+System.lineSeparator()); //table header
    //fw.write(filenamesOrdered.stream().reduce("", (name1,name2)-> name1.concat(","+name2)));
    Iterator<String> it = filenamesOrdered.iterator();
    String line;
    String array;
    int index = 0;
    while(it.hasNext()){
      line = it.next();
      array = Arrays.stream(distanceMatrix[index]).mapToObj(d -> new Double(d).toString()).reduce((s1,s2)->s1+","+s2).get();
      array.substring(1, array.length()-1);
      line+=","+array;
      index++;
      fw.write(line+System.lineSeparator());
    }
    fw.close();
  }
  

}
