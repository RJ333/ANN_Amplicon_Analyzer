package de.fraunhofer.igd.visanox.compare;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.SpinnerModel;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.lang3.ArrayUtils;
import org.geotools.resources.SwingUtilities;
import org.junit.Ignore;
import org.junit.Test;
import org.nd4j.linalg.dataset.DataSet;

import com.vividsolutions.jts.io.ParseException;

import de.fraunhofer.igd.aa.machineLearning.GlyphosatAnalyzer;
import de.fraunhofer.igd.visanox.prepare.CSVReadSpecies;

public class ANNtests extends JPanel{
  
  private static JSpinner spinner;
  
  private static int [] startIndices;
  private static int position = 0;
  private static boolean replicates = false; 
  
  private static File[] files;
  private static int[] spinnerListValues = IntStream.range(-1, 17).toArray();
  private static JFrame startFrame;
  private static JCheckBox checkBox;
  private static JButton okButton = new javax.swing.JButton();
  private static Semaphore semaphore = new Semaphore(1);
  private static final int NUMBER_OF_EXPERIMENT_REPETITIONS = 100;
  private static final File experimentResults = new File("C:\\Users\\jzabel\\Desktop\\promo\\paperGradient\\ergebnisse\\testsBiofilmPlusWater.csv");
  private static boolean[] timepoints = {true,false,true,false,true,false,true,false,true,false,true,false,true,false,true,false};
  private static final int OTU_RESELECTION = 1000;
  
  
  private void timepointDistribution(int amountOfTrues){
      if(amountOfTrues == 16) {
	  Arrays.fill(timepoints, true);
	  System.out.println("timepoints used: "+ Arrays.toString(timepoints));
	  return;
      }else{
      assert(amountOfTrues<16 && amountOfTrues >3);
      Arrays.fill(timepoints, false); 
      timepoints[0]=true;
      timepoints[15]=true;
      int distance = new Double(Math.ceil(16/( (double) amountOfTrues))).intValue();
      int index = distance;
      amountOfTrues-=2;
      //distribute timepoints evenly
      while(index < 15 && amountOfTrues > 0){
	  timepoints[index] = true;
	  index+=distance;
	  amountOfTrues--;
      }
      //distribute remaining timepoints randomly, if any left
      Random rng = new Random();
      while(amountOfTrues>0){
	  int random = rng.nextInt(15);
	  if(!timepoints[random]) {
	      timepoints[random]=true;
	      amountOfTrues--;
	  }
      }
      
      System.out.println("timepoints used: "+ Arrays.toString(timepoints));
      return;
      }
  }
  @Test
  public void testTimepointReselection(){
      timepointDistribution(5);
      timepointDistribution(8);
      timepointDistribution(11);
  }
    
  
  @Test
  public void conductANNexperiments() throws IOException, ParseException,
      ArchiveException, InterruptedException, InvocationTargetException {

    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("C:\\Users\\jzabel\\Desktop\\promo\\daten\\aquarien\\OTUtablesWithoutSingletons\\5erTabelleAufgeteilt"); 
    if (defaultDir.canRead())
      fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    FileNameExtensionFilter filter = new FileNameExtensionFilter(null, "csv");
    fc.setFileFilter(filter);
    fc.setMultiSelectionEnabled(true);
    fc.showOpenDialog(null);
    files = fc.getSelectedFiles();
    startIndices = new int[files.length];
    SwingUtilities.invokeAndWait(new Runnable() {
      public void run() {
        initGUI();
      }

    });
    startFrame.setVisible(true);

    indexFiles();
    timepoints = new boolean[100];
    Arrays.fill(timepoints, true);
    // BEGIN------------------select files--------------------------
    CSVReadSpecies csvr = new CSVReadSpecies();

    // data.add(csvr.readChristinAmpliconData(files[0]));
    // END------------------select files--------------------------
    File file = new File(
        "C:\\Users\\jzabel\\Desktop\\promo\\paperGradient\\ergebnisse\\trace.txt");
    PrintStream ps = new PrintStream(file);
    while (true) {
      try {
        // -------------EXPERIMENT---------------------------
        // pick a new random set of OTUs to work with
	  //int amountOfTimepoints = 9; // 
        for (int j = 1; j < OTU_RESELECTION; j++) {

          List<DataSet> data = new ArrayList<>();
          //csvr.setChosenFeaturesArray();
          csvr.testRandomFeature();
          //if(j % 5 == 0) amountOfTimepoints++;
          //timepointDistribution(amountOfTimepoints);
          //Arrays.fill(timepoints, true);
          //csvr.takeAllFeatures();
          for (int j1 = 0; j1 < files.length; j1++) {
            
            data.add(
                csvr.readAndTransposeAmpliconData(files[j1], startIndices[j1], timepoints, replicates));
          }
          DataSet ds = CSVReadSpecies.simpleMerge(data); //merges the files together into one dataset

          // BEGIN-----------EXPERIMENT----------------------------------
          for (int i = 0; i < NUMBER_OF_EXPERIMENT_REPETITIONS; i++) {
            GlyphosatAnalyzer ga =
                new GlyphosatAnalyzer(NUMBER_OF_EXPERIMENT_REPETITIONS);
            GlyphosatAnalyzer.setNumberOfFiles(files.length);
            ga.trainANNforAmpliconData(ds, experimentResults, replicates);
          }
          GlyphosatAnalyzer.storeResultsPlainTextSpecies(experimentResults,
              ds);
          System.out
              .println("Number of right guesses: " + System.lineSeparator()
                  + ArrayUtils.toString(GlyphosatAnalyzer.countRightGuesses));
          GlyphosatAnalyzer.resetGuessCount();
          // END-----------EXPERIMENT----------------------------------
        }
      } catch (Exception e) {
        e.printStackTrace(ps);
      }
    }
  }
  
  
  //dont use. the nd4j-shuffle() has issues
  private DataSet selectRandomly(DataSet ds, int numOTUs) {
    ds.shuffle();
    return ds.splitTestAndTrain(numOTUs).getTrain();
  }


  @Test
  @Ignore
  public void testAnnotateFileWithClasses() throws FileNotFoundException, IOException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("C:\\Users\\jzabel\\Desktop\\promo\\paperGradient");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    FileNameExtensionFilter filter = new FileNameExtensionFilter(null,"csv");
    fc.setFileFilter(filter);
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    CSVReadSpecies.addClassLabelsToAmpliconOTU(file);
  }
  

  @Test
  //@Ignore //not needed atm
  public void testGUI() throws InterruptedException{
    SwingUtilities.invokeAndWait(new Runnable() {
      public void run() {
        initGUI();
      }
    });
    spinner.setVisible(true);
    okButton.setVisible(true);
    startFrame.setVisible(true);
    TimeUnit.MINUTES.sleep(12);
    System.out.println("Spinner.isDisplayable(): "+spinner.isDisplayable());
  }
  
  @Test
  @Ignore //takes forever
  public void testTSNE() throws IOException{
    final JFileChooser fc = new JFileChooser();
    File defaultDir = new File("C:\\Users\\jzabel\\Desktop\\promo\\paperGradient");
    if(defaultDir.canRead()) fc.setCurrentDirectory(defaultDir);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    FileNameExtensionFilter filter = new FileNameExtensionFilter(null,"csv");
    fc.setFileFilter(filter);
    fc.showOpenDialog(null);
    File file = fc.getSelectedFile();
    
    CSVReadSpecies csvr = new CSVReadSpecies();
    DataSet data = csvr.readChristinAmpliconData(file,timepoints);
    GlyphosatAnalyzer.tDistributedStochasticNeighborEmbedding(data);
  }
  
  
  protected static void initGUI(){
    startFrame = new JFrame("Select start of treatment. If control (no treatment), select -1 ");
    startFrame.setPreferredSize(new Dimension(600, 200));
    startFrame.setLocation(600, 500);
    
    checkBox = new JCheckBox("3 replicates?");
    checkBox.setPreferredSize(new Dimension(35,35));
    checkBox.addItemListener(new java.awt.event.ItemListener() {
	@Override
	public void itemStateChanged(ItemEvent e) {
	   if(e.getStateChange()==ItemEvent.DESELECTED){
	       replicates = false;
	   }else{
	       replicates = true;
	   }	    
	}
    });
     
    okButton.setText("Ok");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        startIndices[position] = (int) spinner.getValue();
        semaphore.release();
        position++;
        }
    });
    
    SpinnerModel sModel = new SpinnerListModel(Arrays.stream(spinnerListValues).boxed().collect(Collectors.toList()));
    sModel.setValue(new Integer(4));

    spinner = new JSpinner(sModel);
    
    //BorderLayout needed, b/c otherwise components are all put into CENTER and will overwrite each other
    startFrame.add(okButton, BorderLayout.SOUTH);
    startFrame.add(spinner, BorderLayout.CENTER); 
    startFrame.add(checkBox, BorderLayout.EAST);
    
    startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //createGUILayout(startFrame, okButton, spinner);   
    startFrame.pack();
  }
  
  /**
   * lets the user select, at which timepoint the experiment substance (e.g. glyphosate) was added. 
   * Any timepoint beginning from the chosen index will be treated as class 1 (exp), any before as class 0 (control)
   */
  protected static void indexFiles(){
    try {
      semaphore.acquire();
    } catch (InterruptedException e1) {
      //interruption (by button press) is planned, so no action required
    }
    for(int i = 0; i<files.length; i++){
        try {
          
          startFrame.setTitle(files[i].getName());
          startFrame.setVisible(true);
          semaphore.acquire();
          //TimeUnit.MINUTES.sleep(15);
        } catch (InterruptedException e) {
          System.out.println("Thread "+Thread.currentThread().getName()+ "interrupted, current permits: "+ semaphore.availablePermits() );
          break;
        }
    }
    startFrame.setVisible(false);
  }
  
}
